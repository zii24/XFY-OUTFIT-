"use client";

import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import type { CartLine } from "@/types/order";

interface CartContextValue {
  lines: CartLine[];
  addLine: (line: CartLine) => void;
  removeLine: (id: string) => void;
  updateQuantity: (id: string, quantity: number) => void;
  clearDestination: (destination: CartLine["destination"]) => void;
  count: number;
  subtotalByDestination: Record<CartLine["destination"], number>;
}

const CartContext = createContext<CartContextValue | null>(null);
const STORAGE_KEY = "xfy_cart_v1";

export function CartProvider({ children }: { children: ReactNode }) {
  const [lines, setLines] = useState<CartLine[]>([]);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setLines(JSON.parse(raw));
    } catch {
      // Corrupt or blocked storage — start with an empty cart rather than crash.
    } finally {
      setHydrated(true);
    }
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(lines));
    } catch {
      // Storage full/unavailable — cart still works for this session.
    }
  }, [lines, hydrated]);

  const addLine = (line: CartLine) => {
    setLines((prev) => {
      const existing = prev.find((l) => l.id === line.id);
      if (existing) {
        const nextQty = Math.min(existing.quantity + line.quantity, existing.maxStock || 99);
        return prev.map((l) => (l.id === line.id ? { ...l, quantity: nextQty } : l));
      }
      return [...prev, line];
    });
  };

  const removeLine = (id: string) => setLines((prev) => prev.filter((l) => l.id !== id));

  const updateQuantity = (id: string, quantity: number) =>
    setLines((prev) =>
      prev.map((l) => (l.id === id ? { ...l, quantity: Math.max(1, Math.min(quantity, l.maxStock || 99)) } : l))
    );

  const clearDestination = (destination: CartLine["destination"]) =>
    setLines((prev) => prev.filter((l) => l.destination !== destination));

  const count = lines.reduce((sum, l) => sum + l.quantity, 0);

  const subtotalByDestination = useMemo(() => {
    const totals: Record<CartLine["destination"], number> = { xfy: 0, shopee: 0, etsy: 0 };
    for (const line of lines) totals[line.destination] += line.unitPrice * line.quantity;
    return totals;
  }, [lines]);

  return (
    <CartContext.Provider value={{ lines, addLine, removeLine, updateQuantity, clearDestination, count, subtotalByDestination }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used within CartProvider");
  return ctx;
}
