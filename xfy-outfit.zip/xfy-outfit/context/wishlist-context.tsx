"use client";

import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export interface WishlistItem {
  productId: string;
  slug: string;
  name: string;
  brandName: string;
  image: string;
  price: number;
  salePrice: number | null;
  inStock: boolean;
}

interface WishlistContextValue {
  items: WishlistItem[];
  toggle: (item: WishlistItem) => void;
  remove: (productId: string) => void;
  has: (productId: string) => boolean;
}

const WishlistContext = createContext<WishlistContextValue | null>(null);
const STORAGE_KEY = "xfy_wishlist_v1";

export function WishlistProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<WishlistItem[]>([]);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setItems(JSON.parse(raw));
    } catch {
      // ignore
    } finally {
      setHydrated(true);
    }
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    } catch {
      // ignore
    }
  }, [items, hydrated]);

  const has = (productId: string) => items.some((i) => i.productId === productId);

  const toggle = (item: WishlistItem) =>
    setItems((prev) => (prev.some((i) => i.productId === item.productId) ? prev.filter((i) => i.productId !== item.productId) : [...prev, item]));

  const remove = (productId: string) => setItems((prev) => prev.filter((i) => i.productId !== productId));

  return <WishlistContext.Provider value={{ items, toggle, remove, has }}>{children}</WishlistContext.Provider>;
}

export function useWishlist() {
  const ctx = useContext(WishlistContext);
  if (!ctx) throw new Error("useWishlist must be used within WishlistProvider");
  return ctx;
}
