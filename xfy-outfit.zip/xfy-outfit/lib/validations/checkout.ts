import { z } from "zod";

export const checkoutSchema = z.object({
  full_name: z.string().min(2, "Enter your full name"),
  email: z.string().email("Enter a valid email"),
  phone: z.string().min(8, "Enter a valid phone number"),
  address_line: z.string().min(5, "Enter your street address"),
  city: z.string().min(2, "Enter your city"),
  province: z.string().min(2, "Enter your province"),
  postal_code: z.string().min(4, "Enter your postal code"),
  country: z.string().default("Indonesia"),
  shipping_method: z.enum(["standard", "express"]),
  payment_method: z.enum(["bank_transfer", "e_wallet", "cod"]),
  agree_terms: z.literal(true, { errorMap: () => ({ message: "You must agree to the terms" }) }),
  notes: z.string().optional(),
});

export type CheckoutInput = z.infer<typeof checkoutSchema>;

export const brandSubmissionSchema = z.object({
  brand_name: z.string().min(2, "Brand name is required"),
  contact_name: z.string().min(2, "Your name is required"),
  email: z.string().email("Enter a valid email"),
  instagram_url: z.string().url().optional().or(z.literal("")),
  website_url: z.string().url().optional().or(z.literal("")),
  city: z.string().optional(),
  style_description: z.string().min(20, "Tell us a bit more (20+ characters)"),
});
