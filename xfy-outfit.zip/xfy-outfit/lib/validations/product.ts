import { z } from "zod";

export const productSchema = z.object({
  name: z.string().min(2, "Product name is required"),
  slug: z
    .string()
    .min(2, "Slug is required")
    .regex(/^[a-z0-9-]+$/, "Use lowercase letters, numbers, and hyphens only"),
  brand_id: z.string().uuid("Select a brand"),
  category: z.string().min(1, "Select a category"),
  style: z.string().min(1, "Select a style"),
  description: z.string().optional(),
  curation_note: z.string().optional(),
  price: z.coerce.number().positive("Price must be greater than 0"),
  sale_price: z.coerce.number().nonnegative().optional().nullable(),
  currency: z.string().default("IDR"),
  material: z.string().optional(),
  fit: z.string().optional(),
  origin: z.string().optional(),
  condition: z.string().optional(),
  sku: z.string().optional(),
  stock: z.coerce.number().int().nonnegative(),
  featured: z.coerce.boolean().default(false),
  xfy_selected: z.coerce.boolean().default(false),
  status: z.enum(["draft", "review", "published", "archived"]),
  shopee_url: z.string().url("Enter a valid URL").optional().or(z.literal("")),
  etsy_url: z.string().url("Enter a valid URL").optional().or(z.literal("")),
});

export type ProductFormInput = z.infer<typeof productSchema>;
