import { z } from "zod";

export const brandSchema = z.object({
  name: z.string().min(2, "Brand name is required"),
  slug: z.string().min(2).regex(/^[a-z0-9-]+$/, "Use lowercase letters, numbers, and hyphens only"),
  description: z.string().optional(),
  story: z.string().optional(),
  logo_url: z.string().url().optional().or(z.literal("")),
  cover_image_url: z.string().url().optional().or(z.literal("")),
  location: z.string().optional(),
  founded_year: z.coerce.number().int().optional().nullable(),
  website_url: z.string().url().optional().or(z.literal("")),
  instagram_url: z.string().url().optional().or(z.literal("")),
  tiktok_url: z.string().url().optional().or(z.literal("")),
  style_tags: z.string().optional(), // comma separated in the form, split before insert
  is_featured: z.coerce.boolean().default(false),
  status: z.enum(["draft", "published", "archived"]),
});
