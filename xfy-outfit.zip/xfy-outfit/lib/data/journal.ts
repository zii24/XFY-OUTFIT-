import { createClient } from "@/lib/supabase/server";
import type { JournalArticle } from "@/types/journal";

export async function getPublishedArticles(limit?: number): Promise<JournalArticle[]> {
  const supabase = await createClient();
  let query = supabase
    .from("journal_articles")
    .select("*")
    .eq("status", "published")
    .order("published_at", { ascending: false });
  if (limit) query = query.limit(limit);

  const { data, error } = await query;
  if (error) {
    console.error("getPublishedArticles:", error.message);
    return [];
  }
  return data ?? [];
}

export async function getArticleBySlug(slug: string): Promise<JournalArticle | null> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("journal_articles")
    .select("*")
    .eq("slug", slug)
    .eq("status", "published")
    .maybeSingle();
  if (error) return null;
  return data;
}

export async function getAllArticlesForAdmin(): Promise<JournalArticle[]> {
  const supabase = await createClient();
  const { data, error } = await supabase.from("journal_articles").select("*").order("updated_at", { ascending: false });
  if (error) return [];
  return data ?? [];
}
