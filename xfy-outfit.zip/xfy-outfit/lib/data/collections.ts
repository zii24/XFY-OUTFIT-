import { createClient } from "@/lib/supabase/server";
import type { Collection } from "@/types/collection";
import type { ProductWithBrand } from "@/types/product";

export async function getPublishedCollections(): Promise<Collection[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("collections")
    .select("*")
    .eq("status", "published")
    .order("sort_order", { ascending: true });

  if (error) {
    console.error("getPublishedCollections:", error.message);
    return [];
  }
  return data ?? [];
}

export async function getCollectionBySlug(slug: string): Promise<Collection | null> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("collections")
    .select("*")
    .eq("slug", slug)
    .eq("status", "published")
    .maybeSingle();

  if (error) return null;
  return data;
}

export async function getCollectionProducts(collectionId: string): Promise<ProductWithBrand[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("collection_products")
    .select(
      `sort_order, product:products ( *, brand:brands ( id, name, slug, location, logo_url ), images:product_images ( * ), variants:product_variants ( * ) )`
    )
    .eq("collection_id", collectionId)
    .order("sort_order", { ascending: true });

  if (error) {
    console.error("getCollectionProducts:", error.message);
    return [];
  }
  return (data ?? [])
    .map((row) => row.product)
    .filter((p): p is any => !!p && p.status === "published") as ProductWithBrand[];
}

export async function getAllCollectionsForAdmin(): Promise<Collection[]> {
  const supabase = await createClient();
  const { data, error } = await supabase.from("collections").select("*").order("sort_order", { ascending: true });
  if (error) return [];
  return data ?? [];
}
