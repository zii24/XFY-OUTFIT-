import { createClient } from "@/lib/supabase/server";

export interface HomepageSettings {
  hero_title: string;
  hero_subtitle: string;
  hero_image_url: string;
  hero_cta_label: string;
  hero_cta_href: string;
  hero_secondary_cta_label: string;
  hero_secondary_cta_href: string;
  announcement_text: string;
  announcement_enabled: boolean;
}

const DEFAULTS: HomepageSettings = {
  hero_title: "Discover Independent Fashion from Indonesia.",
  hero_subtitle: "Find unique pieces, emerging labels, and fashion brands worth discovering.",
  hero_image_url: "https://picsum.photos/seed/xfy-hero/1600/2000",
  hero_cta_label: "Explore Collection",
  hero_cta_href: "/shop",
  hero_secondary_cta_label: "Discover Brands",
  hero_secondary_cta_href: "/brands",
  announcement_text: "Discover independent fashion from Indonesia.",
  announcement_enabled: true,
};

/** Single-row site_settings table. Falls back to sensible defaults if unset. */
export async function getHomepageSettings(): Promise<HomepageSettings> {
  const supabase = await createClient();
  const { data, error } = await supabase.from("site_settings").select("*").eq("id", 1).maybeSingle();
  if (error || !data) return DEFAULTS;
  return { ...DEFAULTS, ...data };
}
