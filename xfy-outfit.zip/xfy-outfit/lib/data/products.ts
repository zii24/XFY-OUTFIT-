import { createClient } from "@/lib/supabase/server";
import type { Product, ProductFilters, ProductWithBrand } from "@/types/product";

const PRODUCT_SELECT = `
  *,
  brand:brands ( id, name, slug, location, logo_url ),
  images:product_images ( id, product_id, image_url, alt_text, sort_order ),
  variants:product_variants ( id, product_id, type, name, value, stock )
`;

/** Published products only — this is what every public page must use. */
export async function getPublishedProducts(filters: ProductFilters = {}): Promise<ProductWithBrand[]> {
  const supabase = await createClient();
  let query = supabase.from("products").select(PRODUCT_SELECT).eq("status", "published");

  if (filters.category) query = query.eq("category", filters.category);
  if (filters.style) query = query.eq("style", filters.style);
  if (filters.brand) query = query.eq("brand.slug", filters.brand);
  if (filters.xfySelected) query = query.eq("xfy_selected", true);
  if (filters.availability === "in-stock") query = query.gt("stock", 0);
  if (typeof filters.minPrice === "number") query = query.gte("price", filters.minPrice);
  if (typeof filters.maxPrice === "number") query = query.lte("price", filters.maxPrice);
  if (filters.q) query = query.ilike("name", `%${filters.q}%`);

  switch (filters.sort) {
    case "newest":
      query = query.order("created_at", { ascending: false });
      break;
    case "price-asc":
      query = query.order("price", { ascending: true });
      break;
    case "price-desc":
      query = query.order("price", { ascending: false });
      break;
    default:
      query = query.order("featured", { ascending: false }).order("created_at", { ascending: false });
  }

  const { data, error } = await query;
  if (error) {
    console.error("getPublishedProducts:", error.message);
    return [];
  }
  return (data ?? []) as unknown as ProductWithBrand[];
}

export async function getProductBySlug(slug: string): Promise<ProductWithBrand | null> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("products")
    .select(PRODUCT_SELECT)
    .eq("slug", slug)
    .eq("status", "published")
    .maybeSingle();

  if (error) {
    console.error("getProductBySlug:", error.message);
    return null;
  }
  return data as unknown as ProductWithBrand | null;
}

export async function getFeaturedProducts(limit = 8): Promise<ProductWithBrand[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("products")
    .select(PRODUCT_SELECT)
    .eq("status", "published")
    .eq("featured", true)
    .order("created_at", { ascending: false })
    .limit(limit);

  if (error) {
    console.error("getFeaturedProducts:", error.message);
    return [];
  }
  return (data ?? []) as unknown as ProductWithBrand[];
}

export async function getRelatedProducts(product: Product, limit = 4): Promise<ProductWithBrand[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("products")
    .select(PRODUCT_SELECT)
    .eq("status", "published")
    .eq("category", product.category)
    .neq("id", product.id)
    .limit(limit);

  if (error) return [];
  return (data ?? []) as unknown as ProductWithBrand[];
}

/** Admin-only: all statuses, for the admin product table. Relies on RLS — only an authenticated admin_users row can read drafts. */
export async function getAllProductsForAdmin() {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("products")
    .select(`*, brand:brands ( id, name )`)
    .order("updated_at", { ascending: false });

  if (error) {
    console.error("getAllProductsForAdmin:", error.message);
    return [];
  }
  return data ?? [];
}

export async function getProductByIdForAdmin(id: string) {
  const supabase = await createClient();
  const { data, error } = await supabase.from("products").select(PRODUCT_SELECT).eq("id", id).maybeSingle();
  if (error) {
    console.error("getProductByIdForAdmin:", error.message);
    return null;
  }
  return data as unknown as ProductWithBrand | null;
}
