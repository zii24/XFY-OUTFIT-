import { createClient } from "@/lib/supabase/server";
import type { Brand } from "@/types/brand";

export async function getPublishedBrands(): Promise<Brand[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("brands")
    .select("*")
    .eq("status", "published")
    .order("is_featured", { ascending: false })
    .order("created_at", { ascending: false });

  if (error) {
    console.error("getPublishedBrands:", error.message);
    return [];
  }
  return data ?? [];
}

export async function getBrandBySlug(slug: string): Promise<Brand | null> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("brands")
    .select("*")
    .eq("slug", slug)
    .eq("status", "published")
    .maybeSingle();

  if (error) {
    console.error("getBrandBySlug:", error.message);
    return null;
  }
  return data;
}

export async function getFeaturedBrands(limit = 4): Promise<Brand[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("brands")
    .select("*")
    .eq("status", "published")
    .order("created_at", { ascending: false })
    .limit(limit);

  if (error) return [];
  return data ?? [];
}

export async function getAllBrandsForAdmin(): Promise<Brand[]> {
  const supabase = await createClient();
  const { data, error } = await supabase.from("brands").select("*").order("updated_at", { ascending: false });
  if (error) {
    console.error("getAllBrandsForAdmin:", error.message);
    return [];
  }
  return data ?? [];
}

export async function getBrandByIdForAdmin(id: string): Promise<Brand | null> {
  const supabase = await createClient();
  const { data, error } = await supabase.from("brands").select("*").eq("id", id).maybeSingle();
  if (error) return null;
  return data;
}
