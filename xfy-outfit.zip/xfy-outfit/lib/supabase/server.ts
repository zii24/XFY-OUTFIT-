import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";

/**
 * Server-side Supabase client for use in Server Components, Route
 * Handlers, and Server Actions. Reads/writes the session cookie so
 * `supabase.auth.getUser()` reflects the logged-in admin.
 *
 * Still uses the anon key — RLS policies decide what it can read/write.
 * The service-role key (if you ever need to bypass RLS for a trusted
 * server job) must only ever be used in a server-only module, never
 * imported by anything with "use client", and never sent to the browser.
 */
export async function createClient() {
  const cookieStore = await cookies();

  return createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return cookieStore.getAll();
        },
        setAll(cookiesToSet) {
          try {
            cookiesToSet.forEach(({ name, value, options }) =>
              cookieStore.set(name, value, options)
            );
          } catch {
            // Called from a Server Component render — safe to ignore because
            // middleware.ts refreshes the session on every request anyway.
          }
        },
      },
    }
  );
}
