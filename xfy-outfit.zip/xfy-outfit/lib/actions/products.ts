"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { productSchema } from "@/lib/validations/product";

export type ActionState = { error?: string; fieldErrors?: Record<string, string> } | undefined;

function parseForm(formData: FormData) {
  const raw = Object.fromEntries(formData.entries());
  return {
    ...raw,
    featured: formData.get("featured") === "on",
    xfy_selected: formData.get("xfy_selected") === "on",
    sale_price: raw.sale_price ? raw.sale_price : null,
  };
}

/** Confirms the current session belongs to a row in admin_users. Every mutation calls this first — never trust the client. */
async function requireAdmin() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error("Not authenticated");

  const { data: adminRow } = await supabase.from("admin_users").select("id").eq("user_id", user.id).maybeSingle();
  if (!adminRow) throw new Error("Not authorized");

  return { supabase, user };
}

export async function createProduct(_prevState: ActionState, formData: FormData): Promise<ActionState> {
  const { supabase } = await requireAdmin();

  const parsed = productSchema.safeParse(parseForm(formData));
  if (!parsed.success) {
    return { error: "Please fix the errors below.", fieldErrors: flattenZod(parsed.error) };
  }

  const { data: product, error } = await supabase.from("products").insert(parsed.data).select("id").single();
  if (error) return { error: error.message };

  // Optional image URLs, one per line, from a textarea field
  const imageUrls = (formData.get("image_urls") as string | null)?.split("\n").map((s) => s.trim()).filter(Boolean) ?? [];
  if (imageUrls.length) {
    await supabase.from("product_images").insert(
      imageUrls.map((url, i) => ({ product_id: product.id, image_url: url, alt_text: parsed.data.name, sort_order: i }))
    );
  }

  // Collection assignment, checkboxes named collection_ids
  const collectionIds = formData.getAll("collection_ids") as string[];
  if (collectionIds.length) {
    await supabase.from("collection_products").insert(
      collectionIds.map((cid, i) => ({ collection_id: cid, product_id: product.id, sort_order: i }))
    );
  }

  revalidatePath("/admin/products");
  revalidatePath("/shop");
  redirect("/admin/products");
}

export async function updateProduct(id: string, _prevState: ActionState, formData: FormData): Promise<ActionState> {
  const { supabase } = await requireAdmin();

  const parsed = productSchema.safeParse(parseForm(formData));
  if (!parsed.success) {
    return { error: "Please fix the errors below.", fieldErrors: flattenZod(parsed.error) };
  }

  const { error } = await supabase.from("products").update(parsed.data).eq("id", id);
  if (error) return { error: error.message };

  const imageUrls = (formData.get("image_urls") as string | null)?.split("\n").map((s) => s.trim()).filter(Boolean) ?? [];
  await supabase.from("product_images").delete().eq("product_id", id);
  if (imageUrls.length) {
    await supabase
      .from("product_images")
      .insert(imageUrls.map((url, i) => ({ product_id: id, image_url: url, alt_text: parsed.data.name, sort_order: i })));
  }

  const collectionIds = formData.getAll("collection_ids") as string[];
  await supabase.from("collection_products").delete().eq("product_id", id);
  if (collectionIds.length) {
    await supabase
      .from("collection_products")
      .insert(collectionIds.map((cid, i) => ({ collection_id: cid, product_id: id, sort_order: i })));
  }

  revalidatePath("/admin/products");
  revalidatePath(`/product/${parsed.data.slug}`);
  revalidatePath("/shop");
  redirect("/admin/products");
}

export async function archiveProduct(id: string) {
  const { supabase } = await requireAdmin();
  const { error } = await supabase.from("products").update({ status: "archived" }).eq("id", id);
  if (error) throw new Error(error.message);
  revalidatePath("/admin/products");
  revalidatePath("/shop");
}

export async function deleteProduct(id: string) {
  const { supabase } = await requireAdmin();
  const { error } = await supabase.from("products").delete().eq("id", id);
  if (error) throw new Error(error.message);
  revalidatePath("/admin/products");
}

// Shared helper so form actions can surface field-level errors
export function flattenZod(error: import("zod").ZodError) {
  const fieldErrors: Record<string, string> = {};
  for (const issue of error.issues) {
    const key = issue.path.join(".");
    if (!fieldErrors[key]) fieldErrors[key] = issue.message;
  }
  return fieldErrors;
}
