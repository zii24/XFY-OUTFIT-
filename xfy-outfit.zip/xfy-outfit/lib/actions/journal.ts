"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { slugify } from "@/lib/utils";

async function requireAdmin() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error("Not authenticated");
  const { data: adminRow } = await supabase.from("admin_users").select("id").eq("user_id", user.id).maybeSingle();
  if (!adminRow) throw new Error("Not authorized");
  return { supabase };
}

export async function createArticle(formData: FormData) {
  const { supabase } = await requireAdmin();
  const title = String(formData.get("title") ?? "");
  const status = String(formData.get("status") ?? "draft");
  const { error } = await supabase.from("journal_articles").insert({
    title,
    slug: slugify(title),
    excerpt: formData.get("excerpt") || null,
    cover_image_url: formData.get("cover_image_url") || null,
    body_markdown: formData.get("body_markdown") || null,
    status,
    published_at: status === "published" ? new Date().toISOString() : null,
  });
  if (error) throw new Error(error.message);
  revalidatePath("/admin/journal");
  revalidatePath("/journal");
  redirect("/admin/journal");
}

export async function updateArticle(id: string, formData: FormData) {
  const { supabase } = await requireAdmin();
  const status = String(formData.get("status") ?? "draft");
  const { error } = await supabase
    .from("journal_articles")
    .update({
      title: formData.get("title"),
      excerpt: formData.get("excerpt") || null,
      cover_image_url: formData.get("cover_image_url") || null,
      body_markdown: formData.get("body_markdown") || null,
      status,
    })
    .eq("id", id);
  if (error) throw new Error(error.message);
  revalidatePath("/admin/journal");
  revalidatePath("/journal");
  redirect("/admin/journal");
}
