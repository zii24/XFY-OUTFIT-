"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { checkoutSchema } from "@/lib/validations/checkout";
import { generateOrderNumber } from "@/lib/utils";
import type { CartLine } from "@/types/order";
import type { OrderStatus, PaymentStatus, ShippingStatus } from "@/types/order";

export type CheckoutState = { error?: string; fieldErrors?: Record<string, string>; orderNumber?: string } | undefined;

const SHIPPING_RATES: Record<string, number> = { standard: 15000, express: 35000 };

/**
 * Creates an order for XFY-checkout cart lines only. Shopee/Etsy lines
 * never reach this action — they're external links handled entirely
 * client-side (see CheckoutOptions / cart page). Every price is re-read
 * from `lines` as submitted by the client for the summary, but the
 * server is the source of truth for totals: it does NOT trust a
 * client-supplied total, it recomputes subtotal/shipping/total itself.
 */
export async function createOrder(
  lines: CartLine[],
  _prevState: CheckoutState,
  formData: FormData
): Promise<CheckoutState> {
  const raw = Object.fromEntries(formData.entries());
  const parsed = checkoutSchema.safeParse({ ...raw, agree_terms: formData.get("agree_terms") === "on" });

  if (!parsed.success) {
    const fieldErrors: Record<string, string> = {};
    for (const issue of parsed.error.issues) fieldErrors[issue.path.join(".")] = issue.message;
    return { error: "Please check the form for errors.", fieldErrors };
  }

  const xfyLines = lines.filter((l) => l.destination === "xfy");
  if (xfyLines.length === 0) {
    return { error: "Your cart has no items available for XFY checkout." };
  }

  const supabase = await createClient();

  // Server-side stock + price validation — never trust cart values from the client.
  const productIds = xfyLines.map((l) => l.productId);
  const { data: dbProducts, error: fetchError } = await supabase
    .from("products")
    .select("id, name, price, sale_price, stock, status, brand:brands(name)")
    .in("id", productIds);

  if (fetchError || !dbProducts) return { error: "Could not verify products. Please try again." };

  for (const line of xfyLines) {
    const dbProduct = dbProducts.find((p) => p.id === line.productId);
    if (!dbProduct || dbProduct.status !== "published") {
      return { error: `"${line.name}" is no longer available.` };
    }
    if (dbProduct.stock < line.quantity) {
      return { error: `Only ${dbProduct.stock} left of "${line.name}". Please update your cart.` };
    }
  }

  const verifiedLines = xfyLines.map((line) => {
    const dbProduct = dbProducts.find((p) => p.id === line.productId)!;
    const unitPrice = dbProduct.sale_price ?? dbProduct.price;
    return { line, dbProduct, unitPrice };
  });

  const subtotal = verifiedLines.reduce((sum, v) => sum + v.unitPrice * v.line.quantity, 0);
  const shippingCost = SHIPPING_RATES[parsed.data.shipping_method] ?? 15000;
  const total = subtotal + shippingCost;

  const { data: customer, error: customerError } = await supabase
    .from("customers")
    .upsert({ email: parsed.data.email, name: parsed.data.full_name, phone: parsed.data.phone }, { onConflict: "email" })
    .select("id")
    .single();

  if (customerError || !customer) return { error: "Could not save your details. Please try again." };

  const orderNumber = generateOrderNumber();
  const paymentStatus: PaymentStatus = parsed.data.payment_method === "cod" ? "pending_manual" : "awaiting_payment";

  const { data: order, error: orderError } = await supabase
    .from("orders")
    .insert({
      order_number: orderNumber,
      customer_id: customer.id,
      status: "pending" satisfies OrderStatus,
      payment_status: paymentStatus,
      shipping_status: "not_shipped" satisfies ShippingStatus,
      subtotal,
      shipping_cost: shippingCost,
      total,
      currency: "IDR",
      shipping_address: {
        full_name: parsed.data.full_name,
        phone: parsed.data.phone,
        address_line: parsed.data.address_line,
        city: parsed.data.city,
        province: parsed.data.province,
        postal_code: parsed.data.postal_code,
        country: parsed.data.country,
      },
      notes: parsed.data.notes ?? null,
    })
    .select("id, order_number")
    .single();

  if (orderError || !order) return { error: "Could not create your order. Please try again." };

  const { error: itemsError } = await supabase.from("order_items").insert(
    verifiedLines.map(({ line, dbProduct, unitPrice }) => ({
      order_id: order.id,
      product_id: line.productId,
      product_name_snapshot: dbProduct.name,
      brand_name_snapshot: (dbProduct as any).brand?.name ?? "XFY Outfit",
      quantity: line.quantity,
      unit_price: unitPrice,
      variant_snapshot: line.variant,
    }))
  );

  if (itemsError) return { error: "Could not save order items. Please contact support." };

  // Decrement stock. In a high-traffic app this belongs in a DB function/transaction;
  // documented as a known simplification for V1 (see README "Known limitations").
  for (const { line, dbProduct } of verifiedLines) {
    await supabase.from("products").update({ stock: dbProduct.stock - line.quantity }).eq("id", line.productId);
  }

  revalidatePath("/admin/orders");
  return { orderNumber: order.order_number };
}

export async function updateOrderStatus(id: string, fields: Partial<{ status: OrderStatus; payment_status: PaymentStatus; shipping_status: ShippingStatus }>) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error("Not authenticated");

  const { error } = await supabase.from("orders").update(fields).eq("id", id);
  if (error) throw new Error(error.message);
  revalidatePath("/admin/orders");
}
