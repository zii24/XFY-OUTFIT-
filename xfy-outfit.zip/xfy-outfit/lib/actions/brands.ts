"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { brandSchema } from "@/lib/validations/brand";
import { flattenZod, type ActionState } from "./products";

async function requireAdmin() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) throw new Error("Not authenticated");
  const { data: adminRow } = await supabase.from("admin_users").select("id").eq("user_id", user.id).maybeSingle();
  if (!adminRow) throw new Error("Not authorized");
  return { supabase };
}

function parseForm(formData: FormData) {
  const raw = Object.fromEntries(formData.entries());
  return { ...raw, is_featured: formData.get("is_featured") === "on" };
}

export async function createBrand(_prevState: ActionState, formData: FormData): Promise<ActionState> {
  const { supabase } = await requireAdmin();
  const parsed = brandSchema.safeParse(parseForm(formData));
  if (!parsed.success) return { error: "Please fix the errors below.", fieldErrors: flattenZod(parsed.error) };

  const { style_tags, ...rest } = parsed.data;
  const { error } = await supabase.from("brands").insert({
    ...rest,
    style_tags: style_tags ? style_tags.split(",").map((s) => s.trim()).filter(Boolean) : [],
  });
  if (error) return { error: error.message };

  revalidatePath("/admin/brands");
  revalidatePath("/brands");
  redirect("/admin/brands");
}

export async function updateBrand(id: string, _prevState: ActionState, formData: FormData): Promise<ActionState> {
  const { supabase } = await requireAdmin();
  const parsed = brandSchema.safeParse(parseForm(formData));
  if (!parsed.success) return { error: "Please fix the errors below.", fieldErrors: flattenZod(parsed.error) };

  const { style_tags, ...rest } = parsed.data;
  const { error } = await supabase
    .from("brands")
    .update({ ...rest, style_tags: style_tags ? style_tags.split(",").map((s) => s.trim()).filter(Boolean) : [] })
    .eq("id", id);
  if (error) return { error: error.message };

  revalidatePath("/admin/brands");
  revalidatePath(`/brands/${parsed.data.slug}`);
  redirect("/admin/brands");
}

export async function archiveBrand(id: string) {
  const { supabase } = await requireAdmin();
  const { error } = await supabase.from("brands").update({ status: "archived" }).eq("id", id);
  if (error) throw new Error(error.message);
  revalidatePath("/admin/brands");
  revalidatePath("/brands");
}
