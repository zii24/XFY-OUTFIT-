"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { slugify } from "@/lib/utils";

async function requireAdmin() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error("Not authenticated");
  const { data: adminRow } = await supabase.from("admin_users").select("id").eq("user_id", user.id).maybeSingle();
  if (!adminRow) throw new Error("Not authorized");
  return { supabase };
}

export async function createCollection(formData: FormData) {
  const { supabase } = await requireAdmin();
  const name = String(formData.get("name") ?? "");
  const { error } = await supabase.from("collections").insert({
    name,
    slug: slugify(name),
    description: formData.get("description") || null,
    cover_image_url: formData.get("cover_image_url") || null,
    status: formData.get("status") || "draft",
    sort_order: Number(formData.get("sort_order") ?? 0),
  });
  if (error) throw new Error(error.message);
  revalidatePath("/admin/collections");
  revalidatePath("/collections");
  redirect("/admin/collections");
}

export async function updateCollection(id: string, formData: FormData) {
  const { supabase } = await requireAdmin();
  const { error } = await supabase
    .from("collections")
    .update({
      name: formData.get("name"),
      description: formData.get("description") || null,
      cover_image_url: formData.get("cover_image_url") || null,
      status: formData.get("status") || "draft",
      sort_order: Number(formData.get("sort_order") ?? 0),
    })
    .eq("id", id);
  if (error) throw new Error(error.message);
  revalidatePath("/admin/collections");
  revalidatePath("/collections");
  redirect("/admin/collections");
}

export async function archiveCollection(id: string) {
  const { supabase } = await requireAdmin();
  await supabase.from("collections").update({ status: "archived" }).eq("id", id);
  revalidatePath("/admin/collections");
}
