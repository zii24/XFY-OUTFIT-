"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";

async function requireAdmin() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error("Not authenticated");
  const { data: adminRow } = await supabase.from("admin_users").select("id").eq("user_id", user.id).maybeSingle();
  if (!adminRow) throw new Error("Not authorized");
  return { supabase };
}

export async function updateHomepageSettings(formData: FormData) {
  const { supabase } = await requireAdmin();
  const { error } = await supabase.from("site_settings").upsert({
    id: 1,
    hero_title: formData.get("hero_title"),
    hero_subtitle: formData.get("hero_subtitle"),
    hero_image_url: formData.get("hero_image_url"),
    hero_cta_label: formData.get("hero_cta_label"),
    hero_cta_href: formData.get("hero_cta_href"),
    hero_secondary_cta_label: formData.get("hero_secondary_cta_label"),
    hero_secondary_cta_href: formData.get("hero_secondary_cta_href"),
    announcement_text: formData.get("announcement_text"),
    announcement_enabled: formData.get("announcement_enabled") === "on",
  });
  if (error) throw new Error(error.message);
  revalidatePath("/");
  revalidatePath("/admin/homepage");
}
