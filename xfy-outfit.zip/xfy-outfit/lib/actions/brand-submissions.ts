"use server";

import { createClient } from "@/lib/supabase/server";
import { brandSubmissionSchema } from "@/lib/validations/checkout";

export type SubmitBrandState = { error?: string; fieldErrors?: Record<string, string>; success?: boolean } | undefined;

export async function submitBrand(_prevState: SubmitBrandState, formData: FormData): Promise<SubmitBrandState> {
  const raw = Object.fromEntries(formData.entries());
  const parsed = brandSubmissionSchema.safeParse(raw);
  if (!parsed.success) {
    const fieldErrors: Record<string, string> = {};
    for (const issue of parsed.error.issues) fieldErrors[issue.path.join(".")] = issue.message;
    return { error: "Please check the form for errors.", fieldErrors };
  }

  const supabase = await createClient();
  const { error } = await supabase.from("brand_submissions").insert({
    brand_name: parsed.data.brand_name,
    contact_name: parsed.data.contact_name,
    email: parsed.data.email,
    instagram_url: parsed.data.instagram_url || null,
    website_url: parsed.data.website_url || null,
    city: parsed.data.city || null,
    style_description: parsed.data.style_description,
    status: "new",
  });

  if (error) return { error: "Something went wrong submitting your brand. Please try again." };
  return { success: true };
}
