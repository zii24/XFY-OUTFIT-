export const CATEGORIES = [
  { slug: "tops", name: "Tops" },
  { slug: "outerwear", name: "Outerwear" },
  { slug: "bottoms", name: "Bottoms" },
  { slug: "dresses", name: "Dresses" },
  { slug: "accessories", name: "Accessories" },
] as const;

export const STYLES = [
  { slug: "streetwear", name: "Streetwear" },
  { slug: "minimal", name: "Minimal" },
  { slug: "vintage", name: "Vintage" },
  { slug: "y2k", name: "Y2K" },
  { slug: "workwear", name: "Workwear" },
] as const;

export const SIZES = ["XS", "S", "M", "L", "XL"] as const;

export const COLORS = [
  { name: "Black", value: "#111111" },
  { name: "White", value: "#FFFFFF" },
  { name: "Navy", value: "#0F172A" },
  { name: "Sand", value: "#D9C9AE" },
  { name: "Sage", value: "#8A9A80" },
] as const;

export const SORT_OPTIONS = [
  { value: "featured", label: "Featured" },
  { value: "newest", label: "Newest" },
  { value: "price-asc", label: "Price: Low to High" },
  { value: "price-desc", label: "Price: High to Low" },
  { value: "popular", label: "Most Popular" },
] as const;

export const NAV_LINKS = [
  { href: "/shop", label: "Shop" },
  { href: "/brands", label: "Brands" },
  { href: "/collections", label: "Collections" },
  { href: "/journal", label: "Journal" },
  { href: "/about", label: "About" },
] as const;

export const SITE_NAME = "XFY Outfit";
export const SITE_DESCRIPTION =
  "Discover unique fashion pieces and emerging independent brands through XFY Outfit.";
