export type OrderStatus = "pending" | "confirmed" | "processing" | "shipped" | "delivered" | "cancelled";
export type PaymentStatus = "pending_manual" | "awaiting_payment" | "paid" | "failed" | "refunded";
export type ShippingStatus = "not_shipped" | "packed" | "shipped" | "delivered";

export interface ShippingAddress {
  full_name: string;
  phone: string;
  address_line: string;
  city: string;
  province: string;
  postal_code: string;
  country: string;
}

export interface Customer {
  id: string;
  email: string;
  name: string;
  phone: string | null;
  created_at: string;
}

export interface OrderItem {
  id: string;
  order_id: string;
  product_id: string | null;
  product_name_snapshot: string;
  brand_name_snapshot: string;
  quantity: number;
  unit_price: number;
  variant_snapshot: string | null;
}

export interface Order {
  id: string;
  order_number: string;
  customer_id: string;
  status: OrderStatus;
  payment_status: PaymentStatus;
  shipping_status: ShippingStatus;
  subtotal: number;
  shipping_cost: number;
  total: number;
  currency: string;
  shipping_address: ShippingAddress;
  notes: string | null;
  created_at: string;
  updated_at: string;
  customer?: Customer;
  items?: OrderItem[];
}

// Cart lives client-side (localStorage) — this is not a DB table.
export type CheckoutDestination = "xfy" | "shopee" | "etsy";

export interface CartLine {
  id: string; // productId + variant key, for uniqueness
  productId: string;
  slug: string;
  name: string;
  brandName: string;
  image: string;
  unitPrice: number;
  quantity: number;
  variant: string | null;
  destination: CheckoutDestination;
  externalUrl: string | null; // required when destination !== "xfy"
  maxStock: number;
}
