export type BrandStatus = "draft" | "published" | "archived";

export interface Brand {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  story: string | null;
  logo_url: string | null;
  cover_image_url: string | null;
  location: string | null;
  founded_year: number | null;
  website_url: string | null;
  instagram_url: string | null;
  tiktok_url: string | null;
  style_tags: string[] | null;
  is_featured: boolean;
  status: BrandStatus;
  created_at: string;
  updated_at: string;
}

export interface BrandSubmission {
  id: string;
  brand_name: string;
  contact_name: string;
  email: string;
  instagram_url: string | null;
  website_url: string | null;
  city: string | null;
  style_description: string;
  status: "new" | "reviewing" | "approved" | "declined";
  created_at: string;
}
