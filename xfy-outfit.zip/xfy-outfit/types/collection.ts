export type CollectionStatus = "draft" | "published" | "archived";

export interface Collection {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  cover_image_url: string | null;
  status: CollectionStatus;
  sort_order: number;
  created_at: string;
  updated_at: string;
}
