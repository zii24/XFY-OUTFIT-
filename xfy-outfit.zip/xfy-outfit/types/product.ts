export type ProductStatus = "draft" | "review" | "published" | "archived";

export interface ProductImage {
  id: string;
  product_id: string;
  image_url: string;
  alt_text: string | null;
  sort_order: number;
}

export interface ProductVariant {
  id: string;
  product_id: string;
  type: "size" | "color";
  name: string;
  value: string;
  stock: number;
}

export interface Product {
  id: string;
  brand_id: string;
  name: string;
  slug: string;
  description: string | null;
  curation_note: string | null;
  price: number;
  sale_price: number | null;
  currency: string;
  category: string;
  style: string;
  material: string | null;
  fit: string | null;
  origin: string | null;
  condition: string | null;
  sku: string | null;
  stock: number;
  featured: boolean;
  xfy_selected: boolean;
  status: ProductStatus;
  shopee_url: string | null;
  etsy_url: string | null;
  created_at: string;
  updated_at: string;
  // Joined at query time
  images?: ProductImage[];
  variants?: ProductVariant[];
  brand?: { id: string; name: string; slug: string; location: string | null; logo_url: string | null };
}

export interface ProductWithBrand extends Product {
  brand: { id: string; name: string; slug: string; location: string | null; logo_url: string | null };
}

export interface ProductFilters {
  category?: string;
  style?: string;
  brand?: string;
  size?: string;
  color?: string;
  minPrice?: number;
  maxPrice?: number;
  xfySelected?: boolean;
  availability?: "in-stock" | "all";
  sort?: "featured" | "newest" | "price-asc" | "price-desc" | "popular";
  q?: string;
}
