import Link from "next/link";
import { Button } from "@/components/ui/button";

// Rendered inside the root layout (app/layout.tsx already provides <html>/<body>).
export default function NotFound() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-white px-4 text-center">
      <p className="font-display text-sm font-medium text-xfy-blue">404</p>
      <h1 className="mt-2 font-display text-2xl font-bold text-xfy-black">Page not found.</h1>
      <p className="mt-2 max-w-sm text-sm text-xfy-gray-500">The page you&apos;re looking for doesn&apos;t exist or may have moved.</p>
      <Link href="/">
        <Button variant="accent" size="lg" className="mt-6">Back to home</Button>
      </Link>
    </div>
  );
}
