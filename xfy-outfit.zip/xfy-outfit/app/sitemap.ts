import type { MetadataRoute } from "next";
import { createClient } from "@/lib/supabase/server";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";
  const supabase = await createClient();

  const [{ data: products }, { data: brands }, { data: collections }, { data: articles }] = await Promise.all([
    supabase.from("products").select("slug, updated_at").eq("status", "published"),
    supabase.from("brands").select("slug, updated_at").eq("status", "published"),
    supabase.from("collections").select("slug, updated_at").eq("status", "published"),
    supabase.from("journal_articles").select("slug, updated_at").eq("status", "published"),
  ]);

  const staticRoutes: MetadataRoute.Sitemap = ["", "/shop", "/brands", "/collections", "/journal", "/about", "/submit-brand"].map((path) => ({
    url: `${base}${path}`,
    changeFrequency: "daily",
  }));

  const dynamicRoutes: MetadataRoute.Sitemap = [
    ...(products ?? []).map((p) => ({ url: `${base}/product/${p.slug}`, lastModified: p.updated_at })),
    ...(brands ?? []).map((b) => ({ url: `${base}/brands/${b.slug}`, lastModified: b.updated_at })),
    ...(collections ?? []).map((c) => ({ url: `${base}/collections/${c.slug}`, lastModified: c.updated_at })),
    ...(articles ?? []).map((a) => ({ url: `${base}/journal/${a.slug}`, lastModified: a.updated_at })),
  ];

  return [...staticRoutes, ...dynamicRoutes];
}
