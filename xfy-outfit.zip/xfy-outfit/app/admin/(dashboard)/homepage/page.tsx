import { getHomepageSettings } from "@/lib/data/homepage";
import { updateHomepageSettings } from "@/lib/actions/homepage";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";

export default async function AdminHomepagePage() {
  const settings = await getHomepageSettings();

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-xfy-black">Homepage</h1>
      <p className="mt-1 max-w-lg text-sm text-xfy-gray-500">
        Edit the hero and announcement bar. Featured products, XFY Picks, and Hidden Gems pull automatically from
        products/brands marked &ldquo;Featured&rdquo; — manage those from Products and Brands.
      </p>

      <form action={updateHomepageSettings} className="mt-8 max-w-2xl space-y-8">
        <section className="space-y-5 rounded-xfy border border-xfy-gray-200 bg-white p-6">
          <h2 className="font-display text-lg font-semibold text-xfy-black">Hero</h2>
          <div><Label htmlFor="hero_title">Headline</Label><Input id="hero_title" name="hero_title" defaultValue={settings.hero_title} /></div>
          <div><Label htmlFor="hero_subtitle">Subheadline</Label><Textarea id="hero_subtitle" name="hero_subtitle" rows={2} defaultValue={settings.hero_subtitle} /></div>
          <div><Label htmlFor="hero_image_url">Hero image URL</Label><Input id="hero_image_url" name="hero_image_url" type="url" defaultValue={settings.hero_image_url} /></div>
          <div className="grid grid-cols-2 gap-4">
            <div><Label htmlFor="hero_cta_label">Primary CTA label</Label><Input id="hero_cta_label" name="hero_cta_label" defaultValue={settings.hero_cta_label} /></div>
            <div><Label htmlFor="hero_cta_href">Primary CTA link</Label><Input id="hero_cta_href" name="hero_cta_href" defaultValue={settings.hero_cta_href} /></div>
            <div><Label htmlFor="hero_secondary_cta_label">Secondary CTA label</Label><Input id="hero_secondary_cta_label" name="hero_secondary_cta_label" defaultValue={settings.hero_secondary_cta_label} /></div>
            <div><Label htmlFor="hero_secondary_cta_href">Secondary CTA link</Label><Input id="hero_secondary_cta_href" name="hero_secondary_cta_href" defaultValue={settings.hero_secondary_cta_href} /></div>
          </div>
        </section>

        <section className="space-y-4 rounded-xfy border border-xfy-gray-200 bg-white p-6">
          <h2 className="font-display text-lg font-semibold text-xfy-black">Announcement bar</h2>
          <div><Label htmlFor="announcement_text">Text</Label><Input id="announcement_text" name="announcement_text" defaultValue={settings.announcement_text} /></div>
          <label className="flex items-center gap-2 text-sm text-xfy-black">
            <input type="checkbox" name="announcement_enabled" defaultChecked={settings.announcement_enabled} className="h-4 w-4 rounded border-xfy-gray-300 text-xfy-blue" />
            Show announcement bar
          </label>
        </section>

        <Button type="submit" variant="accent" size="lg">Save homepage</Button>
      </form>
    </div>
  );
}
