import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { Package, Building2, ShoppingCart, FileEdit } from "lucide-react";

async function getCounts() {
  const supabase = await createClient();
  const [{ count: totalProducts }, { count: publishedProducts }, { count: draftProducts }, { count: totalBrands }, { count: totalOrders }] =
    await Promise.all([
      supabase.from("products").select("id", { count: "exact", head: true }),
      supabase.from("products").select("id", { count: "exact", head: true }).eq("status", "published"),
      supabase.from("products").select("id", { count: "exact", head: true }).eq("status", "draft"),
      supabase.from("brands").select("id", { count: "exact", head: true }),
      supabase.from("orders").select("id", { count: "exact", head: true }),
    ]);

  const { data: recentOrders } = await supabase
    .from("orders")
    .select("id, order_number, status, payment_status, total, created_at, customer:customers(name, email)")
    .order("created_at", { ascending: false })
    .limit(5);

  return {
    totalProducts: totalProducts ?? 0,
    publishedProducts: publishedProducts ?? 0,
    draftProducts: draftProducts ?? 0,
    totalBrands: totalBrands ?? 0,
    totalOrders: totalOrders ?? 0,
    recentOrders: recentOrders ?? [],
  };
}

export default async function AdminDashboardPage() {
  const counts = await getCounts();

  const cards = [
    { label: "Total products", value: counts.totalProducts, sub: `${counts.publishedProducts} published · ${counts.draftProducts} draft`, icon: Package, href: "/admin/products" },
    { label: "Total brands", value: counts.totalBrands, sub: "Across all statuses", icon: Building2, href: "/admin/brands" },
    { label: "Total orders", value: counts.totalOrders, sub: "All-time", icon: ShoppingCart, href: "/admin/orders" },
  ];

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-xfy-black">Dashboard</h1>
      <p className="mt-1 text-sm text-xfy-gray-500">Figures below reflect your live Supabase data, not sample numbers.</p>

      <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-3">
        {cards.map((card) => {
          const Icon = card.icon;
          return (
            <Link key={card.label} href={card.href} className="rounded-xfy border border-xfy-gray-200 bg-white p-5 hover:border-xfy-black">
              <div className="flex items-center justify-between">
                <Icon className="h-5 w-5 text-xfy-gray-500" />
              </div>
              <p className="mt-4 text-2xl font-bold text-xfy-black">{card.value}</p>
              <p className="text-sm text-xfy-gray-500">{card.label}</p>
              <p className="mt-1 text-xs text-xfy-gray-400">{card.sub}</p>
            </Link>
          );
        })}
      </div>

      <div className="mt-10 grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Link href="/admin/products/new" className="flex items-center gap-2 rounded-xfy border border-dashed border-xfy-gray-300 p-4 text-sm font-medium text-xfy-black hover:border-xfy-black">
          <FileEdit className="h-4 w-4" /> Add product
        </Link>
        <Link href="/admin/brands/new" className="flex items-center gap-2 rounded-xfy border border-dashed border-xfy-gray-300 p-4 text-sm font-medium text-xfy-black hover:border-xfy-black">
          <FileEdit className="h-4 w-4" /> Add brand
        </Link>
        <Link href="/admin/homepage" className="flex items-center gap-2 rounded-xfy border border-dashed border-xfy-gray-300 p-4 text-sm font-medium text-xfy-black hover:border-xfy-black">
          <FileEdit className="h-4 w-4" /> Edit homepage
        </Link>
      </div>

      <div className="mt-10">
        <h2 className="font-display text-lg font-semibold text-xfy-black">Recent orders</h2>
        <div className="mt-4 overflow-x-auto rounded-xfy border border-xfy-gray-200 bg-white">
          <table className="w-full min-w-[560px] text-left text-sm">
            <thead className="border-b border-xfy-gray-200 text-xs uppercase tracking-wide text-xfy-gray-500">
              <tr>
                <th className="px-4 py-3">Order</th>
                <th className="px-4 py-3">Customer</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3">Payment</th>
                <th className="px-4 py-3 text-right">Total</th>
              </tr>
            </thead>
            <tbody>
              {counts.recentOrders.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-4 py-8 text-center text-xfy-gray-500">No orders yet.</td>
                </tr>
              ) : (
                counts.recentOrders.map((order: any) => (
                  <tr key={order.id} className="border-b border-xfy-gray-100 last:border-0">
                    <td className="px-4 py-3 font-medium text-xfy-black">
                      <Link href="/admin/orders" className="hover:underline">{order.order_number}</Link>
                    </td>
                    <td className="px-4 py-3 text-xfy-gray-700">{order.customer?.name ?? "—"}</td>
                    <td className="px-4 py-3 capitalize text-xfy-gray-700">{order.status}</td>
                    <td className="px-4 py-3 capitalize text-xfy-gray-700">{order.payment_status?.replace("_", " ")}</td>
                    <td className="px-4 py-3 text-right font-medium text-xfy-black">Rp {Number(order.total).toLocaleString("id-ID")}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
