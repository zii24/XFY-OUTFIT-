export default function AdminSettingsPage() {
  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-xfy-black">Settings</h1>
      <p className="mt-1 text-sm text-xfy-gray-500">Account and platform-level configuration.</p>

      <div className="mt-8 max-w-2xl space-y-6">
        <section className="rounded-xfy border border-xfy-gray-200 bg-white p-6">
          <h2 className="font-display text-lg font-semibold text-xfy-black">Admin access</h2>
          <p className="mt-2 text-sm leading-relaxed text-xfy-gray-500">
            Admin accounts are not self-serve in V1 — this is deliberate, not an oversight. To add an admin: create
            the user in Supabase Authentication, then insert a matching row into the <code className="rounded bg-xfy-gray-100 px-1 py-0.5 text-xs">admin_users</code> table
            with their <code className="rounded bg-xfy-gray-100 px-1 py-0.5 text-xs">user_id</code>. See README &ldquo;Admin access&rdquo; for the exact SQL.
          </p>
        </section>

        <section className="rounded-xfy border border-xfy-gray-200 bg-white p-6">
          <h2 className="font-display text-lg font-semibold text-xfy-black">Payments</h2>
          <p className="mt-2 text-sm leading-relaxed text-xfy-gray-500">
            No payment gateway is connected. Orders are created with payment status &ldquo;awaiting payment&rdquo; or
            &ldquo;pending manual&rdquo; and confirmed by hand from the Orders page until Midtrans/Xendit credentials
            are added — see <code className="rounded bg-xfy-gray-100 px-1 py-0.5 text-xs">.env.example</code>.
          </p>
        </section>

        <section className="rounded-xfy border border-dashed border-xfy-gray-300 bg-white p-6">
          <h2 className="font-display text-lg font-semibold text-xfy-gray-500">Team & roles</h2>
          <p className="mt-2 text-sm text-xfy-gray-500">Coming soon — V1 treats every row in admin_users as a full admin. Scoped roles (e.g. content-only) aren&apos;t built yet.</p>
        </section>
      </div>
    </div>
  );
}
