import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { AdminSidebar } from "@/components/admin/sidebar";

export const metadata = { title: { default: "Admin", template: "%s — XFY Admin" }, robots: { index: false, follow: false } };

// Belt-and-braces: middleware.ts already redirects unauthenticated/unauthorized
// requests before they reach here, but this layout re-checks so any route
// added under /admin later is safe even if the middleware matcher is ever
// changed. Real data access is still enforced by RLS on every table.
export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) redirect("/admin/login");

  const { data: adminRow } = await supabase.from("admin_users").select("id").eq("user_id", user.id).maybeSingle();
  if (!adminRow) redirect("/admin/login?error=unauthorized");

  return (
    <div className="flex min-h-screen bg-xfy-gray-50">
      <AdminSidebar email={user.email ?? ""} />
      <div className="flex-1 overflow-x-hidden">
        <div className="mx-auto max-w-6xl px-6 py-8 md:px-10 md:py-10">{children}</div>
      </div>
    </div>
  );
}
