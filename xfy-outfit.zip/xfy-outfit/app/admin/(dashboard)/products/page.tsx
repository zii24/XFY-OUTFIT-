import Link from "next/link";
import { Plus, Search } from "lucide-react";
import { getAllProductsForAdmin } from "@/lib/data/products";
import { archiveProduct } from "@/lib/actions/products";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { formatPrice } from "@/lib/utils";

const STATUS_TONE: Record<string, "status" | "selected" | "soft"> = {
  draft: "status",
  review: "soft",
  published: "selected",
  archived: "status",
};

export default async function AdminProductsPage({ searchParams }: { searchParams: Promise<{ q?: string; status?: string }> }) {
  const { q, status } = await searchParams;
  const allProducts = await getAllProductsForAdmin();

  const filtered = allProducts.filter((p: any) => {
    if (status && p.status !== status) return false;
    if (q && !p.name.toLowerCase().includes(q.toLowerCase())) return false;
    return true;
  });

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-xfy-black">Products</h1>
          <p className="mt-1 text-sm text-xfy-gray-500">{allProducts.length} total</p>
        </div>
        <Link href="/admin/products/new">
          <Button variant="accent"><Plus className="h-4 w-4" /> Add product</Button>
        </Link>
      </div>

      <form className="mt-6 flex flex-wrap gap-3">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-xfy-gray-400" />
          <input
            name="q"
            defaultValue={q}
            placeholder="Search products…"
            className="h-10 w-full rounded-xfy border border-xfy-gray-200 bg-white pl-9 pr-3 text-sm focus:outline-none focus:ring-2 focus:ring-xfy-blue"
          />
        </div>
        <select name="status" defaultValue={status ?? ""} className="h-10 rounded-xfy border border-xfy-gray-200 bg-white px-3 text-sm">
          <option value="">All statuses</option>
          <option value="draft">Draft</option>
          <option value="review">Review</option>
          <option value="published">Published</option>
          <option value="archived">Archived</option>
        </select>
        <Button type="submit" variant="outline">Filter</Button>
      </form>

      <div className="mt-6 overflow-x-auto rounded-xfy border border-xfy-gray-200 bg-white">
        <table className="w-full min-w-[720px] text-left text-sm">
          <thead className="border-b border-xfy-gray-200 text-xs uppercase tracking-wide text-xfy-gray-500">
            <tr>
              <th className="px-4 py-3">Product</th>
              <th className="px-4 py-3">Brand</th>
              <th className="px-4 py-3">Price</th>
              <th className="px-4 py-3">Stock</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr><td colSpan={6} className="px-4 py-10 text-center text-xfy-gray-500">No products match.</td></tr>
            ) : (
              filtered.map((p: any) => (
                <tr key={p.id} className="border-b border-xfy-gray-100 last:border-0">
                  <td className="px-4 py-3 font-medium text-xfy-black">{p.name}</td>
                  <td className="px-4 py-3 text-xfy-gray-700">{p.brand?.name ?? "—"}</td>
                  <td className="px-4 py-3 text-xfy-gray-700">{formatPrice(p.price, p.currency)}</td>
                  <td className="px-4 py-3 text-xfy-gray-700">{p.stock}</td>
                  <td className="px-4 py-3"><Badge tone={STATUS_TONE[p.status] ?? "status"} className="capitalize">{p.status}</Badge></td>
                  <td className="px-4 py-3">
                    <div className="flex justify-end gap-3">
                      <Link href={`/admin/products/${p.id}/edit`} className="text-xfy-blue hover:underline">Edit</Link>
                      {p.status !== "archived" && (
                        <form action={async () => { "use server"; await archiveProduct(p.id); }}>
                          <button type="submit" className="text-xfy-gray-500 hover:text-red-600">Archive</button>
                        </form>
                      )}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
