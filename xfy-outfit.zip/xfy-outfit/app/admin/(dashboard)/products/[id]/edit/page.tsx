import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { ProductForm } from "@/components/admin/product-form";
import { updateProduct } from "@/lib/actions/products";
import { getProductByIdForAdmin } from "@/lib/data/products";
import { getAllBrandsForAdmin } from "@/lib/data/brands";
import { getAllCollectionsForAdmin } from "@/lib/data/collections";
import { createClient } from "@/lib/supabase/server";

interface Props {
  params: Promise<{ id: string }>;
}

export default async function EditProductPage({ params }: Props) {
  const { id } = await params;
  const [product, brands, collections] = await Promise.all([
    getProductByIdForAdmin(id),
    getAllBrandsForAdmin(),
    getAllCollectionsForAdmin(),
  ]);
  if (!product) notFound();

  const supabase = await createClient();
  const { data: assignedCollections } = await supabase.from("collection_products").select("collection_id").eq("product_id", id);

  const boundAction = updateProduct.bind(null, id);

  return (
    <div>
      <Link href="/admin/products" className="mb-6 inline-flex items-center gap-1.5 text-sm text-xfy-gray-500 hover:text-xfy-black">
        <ArrowLeft className="h-4 w-4" /> Back to products
      </Link>
      <h1 className="font-display text-2xl font-bold text-xfy-black">Edit product</h1>
      <div className="mt-6 max-w-2xl">
        <ProductForm
          action={boundAction}
          brands={brands}
          collections={collections}
          product={{ ...product, collection_ids: (assignedCollections ?? []).map((c) => c.collection_id) }}
          submitLabel="Save changes"
        />
      </div>
    </div>
  );
}
