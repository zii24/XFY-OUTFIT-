import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { ProductForm } from "@/components/admin/product-form";
import { createProduct } from "@/lib/actions/products";
import { getAllBrandsForAdmin } from "@/lib/data/brands";
import { getAllCollectionsForAdmin } from "@/lib/data/collections";

export default async function NewProductPage() {
  const [brands, collections] = await Promise.all([getAllBrandsForAdmin(), getAllCollectionsForAdmin()]);

  return (
    <div>
      <Link href="/admin/products" className="mb-6 inline-flex items-center gap-1.5 text-sm text-xfy-gray-500 hover:text-xfy-black">
        <ArrowLeft className="h-4 w-4" /> Back to products
      </Link>
      <h1 className="font-display text-2xl font-bold text-xfy-black">Add product</h1>
      <div className="mt-6 max-w-2xl">
        <ProductForm action={createProduct} brands={brands} collections={collections} submitLabel="Create product" />
      </div>
    </div>
  );
}
