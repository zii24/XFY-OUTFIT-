import { createClient } from "@/lib/supabase/server";
import { updateOrderStatus } from "@/lib/actions/orders";
import { Badge } from "@/components/ui/badge";
import { formatPrice } from "@/lib/utils";
import type { OrderStatus, PaymentStatus, ShippingStatus } from "@/types/order";

const ORDER_STATUSES: OrderStatus[] = ["pending", "confirmed", "processing", "shipped", "delivered", "cancelled"];
const PAYMENT_STATUSES: PaymentStatus[] = ["pending_manual", "awaiting_payment", "paid", "failed", "refunded"];
const SHIPPING_STATUSES: ShippingStatus[] = ["not_shipped", "packed", "shipped", "delivered"];

async function getOrders() {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("orders")
    .select("*, customer:customers(name, email, phone), items:order_items(*)")
    .order("created_at", { ascending: false });
  if (error) {
    console.error("admin getOrders:", error.message);
    return [];
  }
  return data ?? [];
}

export default async function AdminOrdersPage() {
  const orders = await getOrders();

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-xfy-black">Orders</h1>
      <p className="mt-1 text-sm text-xfy-gray-500">{orders.length} orders placed through XFY checkout.</p>

      {orders.length === 0 ? (
        <div className="mt-8 rounded-xfy border border-dashed border-xfy-gray-300 bg-white p-10 text-center text-sm text-xfy-gray-500">
          No orders yet. Orders placed on the storefront checkout will appear here.
        </div>
      ) : (
        <div className="mt-6 space-y-4">
          {orders.map((order: any) => (
            <details key={order.id} className="rounded-xfy border border-xfy-gray-200 bg-white p-5">
              <summary className="flex cursor-pointer flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="font-medium text-xfy-black">{order.order_number}</p>
                  <p className="text-xs text-xfy-gray-500">{order.customer?.name} · {order.customer?.email}</p>
                </div>
                <div className="flex items-center gap-2">
                  <Badge tone={order.payment_status === "paid" ? "selected" : "status"} className="capitalize">{order.payment_status?.replace("_", " ")}</Badge>
                  <span className="text-sm font-semibold text-xfy-black">{formatPrice(order.total, order.currency)}</span>
                </div>
              </summary>

              <div className="mt-4 space-y-4 border-t border-xfy-gray-100 pt-4">
                <div>
                  <p className="text-xs font-medium uppercase tracking-wide text-xfy-gray-500">Items</p>
                  <ul className="mt-2 space-y-1 text-sm text-xfy-gray-700">
                    {order.items?.map((item: any) => (
                      <li key={item.id}>
                        {item.quantity}× {item.product_name_snapshot} ({item.brand_name_snapshot}){item.variant_snapshot ? ` — ${item.variant_snapshot}` : ""} — {formatPrice(item.unit_price * item.quantity, order.currency)}
                      </li>
                    ))}
                  </ul>
                </div>

                <div>
                  <p className="text-xs font-medium uppercase tracking-wide text-xfy-gray-500">Shipping address</p>
                  <p className="mt-1 text-sm text-xfy-gray-700">
                    {order.shipping_address?.full_name}, {order.shipping_address?.address_line}, {order.shipping_address?.city}, {order.shipping_address?.province} {order.shipping_address?.postal_code}, {order.shipping_address?.country}
                  </p>
                </div>

                <form
                  action={async (formData: FormData) => {
                    "use server";
                    await updateOrderStatus(order.id, {
                      status: formData.get("status") as OrderStatus,
                      payment_status: formData.get("payment_status") as PaymentStatus,
                      shipping_status: formData.get("shipping_status") as ShippingStatus,
                    });
                  }}
                  className="grid grid-cols-1 gap-3 sm:grid-cols-4"
                >
                  <select name="status" defaultValue={order.status} className="h-10 rounded-xfy border border-xfy-gray-200 px-3 text-sm capitalize">
                    {ORDER_STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
                  </select>
                  <select name="payment_status" defaultValue={order.payment_status} className="h-10 rounded-xfy border border-xfy-gray-200 px-3 text-sm capitalize">
                    {PAYMENT_STATUSES.map((s) => <option key={s} value={s}>{s.replace("_", " ")}</option>)}
                  </select>
                  <select name="shipping_status" defaultValue={order.shipping_status} className="h-10 rounded-xfy border border-xfy-gray-200 px-3 text-sm capitalize">
                    {SHIPPING_STATUSES.map((s) => <option key={s} value={s}>{s.replace("_", " ")}</option>)}
                  </select>
                  <button type="submit" className="h-10 rounded-xfy bg-xfy-black px-4 text-sm font-medium text-white hover:bg-xfy-navy">
                    Update status
                  </button>
                </form>
              </div>
            </details>
          ))}
        </div>
      )}
    </div>
  );
}
