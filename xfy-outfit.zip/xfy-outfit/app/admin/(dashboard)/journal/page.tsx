import Link from "next/link";
import { Plus } from "lucide-react";
import { getAllArticlesForAdmin } from "@/lib/data/journal";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export default async function AdminJournalPage() {
  const articles = await getAllArticlesForAdmin();

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-xfy-black">Journal</h1>
          <p className="mt-1 text-sm text-xfy-gray-500">{articles.length} articles</p>
        </div>
        <Link href="/admin/journal/new"><Button variant="accent"><Plus className="h-4 w-4" /> New article</Button></Link>
      </div>

      <div className="mt-6 overflow-x-auto rounded-xfy border border-xfy-gray-200 bg-white">
        <table className="w-full min-w-[520px] text-left text-sm">
          <thead className="border-b border-xfy-gray-200 text-xs uppercase tracking-wide text-xfy-gray-500">
            <tr><th className="px-4 py-3">Title</th><th className="px-4 py-3">Status</th><th className="px-4 py-3 text-right">Actions</th></tr>
          </thead>
          <tbody>
            {articles.length === 0 ? (
              <tr><td colSpan={3} className="px-4 py-10 text-center text-xfy-gray-500">No articles yet.</td></tr>
            ) : (
              articles.map((a) => (
                <tr key={a.id} className="border-b border-xfy-gray-100 last:border-0">
                  <td className="px-4 py-3 font-medium text-xfy-black">{a.title}</td>
                  <td className="px-4 py-3"><Badge tone={a.status === "published" ? "selected" : "status"} className="capitalize">{a.status}</Badge></td>
                  <td className="px-4 py-3 text-right"><Link href={`/admin/journal/${a.id}/edit`} className="text-xfy-blue hover:underline">Edit</Link></td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
