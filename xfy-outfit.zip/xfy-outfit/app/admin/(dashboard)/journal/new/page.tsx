import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { createArticle } from "@/lib/actions/journal";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";

export default function NewArticlePage() {
  return (
    <div>
      <Link href="/admin/journal" className="mb-6 inline-flex items-center gap-1.5 text-sm text-xfy-gray-500 hover:text-xfy-black">
        <ArrowLeft className="h-4 w-4" /> Back to journal
      </Link>
      <h1 className="font-display text-2xl font-bold text-xfy-black">New article</h1>
      <form action={createArticle} className="mt-6 max-w-2xl space-y-5 rounded-xfy border border-xfy-gray-200 bg-white p-6">
        <div><Label htmlFor="title">Title</Label><Input id="title" name="title" required /></div>
        <div><Label htmlFor="excerpt">Excerpt</Label><Textarea id="excerpt" name="excerpt" rows={2} /></div>
        <div><Label htmlFor="cover_image_url">Cover image URL</Label><Input id="cover_image_url" name="cover_image_url" type="url" /></div>
        <div><Label htmlFor="body_markdown">Body</Label><Textarea id="body_markdown" name="body_markdown" rows={10} /></div>
        <div>
          <Label htmlFor="status">Status</Label>
          <Select id="status" name="status" defaultValue="draft">
            <option value="draft">Draft</option>
            <option value="published">Published</option>
          </Select>
        </div>
        <Button type="submit" variant="accent" size="lg">Create article</Button>
      </form>
    </div>
  );
}
