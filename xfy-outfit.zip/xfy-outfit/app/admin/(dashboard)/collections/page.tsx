import Link from "next/link";
import { Plus } from "lucide-react";
import { getAllCollectionsForAdmin } from "@/lib/data/collections";
import { archiveCollection } from "@/lib/actions/collections";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export default async function AdminCollectionsPage() {
  const collections = await getAllCollectionsForAdmin();

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-xfy-black">Collections</h1>
          <p className="mt-1 text-sm text-xfy-gray-500">Assign products to a collection from each product&apos;s edit page.</p>
        </div>
        <Link href="/admin/collections/new"><Button variant="accent"><Plus className="h-4 w-4" /> New collection</Button></Link>
      </div>

      <div className="mt-6 overflow-x-auto rounded-xfy border border-xfy-gray-200 bg-white">
        <table className="w-full min-w-[520px] text-left text-sm">
          <thead className="border-b border-xfy-gray-200 text-xs uppercase tracking-wide text-xfy-gray-500">
            <tr><th className="px-4 py-3">Name</th><th className="px-4 py-3">Status</th><th className="px-4 py-3">Order</th><th className="px-4 py-3 text-right">Actions</th></tr>
          </thead>
          <tbody>
            {collections.length === 0 ? (
              <tr><td colSpan={4} className="px-4 py-10 text-center text-xfy-gray-500">No collections yet.</td></tr>
            ) : (
              collections.map((c) => (
                <tr key={c.id} className="border-b border-xfy-gray-100 last:border-0">
                  <td className="px-4 py-3 font-medium text-xfy-black">{c.name}</td>
                  <td className="px-4 py-3"><Badge tone={c.status === "published" ? "selected" : "status"} className="capitalize">{c.status}</Badge></td>
                  <td className="px-4 py-3 text-xfy-gray-700">{c.sort_order}</td>
                  <td className="px-4 py-3">
                    <div className="flex justify-end gap-3">
                      <Link href={`/admin/collections/${c.id}/edit`} className="text-xfy-blue hover:underline">Edit</Link>
                      {c.status !== "archived" && (
                        <form action={async () => { "use server"; await archiveCollection(c.id); }}>
                          <button type="submit" className="text-xfy-gray-500 hover:text-red-600">Archive</button>
                        </form>
                      )}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
