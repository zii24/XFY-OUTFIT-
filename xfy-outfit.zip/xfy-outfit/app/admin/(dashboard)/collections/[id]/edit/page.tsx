import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { createClient } from "@/lib/supabase/server";
import { updateCollection } from "@/lib/actions/collections";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";

export default async function EditCollectionPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const supabase = await createClient();
  const { data: collection } = await supabase.from("collections").select("*").eq("id", id).maybeSingle();
  if (!collection) notFound();

  const boundAction = updateCollection.bind(null, id);

  return (
    <div>
      <Link href="/admin/collections" className="mb-6 inline-flex items-center gap-1.5 text-sm text-xfy-gray-500 hover:text-xfy-black">
        <ArrowLeft className="h-4 w-4" /> Back to collections
      </Link>
      <h1 className="font-display text-2xl font-bold text-xfy-black">Edit collection</h1>
      <form action={boundAction} className="mt-6 max-w-lg space-y-5 rounded-xfy border border-xfy-gray-200 bg-white p-6">
        <div><Label htmlFor="name">Name</Label><Input id="name" name="name" required defaultValue={collection.name} /></div>
        <div><Label htmlFor="description">Description</Label><Textarea id="description" name="description" rows={3} defaultValue={collection.description ?? ""} /></div>
        <div><Label htmlFor="cover_image_url">Cover image URL</Label><Input id="cover_image_url" name="cover_image_url" type="url" defaultValue={collection.cover_image_url ?? ""} /></div>
        <div>
          <Label htmlFor="status">Status</Label>
          <Select id="status" name="status" defaultValue={collection.status}>
            <option value="draft">Draft</option>
            <option value="published">Published</option>
            <option value="archived">Archived</option>
          </Select>
        </div>
        <div><Label htmlFor="sort_order">Sort order</Label><Input id="sort_order" name="sort_order" type="number" defaultValue={collection.sort_order} /></div>
        <Button type="submit" variant="accent" size="lg">Save changes</Button>
      </form>
    </div>
  );
}
