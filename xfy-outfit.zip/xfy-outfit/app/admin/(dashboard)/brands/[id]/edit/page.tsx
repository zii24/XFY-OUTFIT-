import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft } from "lucide-react";
import { BrandForm } from "@/components/admin/brand-form";
import { updateBrand } from "@/lib/actions/brands";
import { getBrandByIdForAdmin } from "@/lib/data/brands";

export default async function EditBrandPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const brand = await getBrandByIdForAdmin(id);
  if (!brand) notFound();

  const boundAction = updateBrand.bind(null, id);

  return (
    <div>
      <Link href="/admin/brands" className="mb-6 inline-flex items-center gap-1.5 text-sm text-xfy-gray-500 hover:text-xfy-black">
        <ArrowLeft className="h-4 w-4" /> Back to brands
      </Link>
      <h1 className="font-display text-2xl font-bold text-xfy-black">Edit brand</h1>
      <div className="mt-6 max-w-2xl">
        <BrandForm action={boundAction} brand={brand} submitLabel="Save changes" />
      </div>
    </div>
  );
}
