import Link from "next/link";
import { Plus } from "lucide-react";
import { getAllBrandsForAdmin } from "@/lib/data/brands";
import { archiveBrand } from "@/lib/actions/brands";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export default async function AdminBrandsPage() {
  const brands = await getAllBrandsForAdmin();

  return (
    <div>
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-bold text-xfy-black">Brands</h1>
          <p className="mt-1 text-sm text-xfy-gray-500">{brands.length} total</p>
        </div>
        <Link href="/admin/brands/new">
          <Button variant="accent"><Plus className="h-4 w-4" /> Add brand</Button>
        </Link>
      </div>

      <div className="mt-6 overflow-x-auto rounded-xfy border border-xfy-gray-200 bg-white">
        <table className="w-full min-w-[600px] text-left text-sm">
          <thead className="border-b border-xfy-gray-200 text-xs uppercase tracking-wide text-xfy-gray-500">
            <tr>
              <th className="px-4 py-3">Brand</th>
              <th className="px-4 py-3">Location</th>
              <th className="px-4 py-3">Featured</th>
              <th className="px-4 py-3">Status</th>
              <th className="px-4 py-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody>
            {brands.length === 0 ? (
              <tr><td colSpan={5} className="px-4 py-10 text-center text-xfy-gray-500">No brands yet.</td></tr>
            ) : (
              brands.map((b) => (
                <tr key={b.id} className="border-b border-xfy-gray-100 last:border-0">
                  <td className="px-4 py-3 font-medium text-xfy-black">{b.name}</td>
                  <td className="px-4 py-3 text-xfy-gray-700">{b.location ?? "—"}</td>
                  <td className="px-4 py-3 text-xfy-gray-700">{b.is_featured ? "Yes" : "No"}</td>
                  <td className="px-4 py-3"><Badge tone={b.status === "published" ? "selected" : "status"} className="capitalize">{b.status}</Badge></td>
                  <td className="px-4 py-3">
                    <div className="flex justify-end gap-3">
                      <Link href={`/admin/brands/${b.id}/edit`} className="text-xfy-blue hover:underline">Edit</Link>
                      {b.status !== "archived" && (
                        <form action={async () => { "use server"; await archiveBrand(b.id); }}>
                          <button type="submit" className="text-xfy-gray-500 hover:text-red-600">Archive</button>
                        </form>
                      )}
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
