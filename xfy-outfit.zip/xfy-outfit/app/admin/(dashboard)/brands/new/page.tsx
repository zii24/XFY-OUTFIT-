import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { BrandForm } from "@/components/admin/brand-form";
import { createBrand } from "@/lib/actions/brands";

export default function NewBrandPage() {
  return (
    <div>
      <Link href="/admin/brands" className="mb-6 inline-flex items-center gap-1.5 text-sm text-xfy-gray-500 hover:text-xfy-black">
        <ArrowLeft className="h-4 w-4" /> Back to brands
      </Link>
      <h1 className="font-display text-2xl font-bold text-xfy-black">Add brand</h1>
      <div className="mt-6 max-w-2xl">
        <BrandForm action={createBrand} submitLabel="Create brand" />
      </div>
    </div>
  );
}
