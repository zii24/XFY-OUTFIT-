"use client";

import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";

export function AdminLoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const unauthorized = searchParams.get("error") === "unauthorized";

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const supabase = createClient();
    const { error: signInError } = await supabase.auth.signInWithPassword({ email, password });

    if (signInError) {
      setError("Incorrect email or password.");
      setLoading(false);
      return;
    }

    const next = searchParams.get("next") ?? "/admin";
    router.push(next);
    router.refresh();
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-xfy-gray-50 px-4">
      <div className="w-full max-w-sm rounded-xfy border border-xfy-gray-200 bg-white p-8 shadow-sm">
        <p className="font-display text-xl font-bold text-xfy-black">XFY</p>
        <h1 className="mt-1 text-sm text-xfy-gray-500">Admin sign in</h1>

        {unauthorized && (
          <p className="mt-4 rounded-xfy border border-amber-200 bg-amber-50 p-3 text-xs text-amber-800">
            That account isn&apos;t authorized for the admin dashboard. Contact an existing admin to be added.
          </p>
        )}
        {error && (
          <p className="mt-4 rounded-xfy border border-red-200 bg-red-50 p-3 text-xs text-red-700" role="alert">
            {error}
          </p>
        )}

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <div>
            <Label htmlFor="email">Email</Label>
            <Input id="email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
          </div>
          <div>
            <Label htmlFor="password">Password</Label>
            <Input id="password" type="password" required value={password} onChange={(e) => setPassword(e.target.value)} />
          </div>
          <Button type="submit" variant="primary" size="lg" className="w-full" disabled={loading}>
            {loading ? "Signing in…" : "Sign in"}
          </Button>
        </form>
        <p className="mt-6 text-center text-xs text-xfy-gray-500">
          Admin accounts are created in the Supabase dashboard, not self-serve — see README &ldquo;Admin access&rdquo;.
        </p>
      </div>
    </div>
  );
}
