"use client";

// Replaces the root layout entirely when an error escapes every nested
// error boundary, so it must define its own <html>/<body>.
export default function GlobalError({ reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <html lang="en">
      <body>
        <div className="flex min-h-screen flex-col items-center justify-center bg-white px-4 text-center">
          <h1 className="text-xl font-bold text-black">Something went wrong.</h1>
          <p className="mt-2 text-sm text-gray-500">Please try again.</p>
          <button onClick={reset} className="mt-6 rounded-md bg-black px-5 py-2.5 text-sm font-medium text-white">
            Retry
          </button>
        </div>
      </body>
    </html>
  );
}
