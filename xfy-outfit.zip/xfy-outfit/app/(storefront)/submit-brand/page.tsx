"use client";

import { useFormState, useFormStatus } from "react-dom";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { FieldError } from "@/components/ui/field-error";
import { submitBrand } from "@/lib/actions/brand-submissions";
import { CheckCircle2 } from "lucide-react";

function SubmitButton() {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" variant="accent" size="lg" disabled={pending}>
      {pending ? "Submitting…" : "Submit your brand"}
    </Button>
  );
}

export default function SubmitBrandPage() {
  const [state, formAction] = useFormState(submitBrand, undefined);

  if (state?.success) {
    return (
      <div className="container flex max-w-lg flex-col items-center py-24 text-center">
        <CheckCircle2 className="h-12 w-12 text-xfy-blue" strokeWidth={1.5} />
        <h1 className="mt-5 font-display text-2xl font-bold text-xfy-black">Thanks for reaching out.</h1>
        <p className="mt-3 text-sm text-xfy-gray-500">
          We review every submission by hand. If it&apos;s a fit for the XFY edit, our team will follow up by email.
        </p>
      </div>
    );
  }

  return (
    <div className="container max-w-lg py-14 md:py-20">
      <h1 className="font-display text-3xl font-bold text-xfy-black">Submit your brand</h1>
      <p className="mt-3 text-sm leading-relaxed text-xfy-gray-500">
        Tell us about your label. We look for a distinctive point of view, quality, and fit within the XFY edit — not
        every submission is accepted, and we won&apos;t sugarcoat that.
      </p>

      {state?.error && (
        <div className="mt-6 rounded-xfy border border-red-200 bg-red-50 p-4 text-sm text-red-700" role="alert">
          {state.error}
        </div>
      )}

      <form action={formAction} className="mt-8 space-y-5">
        <div>
          <Label htmlFor="brand_name">Brand name</Label>
          <Input id="brand_name" name="brand_name" required />
          <FieldError message={state?.fieldErrors?.brand_name} />
        </div>
        <div>
          <Label htmlFor="contact_name">Your name</Label>
          <Input id="contact_name" name="contact_name" required />
          <FieldError message={state?.fieldErrors?.contact_name} />
        </div>
        <div>
          <Label htmlFor="email">Email</Label>
          <Input id="email" name="email" type="email" required />
          <FieldError message={state?.fieldErrors?.email} />
        </div>
        <div>
          <Label htmlFor="instagram_url">Instagram URL (optional)</Label>
          <Input id="instagram_url" name="instagram_url" type="url" placeholder="https://instagram.com/yourbrand" />
        </div>
        <div>
          <Label htmlFor="website_url">Website (optional)</Label>
          <Input id="website_url" name="website_url" type="url" placeholder="https://yourbrand.com" />
        </div>
        <div>
          <Label htmlFor="city">City (optional)</Label>
          <Input id="city" name="city" placeholder="e.g. Bandung" />
        </div>
        <div>
          <Label htmlFor="style_description">Tell us about your brand</Label>
          <Textarea id="style_description" name="style_description" required placeholder="What you make, your style, and what makes it distinctive." rows={5} />
          <FieldError message={state?.fieldErrors?.style_description} />
        </div>
        <SubmitButton />
      </form>
    </div>
  );
}
