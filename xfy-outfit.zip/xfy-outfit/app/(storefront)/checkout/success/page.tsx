import Link from "next/link";
import { CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";

export default async function CheckoutSuccessPage({ searchParams }: { searchParams: Promise<{ order?: string }> }) {
  const { order } = await searchParams;

  return (
    <div className="container flex flex-col items-center justify-center py-24 text-center md:py-32">
      <CheckCircle2 className="h-14 w-14 text-xfy-blue" strokeWidth={1.5} />
      <h1 className="mt-6 font-display text-3xl font-bold text-xfy-black">Order placed</h1>
      {order && (
        <p className="mt-3 text-sm text-xfy-gray-500">
          Order number <span className="font-medium text-xfy-black">{order}</span>
        </p>
      )}
      <p className="mt-4 max-w-md text-sm leading-relaxed text-xfy-gray-500">
        We&apos;ve received your order and it&apos;s awaiting payment confirmation. You&apos;ll get an email with
        transfer details shortly — we&apos;ll never mark an order as paid without verifying it first.
      </p>
      <div className="mt-8 flex gap-3">
        <Link href="/shop">
          <Button variant="accent" size="lg">Continue shopping</Button>
        </Link>
        <Link href="/">
          <Button variant="outline" size="lg">Back to home</Button>
        </Link>
      </div>
    </div>
  );
}
