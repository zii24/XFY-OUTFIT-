"use client";

import { useState } from "react";
import { useFormState, useFormStatus } from "react-dom";
import { useRouter } from "next/navigation";
import Link from "next/link";
import Image from "next/image";
import { Check } from "lucide-react";
import { useCart } from "@/context/cart-context";
import { createOrder } from "@/lib/actions/orders";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { FieldError } from "@/components/ui/field-error";
import { formatPrice } from "@/lib/utils";
import { useEffect } from "react";

const STEPS = ["Customer info", "Shipping", "Payment", "Review"];

function SubmitButton() {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" variant="accent" size="lg" className="w-full" disabled={pending}>
      {pending ? "Placing order…" : "Place order"}
    </Button>
  );
}

export default function CheckoutPage() {
  const { lines, subtotalByDestination, clearDestination } = useCart();
  const xfyLines = lines.filter((l) => l.destination === "xfy");
  const router = useRouter();
  const [step, setStep] = useState(0);

  const boundAction = createOrder.bind(null, xfyLines);
  const [state, formAction] = useFormState(boundAction, undefined);

  useEffect(() => {
    if (state?.orderNumber) {
      clearDestination("xfy");
      router.push(`/checkout/success?order=${state.orderNumber}`);
    }
  }, [state?.orderNumber, clearDestination, router]);

  if (xfyLines.length === 0) {
    return (
      <div className="container flex flex-col items-center justify-center py-28 text-center">
        <p className="font-display text-xl font-semibold text-xfy-black">No XFY items to check out.</p>
        <p className="mt-2 max-w-sm text-sm text-xfy-gray-500">
          Add a product with &ldquo;Buy on XFY&rdquo; to your cart, or continue your Shopee/Etsy purchases from the cart page.
        </p>
        <Link href="/cart">
          <Button variant="accent" size="lg" className="mt-6">Back to cart</Button>
        </Link>
      </div>
    );
  }

  const shippingCost = 15000;
  const subtotal = subtotalByDestination.xfy;
  const total = subtotal + shippingCost;

  return (
    <div className="container py-10 md:py-14">
      <h1 className="font-display text-3xl font-bold text-xfy-black">Checkout</h1>

      <ol className="mt-6 flex flex-wrap gap-x-6 gap-y-2" aria-label="Checkout progress">
        {STEPS.map((label, i) => (
          <li key={label} className="flex items-center gap-2 text-sm">
            <span
              className={`flex h-6 w-6 items-center justify-center rounded-full text-xs font-semibold ${
                i <= step ? "bg-xfy-black text-white" : "bg-xfy-gray-100 text-xfy-gray-500"
              }`}
            >
              {i < step ? <Check className="h-3.5 w-3.5" /> : i + 1}
            </span>
            <span className={i <= step ? "text-xfy-black" : "text-xfy-gray-500"}>{label}</span>
          </li>
        ))}
      </ol>

      <div className="mt-10 grid grid-cols-1 gap-10 lg:grid-cols-[1.3fr_1fr]">
        <form action={formAction} className="space-y-10">
          {state?.error && (
            <div className="rounded-xfy border border-red-200 bg-red-50 p-4 text-sm text-red-700" role="alert">
              {state.error}
            </div>
          )}

          <fieldset className="space-y-4">
            <legend className="mb-1 font-display text-lg font-semibold text-xfy-black">1. Customer information</legend>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <Label htmlFor="full_name">Full name</Label>
                <Input id="full_name" name="full_name" required />
                <FieldError message={state?.fieldErrors?.full_name} />
              </div>
              <div>
                <Label htmlFor="email">Email</Label>
                <Input id="email" name="email" type="email" required />
                <FieldError message={state?.fieldErrors?.email} />
              </div>
              <div className="sm:col-span-2">
                <Label htmlFor="phone">Phone</Label>
                <Input id="phone" name="phone" type="tel" required />
                <FieldError message={state?.fieldErrors?.phone} />
              </div>
            </div>
          </fieldset>

          <fieldset className="space-y-4">
            <legend className="mb-1 font-display text-lg font-semibold text-xfy-black">2. Shipping address</legend>
            <div>
              <Label htmlFor="address_line">Address</Label>
              <Input id="address_line" name="address_line" required />
              <FieldError message={state?.fieldErrors?.address_line} />
            </div>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
              <div>
                <Label htmlFor="city">City</Label>
                <Input id="city" name="city" required />
                <FieldError message={state?.fieldErrors?.city} />
              </div>
              <div>
                <Label htmlFor="province">Province</Label>
                <Input id="province" name="province" required />
                <FieldError message={state?.fieldErrors?.province} />
              </div>
              <div>
                <Label htmlFor="postal_code">Postal code</Label>
                <Input id="postal_code" name="postal_code" required />
                <FieldError message={state?.fieldErrors?.postal_code} />
              </div>
            </div>
            <div>
              <Label htmlFor="country">Country</Label>
              <Select id="country" name="country" defaultValue="Indonesia">
                <option value="Indonesia">Indonesia</option>
              </Select>
              <p className="mt-1.5 text-xs text-xfy-gray-500">International shipping isn&apos;t available yet — Indonesia only for V1.</p>
            </div>
          </fieldset>

          <fieldset className="space-y-3">
            <legend className="mb-1 font-display text-lg font-semibold text-xfy-black">3. Shipping method</legend>
            <label className="flex items-center justify-between rounded-xfy border border-xfy-gray-200 p-4 text-sm has-[:checked]:border-xfy-black">
              <span className="flex items-center gap-3">
                <input type="radio" name="shipping_method" value="standard" defaultChecked className="h-4 w-4 text-xfy-blue" />
                Standard (3–5 days)
              </span>
              <span className="font-medium">{formatPrice(15000, "IDR")}</span>
            </label>
            <label className="flex items-center justify-between rounded-xfy border border-xfy-gray-200 p-4 text-sm has-[:checked]:border-xfy-black">
              <span className="flex items-center gap-3">
                <input type="radio" name="shipping_method" value="express" className="h-4 w-4 text-xfy-blue" />
                Express (1–2 days)
              </span>
              <span className="font-medium">{formatPrice(35000, "IDR")}</span>
            </label>
          </fieldset>

          <fieldset className="space-y-3">
            <legend className="mb-1 font-display text-lg font-semibold text-xfy-black">4. Payment method</legend>
            <label className="flex items-center gap-3 rounded-xfy border border-xfy-gray-200 p-4 text-sm has-[:checked]:border-xfy-black">
              <input type="radio" name="payment_method" value="bank_transfer" defaultChecked className="h-4 w-4 text-xfy-blue" />
              Bank transfer
            </label>
            <label className="flex items-center gap-3 rounded-xfy border border-xfy-gray-200 p-4 text-sm has-[:checked]:border-xfy-black">
              <input type="radio" name="payment_method" value="e_wallet" className="h-4 w-4 text-xfy-blue" />
              E-wallet (GoPay, OVO, Dana)
            </label>
            <label className="flex items-center gap-3 rounded-xfy border border-xfy-gray-200 p-4 text-sm has-[:checked]:border-xfy-black">
              <input type="radio" name="payment_method" value="cod" className="h-4 w-4 text-xfy-blue" />
              Cash on delivery
            </label>
            <p className="text-xs leading-relaxed text-xfy-gray-500">
              No payment gateway is connected yet. Your order is created and marked awaiting payment — our team will
              follow up with transfer details. We never mark an order as paid without verifying it.
            </p>
          </fieldset>

          <div>
            <Label htmlFor="notes">Order notes (optional)</Label>
            <Textarea id="notes" name="notes" placeholder="Delivery instructions, gift note, etc." />
          </div>

          <label className="flex items-start gap-2 text-sm text-xfy-gray-700">
            <input type="checkbox" name="agree_terms" required className="mt-0.5 h-4 w-4 rounded border-xfy-gray-300 text-xfy-blue" />
            <span>
              I agree to XFY&apos;s <Link href="/about#terms" className="underline">Terms</Link> and{" "}
              <Link href="/about#privacy" className="underline">Privacy Policy</Link>. Your information is used only to fulfil this order.
            </span>
          </label>
          <FieldError message={state?.fieldErrors?.agree_terms} />

          <SubmitButton />
        </form>

        <aside className="h-fit rounded-xfy border border-xfy-gray-200 p-6">
          <h2 className="font-display text-lg font-semibold text-xfy-black">Order summary</h2>
          <div className="mt-4 space-y-4">
            {xfyLines.map((line) => (
              <div key={line.id} className="flex gap-3">
                <div className="relative h-16 w-14 shrink-0 overflow-hidden rounded-xfy bg-xfy-gray-100">
                  {line.image && <Image src={line.image} alt={line.name} fill sizes="56px" className="object-cover" />}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-xs uppercase tracking-wide text-xfy-gray-500">{line.brandName}</p>
                  <p className="truncate text-sm font-medium text-xfy-black">{line.name}</p>
                  {line.variant && <p className="text-xs text-xfy-gray-500">{line.variant}</p>}
                  <p className="text-xs text-xfy-gray-500">Qty {line.quantity}</p>
                </div>
                <span className="shrink-0 text-sm font-medium text-xfy-black">{formatPrice(line.unitPrice * line.quantity, "IDR")}</span>
              </div>
            ))}
          </div>
          <div className="mt-5 space-y-2 border-t border-xfy-gray-200 pt-4 text-sm">
            <div className="flex justify-between text-xfy-gray-500"><span>Subtotal</span><span>{formatPrice(subtotal, "IDR")}</span></div>
            <div className="flex justify-between text-xfy-gray-500"><span>Shipping</span><span>{formatPrice(shippingCost, "IDR")}</span></div>
            <div className="flex justify-between border-t border-xfy-gray-200 pt-2 text-base font-semibold text-xfy-black">
              <span>Total</span><span>{formatPrice(total, "IDR")}</span>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
