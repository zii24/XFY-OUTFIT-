import { Hero } from "@/components/home/hero";
import { FeaturedCollections } from "@/components/home/featured-collections";
import { XfyPicks } from "@/components/home/xfy-picks";
import { HiddenGems } from "@/components/home/hidden-gems";
import { NewBrands } from "@/components/home/new-brands";
import { ShopTheLook } from "@/components/home/shop-the-look";
import { JournalHighlights } from "@/components/home/journal-highlights";
import { Newsletter } from "@/components/home/newsletter";
import { getHomepageSettings } from "@/lib/data/homepage";
import { getFeaturedProducts, getPublishedProducts } from "@/lib/data/products";
import { getPublishedCollections } from "@/lib/data/collections";
import { getPublishedBrands, getFeaturedBrands } from "@/lib/data/brands";
import { getPublishedArticles } from "@/lib/data/journal";

export const revalidate = 60;

export default async function HomePage() {
  const [settings, featuredProducts, collections, newBrands, featuredBrands, articles, lookProducts] = await Promise.all([
    getHomepageSettings(),
    getFeaturedProducts(8),
    getPublishedCollections(),
    getPublishedBrands(),
    getFeaturedBrands(1),
    getPublishedArticles(3),
    getPublishedProducts({ sort: "featured" }),
  ]);

  const hiddenGemBrand = featuredBrands[0] ?? null;
  const shopTheLookProducts = lookProducts.slice(0, 4);

  return (
    <>
      <Hero
        title={settings.hero_title}
        subtitle={settings.hero_subtitle}
        imageUrl={settings.hero_image_url}
        ctaLabel={settings.hero_cta_label}
        ctaHref={settings.hero_cta_href}
        secondaryCtaLabel={settings.hero_secondary_cta_label}
        secondaryCtaHref={settings.hero_secondary_cta_href}
      />
      <FeaturedCollections collections={collections} />
      <XfyPicks products={featuredProducts} />
      <HiddenGems brand={hiddenGemBrand} />
      <NewBrands brands={newBrands.slice(0, 4)} />
      <ShopTheLook products={shopTheLookProducts} lookImage="https://picsum.photos/seed/xfy-look/900/1200" />
      <JournalHighlights articles={articles} />
      <Newsletter />
    </>
  );
}
