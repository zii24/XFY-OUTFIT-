import { Header } from "@/components/layout/header";
import { Footer } from "@/components/layout/footer";
import { AnnouncementBar } from "@/components/layout/announcement-bar";
import { CartProvider } from "@/context/cart-context";
import { WishlistProvider } from "@/context/wishlist-context";
import { getHomepageSettings } from "@/lib/data/homepage";

export default async function StorefrontLayout({ children }: { children: React.ReactNode }) {
  const settings = await getHomepageSettings();

  return (
    <CartProvider>
      <WishlistProvider>
        <AnnouncementBar text={settings.announcement_text} enabled={settings.announcement_enabled} />
        <Header />
        <main>{children}</main>
        <Footer />
      </WishlistProvider>
    </CartProvider>
  );
}
