import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Link from "next/link";
import Image from "next/image";
import { MapPin } from "lucide-react";
import { getProductBySlug, getRelatedProducts } from "@/lib/data/products";
import { Gallery } from "@/components/product/gallery";
import { Badge } from "@/components/ui/badge";
import { ProductGrid } from "@/components/product/product-grid";
import { formatPrice } from "@/lib/utils";
import { ProductInteractions } from "@/components/product/product-interactions";

interface Props {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) return {};
  return {
    title: `${product.name} — ${product.brand?.name}`,
    description: product.description ?? `${product.name} by ${product.brand?.name}, available on XFY Outfit.`,
    openGraph: { images: product.images?.[0]?.image_url ? [product.images[0].image_url] : [] },
  };
}

export default async function ProductDetailPage({ params }: Props) {
  const { slug } = await params;
  const product = await getProductBySlug(slug);
  if (!product) notFound();

  const related = await getRelatedProducts(product, 4);
  const onSale = product.sale_price != null && product.sale_price < product.price;

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: product.name,
    image: product.images?.map((i) => i.image_url) ?? [],
    description: product.description ?? undefined,
    brand: { "@type": "Brand", name: product.brand?.name },
    offers: {
      "@type": "Offer",
      priceCurrency: product.currency,
      price: product.sale_price ?? product.price,
      availability: product.stock > 0 ? "https://schema.org/InStock" : "https://schema.org/OutOfStock",
    },
  };

  return (
    <div className="container py-8 md:py-12">
      {/* eslint-disable-next-line react/no-danger */}
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />

      <nav aria-label="Breadcrumb" className="mb-6 text-xs text-xfy-gray-500">
        <Link href="/shop" className="hover:text-xfy-black">Shop</Link>
        <span className="mx-1.5">/</span>
        <Link href={`/shop/${product.category}`} className="capitalize hover:text-xfy-black">{product.category}</Link>
        <span className="mx-1.5">/</span>
        <span className="text-xfy-black">{product.name}</span>
      </nav>

      <div className="grid grid-cols-1 gap-10 md:grid-cols-2 md:gap-14">
        <Gallery images={product.images ?? []} productName={product.name} />

        <div>
          <div className="flex items-center gap-2">
            <Link href={`/brands/${product.brand?.slug}`} className="text-sm font-medium uppercase tracking-wide text-xfy-gray-500 hover:text-xfy-black">
              {product.brand?.name}
            </Link>
            {product.xfy_selected && <Badge tone="selected">XFY Selected</Badge>}
          </div>
          <h1 className="mt-2 font-display text-2xl font-bold text-xfy-black md:text-3xl">{product.name}</h1>

          <div className="mt-3 flex items-center gap-3">
            {onSale ? (
              <>
                <span className="text-xl font-semibold text-xfy-black">{formatPrice(product.sale_price!, product.currency)}</span>
                <span className="text-base text-xfy-gray-500 line-through">{formatPrice(product.price, product.currency)}</span>
              </>
            ) : (
              <span className="text-xl font-semibold text-xfy-black">{formatPrice(product.price, product.currency)}</span>
            )}
          </div>

          {product.description && <p className="mt-5 text-sm leading-relaxed text-xfy-gray-700">{product.description}</p>}

          <dl className="mt-6 grid grid-cols-2 gap-4 border-y border-xfy-gray-200 py-5 text-sm">
            {product.material && (
              <div><dt className="text-xfy-gray-500">Material</dt><dd className="mt-0.5 text-xfy-black">{product.material}</dd></div>
            )}
            {product.fit && (
              <div><dt className="text-xfy-gray-500">Fit</dt><dd className="mt-0.5 text-xfy-black">{product.fit}</dd></div>
            )}
            {product.origin && (
              <div><dt className="text-xfy-gray-500">Origin</dt><dd className="mt-0.5 text-xfy-black">{product.origin}</dd></div>
            )}
            {product.condition && (
              <div><dt className="text-xfy-gray-500">Condition</dt><dd className="mt-0.5 text-xfy-black">{product.condition}</dd></div>
            )}
          </dl>

          <ProductInteractions product={product} />

          {product.curation_note && (
            <div className="mt-8 rounded-xfy bg-xfy-blue-soft p-5">
              <p className="text-sm font-semibold text-xfy-blue-dark">Why XFY picked this</p>
              <p className="mt-2 text-sm leading-relaxed text-xfy-navy">{product.curation_note}</p>
            </div>
          )}

          {product.brand && (
            <div className="mt-8 flex items-center justify-between rounded-xfy border border-xfy-gray-200 p-4">
              <div className="flex items-center gap-3">
                <div className="relative h-12 w-12 overflow-hidden rounded-full bg-xfy-gray-100">
                  {product.brand.logo_url && <Image src={product.brand.logo_url} alt={product.brand.name} fill className="object-cover" />}
                </div>
                <div>
                  <p className="text-sm font-semibold text-xfy-black">{product.brand.name}</p>
                  {product.brand.location && (
                    <p className="flex items-center gap-1 text-xs text-xfy-gray-500">
                      <MapPin className="h-3 w-3" /> {product.brand.location}
                    </p>
                  )}
                </div>
              </div>
              <Link href={`/brands/${product.brand.slug}`} className="text-sm font-medium text-xfy-blue hover:underline">
                Explore brand
              </Link>
            </div>
          )}
        </div>
      </div>

      {related.length > 0 && (
        <div className="mt-20">
          <h2 className="mb-8 font-display text-2xl font-bold text-xfy-black">You may also like</h2>
          <ProductGrid products={related} />
        </div>
      )}
    </div>
  );
}
