import type { Metadata } from "next";
import { getPublishedCollections } from "@/lib/data/collections";
import { CollectionCard } from "@/components/collection/collection-card";

export const metadata: Metadata = { title: "Collections", description: "Curated edits from XFY Outfit." };

export default async function CollectionsPage() {
  const collections = await getPublishedCollections();
  return (
    <div className="container py-10 md:py-14">
      <div className="mb-10 max-w-2xl">
        <h1 className="font-display text-3xl font-bold text-xfy-black md:text-4xl">Collections</h1>
        <p className="mt-3 text-sm text-xfy-gray-500 md:text-base">Curated edits built around a style, a season, or a story.</p>
      </div>
      {collections.length > 0 ? (
        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {collections.map((c) => (
            <CollectionCard key={c.id} collection={c} />
          ))}
        </div>
      ) : (
        <p className="text-sm text-xfy-gray-500">No collections published yet.</p>
      )}
    </div>
  );
}
