import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Image from "next/image";
import { getCollectionBySlug, getCollectionProducts } from "@/lib/data/collections";
import { ProductGrid } from "@/components/product/product-grid";

interface Props {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const collection = await getCollectionBySlug(slug);
  if (!collection) return {};
  return { title: collection.name, description: collection.description ?? undefined };
}

export default async function CollectionDetailPage({ params }: Props) {
  const { slug } = await params;
  const collection = await getCollectionBySlug(slug);
  if (!collection) notFound();

  const products = await getCollectionProducts(collection.id);

  return (
    <div>
      <div className="relative h-72 w-full overflow-hidden bg-xfy-gray-100 md:h-96">
        <Image
          src={collection.cover_image_url ?? `https://picsum.photos/seed/${collection.slug}-cover/1600/800`}
          alt={collection.name}
          fill
          priority
          className="object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
        <div className="container absolute inset-x-0 bottom-0 pb-8">
          <h1 className="font-display text-3xl font-bold text-white md:text-4xl">{collection.name}</h1>
          {collection.description && <p className="mt-2 max-w-xl text-sm text-white/85 md:text-base">{collection.description}</p>}
        </div>
      </div>
      <div className="container py-12">
        {products.length > 0 ? (
          <ProductGrid products={products} />
        ) : (
          <p className="text-sm text-xfy-gray-500">No products in this collection yet.</p>
        )}
      </div>
    </div>
  );
}
