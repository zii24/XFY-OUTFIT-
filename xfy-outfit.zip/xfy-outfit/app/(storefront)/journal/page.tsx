import type { Metadata } from "next";
import Link from "next/link";
import Image from "next/image";
import { getPublishedArticles } from "@/lib/data/journal";

export const metadata: Metadata = { title: "Journal", description: "Fashion culture, brand stories, and how to discover independent labels." };

export default async function JournalPage() {
  const articles = await getPublishedArticles();

  return (
    <div className="container py-10 md:py-14">
      <div className="mb-10 max-w-2xl">
        <h1 className="font-display text-3xl font-bold text-xfy-black md:text-4xl">XFY Journal</h1>
        <p className="mt-3 text-sm text-xfy-gray-500 md:text-base">Fashion culture, brand stories, and how to discover independent labels.</p>
      </div>

      {articles.length > 0 ? (
        <div className="grid grid-cols-1 gap-10 sm:grid-cols-2 lg:grid-cols-3">
          {articles.map((article) => (
            <Link key={article.id} href={`/journal/${article.slug}`} className="group block">
              <div className="relative aspect-[4/3] w-full overflow-hidden rounded-xfy bg-xfy-gray-100">
                <Image
                  src={article.cover_image_url ?? `https://picsum.photos/seed/${article.slug}/800/600`}
                  alt={article.title}
                  fill
                  sizes="(min-width: 768px) 33vw, 100vw"
                  className="object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </div>
              <h2 className="mt-4 font-display text-lg font-semibold text-xfy-black">{article.title}</h2>
              {article.excerpt && <p className="mt-2 line-clamp-2 text-sm text-xfy-gray-500">{article.excerpt}</p>}
            </Link>
          ))}
        </div>
      ) : (
        <p className="text-sm text-xfy-gray-500">No articles published yet.</p>
      )}
    </div>
  );
}
