import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Image from "next/image";
import { getArticleBySlug } from "@/lib/data/journal";

interface Props {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const article = await getArticleBySlug(slug);
  if (!article) return {};
  return { title: article.title, description: article.excerpt ?? undefined };
}

export default async function JournalArticlePage({ params }: Props) {
  const { slug } = await params;
  const article = await getArticleBySlug(slug);
  if (!article) notFound();

  return (
    <article className="container max-w-2xl py-10 md:py-14">
      <h1 className="font-display text-3xl font-bold text-xfy-black md:text-4xl">{article.title}</h1>
      {article.excerpt && <p className="mt-4 text-base text-xfy-gray-500">{article.excerpt}</p>}
      {article.published_at && (
        <time className="mt-2 block text-xs text-xfy-gray-400" dateTime={article.published_at}>
          {new Date(article.published_at).toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" })}
        </time>
      )}
      {article.cover_image_url && (
        <div className="relative mt-8 aspect-[16/9] w-full overflow-hidden rounded-xfy bg-xfy-gray-100">
          <Image src={article.cover_image_url} alt={article.title} fill sizes="(min-width: 768px) 672px, 100vw" className="object-cover" />
        </div>
      )}
      {article.body_markdown && (
        <div className="prose prose-sm mt-8 max-w-none whitespace-pre-wrap leading-relaxed text-xfy-gray-700">
          {article.body_markdown}
        </div>
      )}
    </article>
  );
}
