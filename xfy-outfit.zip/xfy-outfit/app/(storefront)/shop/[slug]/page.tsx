import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { getPublishedProducts } from "@/lib/data/products";
import { ProductGrid } from "@/components/product/product-grid";
import { CATEGORIES, STYLES } from "@/lib/constants";

interface Props {
  params: Promise<{ slug: string }>;
}

function resolveSlug(slug: string) {
  const category = CATEGORIES.find((c) => c.slug === slug);
  if (category) return { type: "category" as const, label: category.name };
  const style = STYLES.find((s) => s.slug === slug);
  if (style) return { type: "style" as const, label: style.name };
  return null;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const resolved = resolveSlug(slug);
  if (!resolved) return {};
  return { title: resolved.label, description: `Shop ${resolved.label.toLowerCase()} pieces from independent Indonesian fashion brands.` };
}

export default async function ShopStylePage({ params }: Props) {
  const { slug } = await params;
  const resolved = resolveSlug(slug);
  if (!resolved) notFound();

  const products = await getPublishedProducts(resolved.type === "category" ? { category: slug } : { style: slug });

  return (
    <div className="container py-10 md:py-14">
      <div className="mb-10 max-w-2xl">
        <p className="text-sm font-medium text-xfy-blue">{resolved.type === "category" ? "Category" : "Style"}</p>
        <h1 className="mt-1 font-display text-3xl font-bold text-xfy-black md:text-4xl">{resolved.label}</h1>
        <p className="mt-3 text-sm text-xfy-gray-500">{products.length} pieces</p>
      </div>
      {products.length > 0 ? (
        <ProductGrid products={products} />
      ) : (
        <div className="flex flex-col items-center justify-center rounded-xfy border border-dashed border-xfy-gray-200 py-24 text-center">
          <p className="font-display text-lg font-semibold text-xfy-black">No pieces found in {resolved.label} yet.</p>
          <a href="/shop" className="mt-5 text-sm font-medium text-xfy-blue hover:underline">
            Browse all products
          </a>
        </div>
      )}
    </div>
  );
}
