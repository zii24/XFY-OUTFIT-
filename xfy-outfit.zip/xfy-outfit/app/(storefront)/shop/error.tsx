"use client";

import { useEffect } from "react";
import { Button } from "@/components/ui/button";

export default function ShopError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    console.error(error);
  }, [error]);

  return (
    <div className="container flex flex-col items-center justify-center py-28 text-center">
      <p className="font-display text-lg font-semibold text-xfy-black">Couldn&apos;t load products.</p>
      <p className="mt-2 text-sm text-xfy-gray-500">Something went wrong fetching the catalog. Try again.</p>
      <Button variant="accent" size="lg" className="mt-6" onClick={reset}>Retry</Button>
    </div>
  );
}
