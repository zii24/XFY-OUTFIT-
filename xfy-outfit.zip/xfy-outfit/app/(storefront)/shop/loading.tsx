import { ProductGridSkeleton } from "@/components/product/product-grid";
import { Skeleton } from "@/components/ui/skeleton";

export default function ShopLoading() {
  return (
    <div className="container py-10 md:py-14">
      <Skeleton className="h-9 w-64" />
      <Skeleton className="mt-3 h-5 w-96" />
      <div className="mt-10 grid grid-cols-1 gap-10 md:grid-cols-[220px_1fr]">
        <Skeleton className="h-96 w-full" />
        <ProductGridSkeleton />
      </div>
    </div>
  );
}
