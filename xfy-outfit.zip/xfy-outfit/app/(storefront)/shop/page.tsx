import type { Metadata } from "next";
import { Suspense } from "react";
import { Skeleton } from "@/components/ui/skeleton";
import { getPublishedProducts } from "@/lib/data/products";
import { getPublishedBrands } from "@/lib/data/brands";
import { ProductGrid, ProductGridSkeleton } from "@/components/product/product-grid";
import { ShopFilters } from "@/components/product/shop-filters";
import { CATEGORIES, STYLES, SIZES } from "@/lib/constants";
import type { ProductFilters } from "@/types/product";

export const metadata: Metadata = {
  title: "Discover Fashion",
  description: "Explore curated pieces from independent fashion brands.",
};

interface SearchParams {
  category?: string;
  style?: string;
  brand?: string;
  size?: string;
  minPrice?: string;
  maxPrice?: string;
  xfy_selected?: string;
  availability?: string;
  sort?: string;
  q?: string;
}

export default async function ShopPage({ searchParams }: { searchParams: Promise<SearchParams> }) {
  const params = await searchParams;

  const filters: ProductFilters = {
    category: params.category,
    style: params.style,
    brand: params.brand,
    size: params.size,
    minPrice: params.minPrice ? Number(params.minPrice) : undefined,
    maxPrice: params.maxPrice ? Number(params.maxPrice) : undefined,
    xfySelected: params.xfy_selected === "1",
    availability: params.availability === "in-stock" ? "in-stock" : "all",
    sort: (params.sort as ProductFilters["sort"]) ?? "featured",
    q: params.q,
  };

  const [products, brands] = await Promise.all([getPublishedProducts(filters), getPublishedBrands()]);

  return (
    <div className="container py-10 md:py-14">
      <div className="mb-10 max-w-2xl">
        <h1 className="font-display text-3xl font-bold text-xfy-black md:text-4xl">Discover Fashion</h1>
        <p className="mt-3 text-sm text-xfy-gray-500 md:text-base">
          Explore curated pieces from independent fashion brands.
          {params.q && <> Showing results for <span className="font-medium text-xfy-black">&ldquo;{params.q}&rdquo;</span>.</>}
        </p>
      </div>

      <div className="grid grid-cols-1 gap-10 md:grid-cols-[220px_1fr]">
        <Suspense fallback={<Skeleton className="h-96 w-full" />}>
          <ShopFilters
            brands={brands.map((b) => ({ slug: b.slug, name: b.name }))}
            categories={CATEGORIES}
            styles={STYLES}
            sizes={SIZES}
            activeFilters={params}
            resultCount={products.length}
          />
        </Suspense>

        <div>
          <Suspense fallback={<ProductGridSkeleton />}>
            {products.length > 0 ? (
              <ProductGrid products={products} />
            ) : (
              <div className="flex flex-col items-center justify-center rounded-xfy border border-dashed border-xfy-gray-200 py-24 text-center">
                <p className="font-display text-lg font-semibold text-xfy-black">No pieces found.</p>
                <p className="mt-2 text-sm text-xfy-gray-500">Try a different category, style, or price range.</p>
                <a href="/shop" className="mt-5 text-sm font-medium text-xfy-blue hover:underline">
                  Clear filters
                </a>
              </div>
            )}
          </Suspense>
        </div>
      </div>
    </div>
  );
}
