"use client";

import Link from "next/link";
import Image from "next/image";
import { Minus, Plus, X, ShoppingBag } from "lucide-react";
import { useCart } from "@/context/cart-context";
import { Button } from "@/components/ui/button";
import { formatPrice } from "@/lib/utils";
import type { CartLine } from "@/types/order";

const DESTINATION_LABEL: Record<CartLine["destination"], string> = {
  xfy: "Checkout on XFY",
  shopee: "Buy on Shopee",
  etsy: "Buy on Etsy",
};

export default function CartPage() {
  const { lines, removeLine, updateQuantity, subtotalByDestination } = useCart();

  if (lines.length === 0) {
    return (
      <div className="container flex flex-col items-center justify-center py-28 text-center">
        <ShoppingBag className="h-10 w-10 text-xfy-gray-300" />
        <p className="mt-4 font-display text-xl font-semibold text-xfy-black">Your cart is empty.</p>
        <p className="mt-2 text-sm text-xfy-gray-500">Pieces you add will show up here, grouped by where you check out.</p>
        <Link href="/shop">
          <Button variant="accent" size="lg" className="mt-6">Continue shopping</Button>
        </Link>
      </div>
    );
  }

  const groups: Record<CartLine["destination"], CartLine[]> = { xfy: [], shopee: [], etsy: [] };
  for (const line of lines) groups[line.destination].push(line);

  return (
    <div className="container py-10 md:py-14">
      <h1 className="font-display text-3xl font-bold text-xfy-black">Your Cart</h1>
      <p className="mt-2 text-sm text-xfy-gray-500">
        Items are grouped by checkout destination — XFY can only process payment for XFY items.
      </p>

      <div className="mt-8 space-y-10">
        {(Object.keys(groups) as CartLine["destination"][]).map((dest) => {
          const group = groups[dest];
          if (group.length === 0) return null;
          return (
            <section key={dest}>
              <div className="mb-4 flex items-center justify-between">
                <h2 className="font-display text-lg font-semibold text-xfy-black">{DESTINATION_LABEL[dest]}</h2>
                <span className="text-sm text-xfy-gray-500">{formatPrice(subtotalByDestination[dest], "IDR")}</span>
              </div>
              <div className="divide-y divide-xfy-gray-200 rounded-xfy border border-xfy-gray-200">
                {group.map((line) => (
                  <div key={line.id} className="flex gap-4 p-4">
                    <div className="relative h-24 w-20 shrink-0 overflow-hidden rounded-xfy bg-xfy-gray-100">
                      {line.image && <Image src={line.image} alt={line.name} fill sizes="80px" className="object-cover" />}
                    </div>
                    <div className="flex flex-1 flex-col justify-between">
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <p className="text-xs font-medium uppercase tracking-wide text-xfy-gray-500">{line.brandName}</p>
                          <Link href={`/product/${line.slug}`} className="text-sm font-medium text-xfy-black hover:underline">
                            {line.name}
                          </Link>
                          {line.variant && <p className="mt-0.5 text-xs text-xfy-gray-500">{line.variant}</p>}
                        </div>
                        <button aria-label={`Remove ${line.name}`} onClick={() => removeLine(line.id)} className="text-xfy-gray-400 hover:text-xfy-black">
                          <X className="h-4 w-4" />
                        </button>
                      </div>
                      <div className="flex items-center justify-between">
                        {dest === "xfy" ? (
                          <div className="inline-flex items-center rounded-xfy border border-xfy-gray-200">
                            <button
                              aria-label="Decrease quantity"
                              onClick={() => updateQuantity(line.id, line.quantity - 1)}
                              className="flex h-8 w-8 items-center justify-center hover:bg-xfy-gray-50"
                            >
                              <Minus className="h-3 w-3" />
                            </button>
                            <span className="w-8 text-center text-sm">{line.quantity}</span>
                            <button
                              aria-label="Increase quantity"
                              onClick={() => updateQuantity(line.id, line.quantity + 1)}
                              className="flex h-8 w-8 items-center justify-center hover:bg-xfy-gray-50"
                            >
                              <Plus className="h-3 w-3" />
                            </button>
                          </div>
                        ) : (
                          <span className="text-xs text-xfy-gray-500">Qty {line.quantity} · continue on {DESTINATION_LABEL[dest].replace("Buy on ", "")}</span>
                        )}
                        <span className="text-sm font-semibold text-xfy-black">{formatPrice(line.unitPrice * line.quantity, "IDR")}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {dest === "xfy" ? (
                <div className="mt-4 flex justify-end">
                  <Link href="/checkout">
                    <Button variant="accent" size="lg">Checkout on XFY</Button>
                  </Link>
                </div>
              ) : (
                <div className="mt-4 space-y-2">
                  {group.map(
                    (line) =>
                      line.externalUrl && (
                        <a key={line.id} href={line.externalUrl} target="_blank" rel="noopener noreferrer">
                          <Button variant="outline" size="sm" className="mr-2">
                            Continue &ldquo;{line.name}&rdquo; on {dest === "shopee" ? "Shopee" : "Etsy"}
                          </Button>
                        </a>
                      )
                  )}
                  <p className="text-xs text-xfy-gray-500">
                    XFY doesn&apos;t process payment for {dest === "shopee" ? "Shopee" : "Etsy"} items — you&apos;ll complete purchase on their site.
                  </p>
                </div>
              )}
            </section>
          );
        })}
      </div>

      <div className="mt-10">
        <Link href="/shop" className="text-sm font-medium text-xfy-black hover:text-xfy-blue">
          ← Continue shopping
        </Link>
      </div>
    </div>
  );
}
