import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "About",
  description: "XFY Outfit helps small fashion brands and UMKM reach customers through curated discovery.",
};

export default function AboutPage() {
  return (
    <div className="container max-w-2xl py-14 md:py-20">
      <h1 className="font-display text-3xl font-bold text-xfy-black md:text-4xl">About XFY</h1>
      <p className="mt-5 text-base leading-relaxed text-xfy-gray-700">
        XFY helps small fashion brands and UMKM reach customers through curated product discovery, brand
        storytelling, content, and commerce. We&apos;re not a thrift store, and we&apos;re not a generic marketplace —
        every brand and product on XFY is chosen because it fits our fashion edit.
      </p>
      <p className="mt-4 text-base leading-relaxed text-xfy-gray-700">
        We started with one question: how do you find a fashion brand you&apos;ve never heard of, made by someone
        pouring real effort into it, without wading through a marketplace built for volume instead of taste? XFY is
        our answer — curation first, commerce second.
      </p>

      <h2 id="contact" className="mt-12 font-display text-xl font-bold text-xfy-black">Contact</h2>
      <p className="mt-3 text-sm leading-relaxed text-xfy-gray-700">
        For partnership or brand inquiries, reach us at <a href="mailto:hello@xfyoutfit.com" className="text-xfy-blue hover:underline">hello@xfyoutfit.com</a>.
      </p>

      <h2 id="privacy" className="mt-12 font-display text-xl font-bold text-xfy-black">Privacy Policy</h2>
      <p className="mt-3 text-sm leading-relaxed text-xfy-gray-700">
        We collect the information you give us at checkout — name, email, phone, and shipping address — solely to
        fulfil your order and communicate with you about it. We don&apos;t sell your data. Wishlist and guest cart
        data is stored only in your browser and never sent to our servers unless you check out.
      </p>

      <h2 id="terms" className="mt-12 font-display text-xl font-bold text-xfy-black">Terms</h2>
      <p className="mt-3 text-sm leading-relaxed text-xfy-gray-700">
        Products marked &ldquo;Buy on XFY&rdquo; are sold and fulfilled by XFY. Products linked to Shopee or Etsy are
        sold and fulfilled entirely by the third-party seller on that platform — XFY has no role in that payment or
        delivery. Placeholder terms for MVP; replace with counsel-reviewed terms before public launch.
      </p>
    </div>
  );
}
