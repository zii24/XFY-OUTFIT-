import type { Metadata } from "next";
import { getPublishedBrands } from "@/lib/data/brands";
import { BrandCard } from "@/components/brand/brand-card";

export const metadata: Metadata = {
  title: "Brands",
  description: "Discover independent fashion brands from Indonesia, curated by XFY.",
};

export default async function BrandsPage() {
  const brands = await getPublishedBrands();

  return (
    <div className="container py-10 md:py-14">
      <div className="mb-10 max-w-2xl">
        <h1 className="font-display text-3xl font-bold text-xfy-black md:text-4xl">Brands</h1>
        <p className="mt-3 text-sm text-xfy-gray-500 md:text-base">
          Independent labels we&apos;ve found, vetted, and think deserve a wider audience.
        </p>
      </div>

      {brands.length > 0 ? (
        <div className="grid grid-cols-2 gap-5 md:grid-cols-3 lg:grid-cols-4">
          {brands.map((brand) => (
            <BrandCard key={brand.id} brand={brand} />
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center rounded-xfy border border-dashed border-xfy-gray-200 py-24 text-center">
          <p className="font-display text-lg font-semibold text-xfy-black">No brands published yet.</p>
        </div>
      )}
    </div>
  );
}
