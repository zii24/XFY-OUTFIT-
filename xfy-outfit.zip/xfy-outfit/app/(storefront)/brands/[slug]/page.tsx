import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Image from "next/image";
import { Instagram, Music2, Globe, MapPin } from "lucide-react";
import { getBrandBySlug } from "@/lib/data/brands";
import { getPublishedProducts } from "@/lib/data/products";
import { ProductGrid } from "@/components/product/product-grid";

interface Props {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const brand = await getBrandBySlug(slug);
  if (!brand) return {};
  return { title: brand.name, description: brand.description ?? `${brand.name} on XFY Outfit.` };
}

export default async function BrandDetailPage({ params }: Props) {
  const { slug } = await params;
  const brand = await getBrandBySlug(slug);
  if (!brand) notFound();

  const products = await getPublishedProducts({ brand: brand.slug });

  return (
    <div>
      <div className="relative h-64 w-full overflow-hidden bg-xfy-navy md:h-80">
        <Image
          src={brand.cover_image_url ?? `https://picsum.photos/seed/${brand.slug}-cover/1600/700`}
          alt={brand.name}
          fill
          priority
          className="object-cover opacity-80"
        />
      </div>

      <div className="container -mt-14 pb-14">
        <div className="relative flex items-end gap-4">
          <div className="relative h-24 w-24 shrink-0 overflow-hidden rounded-full border-4 border-white bg-xfy-gray-100 shadow-sm md:h-28 md:w-28">
            {brand.logo_url && <Image src={brand.logo_url} alt={brand.name} fill className="object-cover" />}
          </div>
        </div>

        <div className="mt-5 flex flex-col justify-between gap-4 md:flex-row md:items-end">
          <div>
            <h1 className="font-display text-3xl font-bold text-xfy-black">{brand.name}</h1>
            <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-xfy-gray-500">
              {brand.location && (
                <span className="flex items-center gap-1"><MapPin className="h-3.5 w-3.5" /> {brand.location}</span>
              )}
              {brand.founded_year && <span>Founded {brand.founded_year}</span>}
              {brand.style_tags && brand.style_tags.length > 0 && <span>{brand.style_tags.join(" · ")}</span>}
            </div>
          </div>
          <div className="flex gap-2">
            {brand.website_url && (
              <a href={brand.website_url} target="_blank" rel="noopener noreferrer" aria-label={`${brand.name} website`} className="flex h-10 w-10 items-center justify-center rounded-full border border-xfy-gray-200 hover:border-xfy-black">
                <Globe className="h-4 w-4" />
              </a>
            )}
            {brand.instagram_url && (
              <a href={brand.instagram_url} target="_blank" rel="noopener noreferrer" aria-label={`${brand.name} on Instagram`} className="flex h-10 w-10 items-center justify-center rounded-full border border-xfy-gray-200 hover:border-xfy-black">
                <Instagram className="h-4 w-4" />
              </a>
            )}
            {brand.tiktok_url && (
              <a href={brand.tiktok_url} target="_blank" rel="noopener noreferrer" aria-label={`${brand.name} on TikTok`} className="flex h-10 w-10 items-center justify-center rounded-full border border-xfy-gray-200 hover:border-xfy-black">
                <Music2 className="h-4 w-4" />
              </a>
            )}
          </div>
        </div>

        {(brand.story || brand.description) && (
          <div className="mt-8 max-w-2xl space-y-4 text-sm leading-relaxed text-xfy-gray-700">
            <p>{brand.story ?? brand.description}</p>
          </div>
        )}

        <div className="mt-8 rounded-xfy bg-xfy-blue-soft p-5">
          <p className="text-sm font-semibold text-xfy-blue-dark">XFY curation note</p>
          <p className="mt-2 text-sm leading-relaxed text-xfy-navy">
            {brand.name} is part of the XFY edit for its distinctive point of view and consistent quality — this is
            our take, not a claim about the brand&apos;s own marketing.
          </p>
        </div>

        <div className="mt-14">
          <h2 className="mb-8 font-display text-2xl font-bold text-xfy-black">From {brand.name}</h2>
          {products.length > 0 ? (
            <ProductGrid products={products} />
          ) : (
            <p className="text-sm text-xfy-gray-500">No published products from this brand yet.</p>
          )}
        </div>
      </div>
    </div>
  );
}
