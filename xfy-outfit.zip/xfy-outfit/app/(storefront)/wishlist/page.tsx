"use client";

import Link from "next/link";
import Image from "next/image";
import { Heart, X } from "lucide-react";
import { useWishlist } from "@/context/wishlist-context";
import { useCart } from "@/context/cart-context";
import { Button } from "@/components/ui/button";
import { formatPrice } from "@/lib/utils";

export default function WishlistPage() {
  const { items, remove } = useWishlist();
  const { addLine } = useCart();

  if (items.length === 0) {
    return (
      <div className="container flex flex-col items-center justify-center py-28 text-center">
        <Heart className="h-10 w-10 text-xfy-gray-300" />
        <p className="mt-4 font-display text-xl font-semibold text-xfy-black">Your wishlist is empty.</p>
        <p className="mt-2 text-sm text-xfy-gray-500">Tap the heart on any product to save it here.</p>
        <Link href="/shop">
          <Button variant="accent" size="lg" className="mt-6">Explore products</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="container py-10 md:py-14">
      <h1 className="font-display text-3xl font-bold text-xfy-black">Wishlist</h1>
      <p className="mt-2 text-sm text-xfy-gray-500">{items.length} saved {items.length === 1 ? "piece" : "pieces"}.</p>

      <div className="mt-8 grid grid-cols-2 gap-x-4 gap-y-8 md:grid-cols-4">
        {items.map((item) => (
          <div key={item.productId} className="group relative">
            <button
              aria-label={`Remove ${item.name} from wishlist`}
              onClick={() => remove(item.productId)}
              className="absolute right-3 top-3 z-10 flex h-8 w-8 items-center justify-center rounded-full bg-white/90 text-xfy-black shadow-sm"
            >
              <X className="h-4 w-4" />
            </button>
            <Link href={`/product/${item.slug}`} className="block">
              <div className="relative aspect-[4/5] overflow-hidden rounded-xfy bg-xfy-gray-100">
                {item.image && <Image src={item.image} alt={item.name} fill sizes="25vw" className="object-cover" />}
                {!item.inStock && (
                  <span className="absolute bottom-3 left-3 rounded-full bg-xfy-black px-2.5 py-1 text-xs font-medium text-white">Sold out</span>
                )}
              </div>
              <p className="mt-3 text-xs font-medium uppercase tracking-wide text-xfy-gray-500">{item.brandName}</p>
              <p className="text-sm font-medium text-xfy-black">{item.name}</p>
              <p className="text-sm font-semibold text-xfy-black">{formatPrice(item.salePrice ?? item.price, "IDR")}</p>
            </Link>
            {item.inStock && (
              <Button
                variant="outline"
                size="sm"
                className="mt-2 w-full"
                onClick={() =>
                  addLine({
                    id: `${item.productId}-default`,
                    productId: item.productId,
                    slug: item.slug,
                    name: item.name,
                    brandName: item.brandName,
                    image: item.image,
                    unitPrice: item.salePrice ?? item.price,
                    quantity: 1,
                    variant: null,
                    destination: "xfy",
                    externalUrl: null,
                    maxStock: 99,
                  })
                }
              >
                Move to cart
              </Button>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
