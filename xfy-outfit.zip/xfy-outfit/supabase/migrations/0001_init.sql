-- XFY Outfit — initial schema
-- Run in the Supabase SQL editor, or via `supabase db push` with the CLI.

create extension if not exists "pgcrypto";

-- ─────────────────────────────────────────────────────────────────────────
-- Tables
-- ─────────────────────────────────────────────────────────────────────────

create table brands (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  description text,
  story text,
  logo_url text,
  cover_image_url text,
  location text,
  founded_year int,
  website_url text,
  instagram_url text,
  tiktok_url text,
  style_tags text[] default '{}',
  is_featured boolean not null default false,
  status text not null default 'draft' check (status in ('draft','published','archived')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table products (
  id uuid primary key default gen_random_uuid(),
  brand_id uuid not null references brands(id) on delete restrict,
  name text not null,
  slug text not null unique,
  description text,
  curation_note text,
  price numeric(12,2) not null check (price >= 0),
  sale_price numeric(12,2) check (sale_price is null or sale_price >= 0),
  currency text not null default 'IDR',
  category text not null,
  style text not null,
  material text,
  fit text,
  origin text,
  condition text,
  sku text,
  stock int not null default 0 check (stock >= 0),
  featured boolean not null default false,
  xfy_selected boolean not null default false,
  status text not null default 'draft' check (status in ('draft','review','published','archived')),
  shopee_url text,
  etsy_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index products_status_idx on products(status);
create index products_brand_idx on products(brand_id);
create index products_category_idx on products(category);
create index products_style_idx on products(style);

create table product_images (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references products(id) on delete cascade,
  image_url text not null,
  alt_text text,
  sort_order int not null default 0
);
create index product_images_product_idx on product_images(product_id);

create table product_variants (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references products(id) on delete cascade,
  type text not null check (type in ('size','color')),
  name text not null,
  value text not null,
  stock int not null default 0 check (stock >= 0)
);
create index product_variants_product_idx on product_variants(product_id);

create table collections (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  description text,
  cover_image_url text,
  status text not null default 'draft' check (status in ('draft','published','archived')),
  sort_order int not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table collection_products (
  collection_id uuid not null references collections(id) on delete cascade,
  product_id uuid not null references products(id) on delete cascade,
  sort_order int not null default 0,
  primary key (collection_id, product_id)
);

create table customers (
  id uuid primary key default gen_random_uuid(),
  email text not null unique,
  name text not null,
  phone text,
  created_at timestamptz not null default now()
);

create table orders (
  id uuid primary key default gen_random_uuid(),
  order_number text not null unique,
  customer_id uuid not null references customers(id) on delete restrict,
  status text not null default 'pending' check (status in ('pending','confirmed','processing','shipped','delivered','cancelled')),
  payment_status text not null default 'pending_manual' check (payment_status in ('pending_manual','awaiting_payment','paid','failed','refunded')),
  shipping_status text not null default 'not_shipped' check (shipping_status in ('not_shipped','packed','shipped','delivered')),
  subtotal numeric(12,2) not null,
  shipping_cost numeric(12,2) not null default 0,
  total numeric(12,2) not null,
  currency text not null default 'IDR',
  shipping_address jsonb not null,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index orders_customer_idx on orders(customer_id);

create table order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references orders(id) on delete cascade,
  product_id uuid references products(id) on delete set null,
  product_name_snapshot text not null,
  brand_name_snapshot text not null,
  quantity int not null check (quantity > 0),
  unit_price numeric(12,2) not null,
  variant_snapshot text
);
create index order_items_order_idx on order_items(order_id);

create table wishlist_items (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid not null references customers(id) on delete cascade,
  product_id uuid not null references products(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (customer_id, product_id)
);
-- Note: V1 wishlist is guest/localStorage-based (see context/wishlist-context.tsx).
-- This table exists so server-side sync can be turned on later without a migration.

create table journal_articles (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text not null unique,
  excerpt text,
  cover_image_url text,
  body_markdown text,
  status text not null default 'draft' check (status in ('draft','published')),
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table brand_submissions (
  id uuid primary key default gen_random_uuid(),
  brand_name text not null,
  contact_name text not null,
  email text not null,
  instagram_url text,
  website_url text,
  city text,
  style_description text not null,
  status text not null default 'new' check (status in ('new','reviewing','approved','declined')),
  created_at timestamptz not null default now()
);

create table site_settings (
  id int primary key default 1 check (id = 1), -- single row
  hero_title text not null default 'Discover Independent Fashion from Indonesia.',
  hero_subtitle text not null default 'Find unique pieces, emerging labels, and fashion brands worth discovering.',
  hero_image_url text not null default 'https://picsum.photos/seed/xfy-hero/1600/2000',
  hero_cta_label text not null default 'Explore Collection',
  hero_cta_href text not null default '/shop',
  hero_secondary_cta_label text not null default 'Discover Brands',
  hero_secondary_cta_href text not null default '/brands',
  announcement_text text not null default 'Discover independent fashion from Indonesia.',
  announcement_enabled boolean not null default true,
  updated_at timestamptz not null default now()
);
insert into site_settings (id) values (1);

-- Admin users: a row here (linked to a Supabase Auth user) grants dashboard
-- access. Insert rows by hand — see README "Admin access". Never expose
-- this table's existence-check result beyond the boolean it already is.
create table admin_users (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references auth.users(id) on delete cascade,
  email text not null,
  created_at timestamptz not null default now()
);

-- ─────────────────────────────────────────────────────────────────────────
-- updated_at triggers
-- ─────────────────────────────────────────────────────────────────────────

create or replace function set_updated_at() returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

create trigger brands_set_updated_at before update on brands for each row execute function set_updated_at();
create trigger products_set_updated_at before update on products for each row execute function set_updated_at();
create trigger collections_set_updated_at before update on collections for each row execute function set_updated_at();
create trigger orders_set_updated_at before update on orders for each row execute function set_updated_at();
create trigger journal_set_updated_at before update on journal_articles for each row execute function set_updated_at();

-- ─────────────────────────────────────────────────────────────────────────
-- Row Level Security
-- ─────────────────────────────────────────────────────────────────────────

alter table brands enable row level security;
alter table products enable row level security;
alter table product_images enable row level security;
alter table product_variants enable row level security;
alter table collections enable row level security;
alter table collection_products enable row level security;
alter table customers enable row level security;
alter table orders enable row level security;
alter table order_items enable row level security;
alter table wishlist_items enable row level security;
alter table journal_articles enable row level security;
alter table brand_submissions enable row level security;
alter table site_settings enable row level security;
alter table admin_users enable row level security;

-- Helper: is the current session an admin?
create or replace function is_admin() returns boolean as $$
  select exists (select 1 from admin_users where user_id = auth.uid());
$$ language sql stable security definer;

-- Public read: published rows only
create policy "public read published brands" on brands for select using (status = 'published' or is_admin());
create policy "public read published products" on products for select using (status = 'published' or is_admin());
create policy "public read product images" on product_images for select using (
  exists (select 1 from products p where p.id = product_images.product_id and (p.status = 'published' or is_admin()))
);
create policy "public read product variants" on product_variants for select using (
  exists (select 1 from products p where p.id = product_variants.product_id and (p.status = 'published' or is_admin()))
);
create policy "public read published collections" on collections for select using (status = 'published' or is_admin());
create policy "public read collection products" on collection_products for select using (true);
create policy "public read published journal" on journal_articles for select using (status = 'published' or is_admin());
create policy "public read site settings" on site_settings for select using (true);

-- Admin-only write on catalog tables
create policy "admin write brands" on brands for all using (is_admin()) with check (is_admin());
create policy "admin write products" on products for all using (is_admin()) with check (is_admin());
create policy "admin write product images" on product_images for all using (is_admin()) with check (is_admin());
create policy "admin write product variants" on product_variants for all using (is_admin()) with check (is_admin());
create policy "admin write collections" on collections for all using (is_admin()) with check (is_admin());
create policy "admin write collection products" on collection_products for all using (is_admin()) with check (is_admin());
create policy "admin write journal" on journal_articles for all using (is_admin()) with check (is_admin());
create policy "admin write site settings" on site_settings for update using (is_admin()) with check (is_admin());

-- Checkout: anyone can create a customer/order (guest checkout), server action
-- validates everything before insert. No one — including admins via the
-- anon-key path — can read another customer's data back through these
-- policies except the admin read policy below.
create policy "anyone can create a customer" on customers for insert with check (true);
create policy "admin read customers" on customers for select using (is_admin());
create policy "admin update customers" on customers for update using (is_admin());

create policy "anyone can create an order" on orders for insert with check (true);
create policy "admin read orders" on orders for select using (is_admin());
create policy "admin update orders" on orders for update using (is_admin());

create policy "anyone can create order items" on order_items for insert with check (true);
create policy "admin read order items" on order_items for select using (is_admin());

-- Wishlist (server-side sync, reserved for a future authenticated-customer flow)
create policy "admin read wishlist" on wishlist_items for select using (is_admin());

-- Brand submissions: public can submit, only admins can read/triage
create policy "anyone can submit a brand" on brand_submissions for insert with check (true);
create policy "admin read brand submissions" on brand_submissions for select using (is_admin());
create policy "admin update brand submissions" on brand_submissions for update using (is_admin());

-- admin_users: only readable by the row's own user (for the middleware
-- check) and by existing admins (so the dashboard can eventually list team members)
create policy "self read admin row" on admin_users for select using (user_id = auth.uid() or is_admin());
