-- XFY Outfit — demo seed data
-- All brands and products are FICTIONAL, created for development only.
-- Do not present them as real Indonesian businesses. Run after 0001_init.sql.

-- ─────────────────────────────────────────────────────────────────────────
-- Brands (6)
-- ─────────────────────────────────────────────────────────────────────────

insert into brands (name, slug, description, story, logo_url, cover_image_url, location, founded_year, website_url, instagram_url, style_tags, is_featured, status) values
('NOMADS Studio', 'nomads-studio', 'Utilitarian streetwear built for movement, cut from technical fabrics.', 'NOMADS Studio started as a two-person pattern-cutting project in a shared Bandung workshop, focused on garments that hold up to actual daily wear rather than just look good in a lookbook.', 'https://picsum.photos/seed/nomads-logo/200/200', 'https://picsum.photos/seed/nomads-cover/1600/900', 'Bandung, Indonesia', 2021, 'https://example.com/nomads', 'https://instagram.com/nomads.studio', array['Streetwear','Workwear'], true, 'published'),
('Ravenco', 'ravenco', 'Dark minimal silhouettes with an emphasis on drape and proportion.', 'Ravenco is a small atelier exploring how oversized silhouettes can still feel considered — every piece is sampled and re-cut at least three times before it ships.', 'https://picsum.photos/seed/ravenco-logo/200/200', 'https://picsum.photos/seed/ravenco-cover/1600/900', 'Jakarta, Indonesia', 2020, 'https://example.com/ravenco', 'https://instagram.com/ravenco.id', array['Minimal'], true, 'published'),
('Sierra Atelier', 'sierra-atelier', 'Vintage-inspired pieces reworked from deadstock fabric.', 'Sierra Atelier sources deadstock rolls from closing textile mills across Java and reworks them into small, numbered runs — no piece is restocked once it sells out.', 'https://picsum.photos/seed/sierra-logo/200/200', 'https://picsum.photos/seed/sierra-cover/1600/900', 'Yogyakarta, Indonesia', 2019, 'https://example.com/sierra', 'https://instagram.com/sierra.atelier', array['Vintage'], false, 'published'),
('Scandia Works', 'scandia-works', 'Clean, low-contrast basics designed to layer.', 'Scandia Works keeps a tight core wardrobe of six silhouettes, refined slowly across seasons rather than replaced by trend cycles.', 'https://picsum.photos/seed/scandia-logo/200/200', 'https://picsum.photos/seed/scandia-cover/1600/900', 'Surabaya, Indonesia', 2022, 'https://example.com/scandia', 'https://instagram.com/scandia.works', array['Minimal','Workwear'], false, 'published'),
('Urban Form', 'urban-form', 'Y2K-leaning cuts with a contemporary finish.', 'Urban Form revisits early-2000s silhouettes — low-rise, cropped, boxy — through better fabric and construction than the originals ever had.', 'https://picsum.photos/seed/urbanform-logo/200/200', 'https://picsum.photos/seed/urbanform-cover/1600/900', 'Jakarta, Indonesia', 2023, 'https://example.com/urbanform', 'https://instagram.com/urban.form', array['Y2K','Streetwear'], true, 'published'),
('Atelier North', 'atelier-north', 'Considered outerwear made in small batches.', 'Atelier North makes one outerwear drop per season, capped at 150 units per style, and publishes the exact production count with every release.', 'https://picsum.photos/seed/atelnorth-logo/200/200', 'https://picsum.photos/seed/atelnorth-cover/1600/900', 'Bogor, Indonesia', 2021, 'https://example.com/ateliernorth', 'https://instagram.com/atelier.north', array['Minimal','Workwear'], false, 'published');

-- ─────────────────────────────────────────────────────────────────────────
-- Products (24 — 4 per brand)
-- ─────────────────────────────────────────────────────────────────────────

insert into products (brand_id, name, slug, description, curation_note, price, sale_price, category, style, material, fit, origin, condition, sku, stock, featured, xfy_selected, status, shopee_url, etsy_url) values
((select id from brands where slug='nomads-studio'), 'Cargo Utility Jacket', 'nomads-cargo-utility-jacket', 'A boxy utility jacket with reinforced pockets and a drawcord hem, cut from a brushed cotton twill.', 'Selected for its distinctive pocket placement and the weight of the twill — it holds structure without feeling stiff.', 890000, 750000, 'outerwear', 'streetwear', 'Cotton twill', 'Oversized', 'Bandung, Indonesia', 'New', 'NMD-CUJ-01', 14, true, true, 'published', 'https://shopee.co.id/nomads-cargo-jacket', null),
((select id from brands where slug='nomads-studio'), 'Technical Cargo Pants', 'nomads-technical-cargo-pants', 'Water-resistant cargo trousers with articulated knees and a tapered leg.', null, 620000, null, 'bottoms', 'streetwear', 'Nylon-cotton blend', 'Tapered', 'Bandung, Indonesia', 'New', 'NMD-TCP-02', 20, false, false, 'published', 'https://shopee.co.id/nomads-cargo-pants', null),
((select id from brands where slug='nomads-studio'), 'Boxy Logo Tee', 'nomads-boxy-logo-tee', 'Heavyweight cotton tee with a small woven label at the hem.', null, 285000, null, 'tops', 'streetwear', '240gsm cotton', 'Boxy', 'Bandung, Indonesia', 'New', 'NMD-BLT-03', 30, false, false, 'published', null, null),
((select id from brands where slug='nomads-studio'), 'Nylon Shoulder Bag', 'nomads-nylon-shoulder-bag', 'Compact crossbody bag with a magnetic clasp and adjustable strap.', null, 340000, null, 'accessories', 'streetwear', 'Ripstop nylon', 'One size', 'Bandung, Indonesia', 'New', 'NMD-NSB-04', 18, false, false, 'published', null, 'https://etsy.com/listing/nomads-shoulder-bag'),

((select id from brands where slug='ravenco'), 'Draped Wool Coat', 'ravenco-draped-wool-coat', 'Floor-grazing wool coat with an asymmetric front closure.', 'This is the piece that made us pay attention to Ravenco — the drape reads considered, not just oversized for its own sake.', 1450000, null, 'outerwear', 'minimal', 'Wool blend', 'Oversized', 'Jakarta, Indonesia', 'New', 'RVC-DWC-01', 8, true, true, 'published', null, null),
((select id from brands where slug='ravenco'), 'Wide-Leg Trousers', 'ravenco-wide-leg-trousers', 'High-waisted wide-leg trousers in a matte crepe.', null, 540000, 460000, 'bottoms', 'minimal', 'Crepe', 'Wide leg', 'Jakarta, Indonesia', 'New', 'RVC-WLT-02', 16, false, false, 'published', 'https://shopee.co.id/ravenco-wide-trousers', null),
((select id from brands where slug='ravenco'), 'Asymmetric Knit Top', 'ravenco-asymmetric-knit-top', 'Fine-gauge knit with a single dropped shoulder.', null, 410000, null, 'tops', 'minimal', 'Merino blend', 'Relaxed', 'Jakarta, Indonesia', 'New', 'RVC-AKT-03', 12, false, true, 'published', null, null),
((select id from brands where slug='ravenco'), 'Sculpted Midi Dress', 'ravenco-sculpted-midi-dress', 'A minimal midi dress with a structured neckline and side slit.', null, 780000, null, 'dresses', 'minimal', 'Ponte knit', 'Fitted', 'Jakarta, Indonesia', 'New', 'RVC-SMD-04', 10, false, false, 'published', null, null),

((select id from brands where slug='sierra-atelier'), 'Reworked Denim Trucker', 'sierra-reworked-denim-trucker', 'A trucker jacket reconstructed from two vintage denim panels, no two pieces identical.', 'Every unit is genuinely one-of-a-kind — the curation note here is simple: this is the point of Sierra Atelier.', 950000, null, 'outerwear', 'vintage', 'Reclaimed denim', 'Regular', 'Yogyakarta, Indonesia', 'New (upcycled)', 'SRA-RDT-01', 6, true, true, 'published', null, 'https://etsy.com/listing/sierra-denim-trucker'),
((select id from brands where slug='sierra-atelier'), 'Corduroy Wide Pants', 'sierra-corduroy-wide-pants', 'Wide-leg trousers cut from deadstock wide-wale corduroy.', null, 480000, null, 'bottoms', 'vintage', 'Corduroy', 'Wide leg', 'Yogyakarta, Indonesia', 'New (deadstock fabric)', 'SRA-CWP-02', 15, false, false, 'published', null, null),
((select id from brands where slug='sierra-atelier'), 'Hand-Patched Flannel', 'sierra-hand-patched-flannel', 'Classic flannel shirt with hand-stitched patchwork panels.', null, 395000, 340000, 'tops', 'vintage', 'Cotton flannel', 'Regular', 'Yogyakarta, Indonesia', 'New (upcycled)', 'SRA-HPF-03', 9, false, false, 'published', null, null),
((select id from brands where slug='sierra-atelier'), 'Woven Market Tote', 'sierra-woven-market-tote', 'Sturdy woven tote made from remnant canvas offcuts.', null, 220000, null, 'accessories', 'vintage', 'Canvas', 'One size', 'Yogyakarta, Indonesia', 'New (upcycled)', 'SRA-WMT-04', 22, false, false, 'published', null, null),

((select id from brands where slug='scandia-works'), 'Boxy Wool Overshirt', 'scandia-boxy-wool-overshirt', 'A mid-weight wool overshirt designed to layer over a tee.', null, 720000, null, 'outerwear', 'minimal', 'Wool blend', 'Boxy', 'Surabaya, Indonesia', 'New', 'SCW-BWO-01', 11, false, false, 'published', 'https://shopee.co.id/scandia-overshirt', null),
((select id from brands where slug='scandia-works'), 'Straight Leg Trousers', 'scandia-straight-leg-trousers', 'Understated straight-leg trousers with a clean waistband.', null, 490000, null, 'bottoms', 'minimal', 'Cotton twill', 'Straight', 'Surabaya, Indonesia', 'New', 'SCW-SLT-02', 19, false, false, 'published', null, null),
((select id from brands where slug='scandia-works'), 'Ribbed Long Sleeve', 'scandia-ribbed-long-sleeve', 'Fine rib-knit long sleeve top in a low-contrast neutral.', null, 260000, null, 'tops', 'minimal', 'Cotton rib', 'Fitted', 'Surabaya, Indonesia', 'New', 'SCW-RLS-03', 26, false, false, 'published', null, null),
((select id from brands where slug='scandia-works'), 'Canvas Belt Bag', 'scandia-canvas-belt-bag', 'Minimal belt bag in waxed canvas with a brushed buckle.', null, 240000, null, 'accessories', 'minimal', 'Waxed canvas', 'One size', 'Surabaya, Indonesia', 'New', 'SCW-CBB-04', 17, false, false, 'published', null, null),

((select id from brands where slug='urban-form'), 'Low-Rise Cargo Skirt', 'urbanform-low-rise-cargo-skirt', 'Low-rise midi cargo skirt with utility pockets and a slit hem.', 'A genuinely well-made take on a Y2K staple — the pocket hardware alone is worth a closer look.', 460000, 390000, 'bottoms', 'y2k', 'Cotton twill', 'Low-rise', 'Jakarta, Indonesia', 'New', 'UF-LCS-01', 13, true, true, 'published', 'https://shopee.co.id/urbanform-cargo-skirt', null),
((select id from brands where slug='urban-form'), 'Cropped Zip Hoodie', 'urbanform-cropped-zip-hoodie', 'Cropped half-zip hoodie in a heavyweight brushed fleece.', null, 430000, null, 'tops', 'y2k', 'Cotton fleece', 'Cropped', 'Jakarta, Indonesia', 'New', 'UF-CZH-02', 21, false, false, 'published', null, null),
((select id from brands where slug='urban-form'), 'Baby Tee Mesh Overlay', 'urbanform-baby-tee-mesh-overlay', 'Fitted baby tee with a sheer mesh overlay panel.', null, 210000, null, 'tops', 'y2k', 'Cotton jersey, mesh', 'Fitted', 'Jakarta, Indonesia', 'New', 'UF-BTM-03', 24, false, false, 'published', null, null),
((select id from brands where slug='urban-form'), 'Chunky Platform Sneaker Bag Charm', 'urbanform-sneaker-bag-charm', 'Y2K-style novelty bag charm shaped like a chunky platform sneaker.', null, 95000, null, 'accessories', 'y2k', 'PVC, metal hardware', 'One size', 'Jakarta, Indonesia', 'New', 'UF-SBC-04', 40, false, false, 'published', null, null),

((select id from brands where slug='atelier-north'), 'Waxed Field Jacket', 'atelnorth-waxed-field-jacket', 'Waxed cotton field jacket with a corduroy collar and brass hardware.', 'A genuinely rare thing: outerwear that looks better after a year of wear. This is the kind of quality-over-hype pick XFY exists for.', 1120000, null, 'outerwear', 'workwear', 'Waxed cotton', 'Regular', 'Bogor, Indonesia', 'New', 'ATN-WFJ-01', 7, true, true, 'published', null, null),
((select id from brands where slug='atelier-north'), 'Canvas Work Pants', 'atelnorth-canvas-work-pants', 'Reinforced canvas work trousers with a tool loop.', null, 560000, null, 'bottoms', 'workwear', 'Cotton canvas', 'Straight', 'Bogor, Indonesia', 'New', 'ATN-CWP-02', 15, false, false, 'published', null, null),
((select id from brands where slug='atelier-north'), 'Chore Coat', 'atelnorth-chore-coat', 'Classic four-pocket chore coat in a washed cotton twill.', null, 680000, 590000, 'outerwear', 'workwear', 'Cotton twill', 'Regular', 'Bogor, Indonesia', 'New', 'ATN-CC-03', 12, false, false, 'published', null, null),
((select id from brands where slug='atelier-north'), 'Waxed Canvas Tool Roll', 'atelnorth-tool-roll', 'Compact waxed canvas roll for small tools or accessories.', null, 175000, null, 'accessories', 'workwear', 'Waxed canvas', 'One size', 'Bogor, Indonesia', 'New', 'ATN-WTR-04', 20, false, false, 'published', null, null);

-- ─────────────────────────────────────────────────────────────────────────
-- Product images (2 per product — primary + hover)
-- ─────────────────────────────────────────────────────────────────────────

insert into product_images (product_id, image_url, alt_text, sort_order)
select id, 'https://picsum.photos/seed/' || slug || '-a/900/1125', name, 0 from products
union all
select id, 'https://picsum.photos/seed/' || slug || '-b/900/1125', name, 1 from products;

-- ─────────────────────────────────────────────────────────────────────────
-- Variants — sizes for apparel, one color for a few
-- ─────────────────────────────────────────────────────────────────────────

insert into product_variants (product_id, type, name, value, stock)
select p.id, 'size', s.size, s.size, floor(random() * 6 + 1)::int
from products p
cross join (values ('XS'),('S'),('M'),('L'),('XL')) as s(size)
where p.category in ('tops','outerwear','bottoms','dresses');

insert into product_variants (product_id, type, name, value, stock)
select id, 'color', 'Black', '#111111', floor(random() * 6 + 1)::int from products where slug in ('nomads-boxy-logo-tee','scandia-ribbed-long-sleeve','urbanform-cropped-zip-hoodie')
union all
select id, 'color', 'Sand', '#D9C9AE', floor(random() * 6 + 1)::int from products where slug in ('nomads-boxy-logo-tee','scandia-ribbed-long-sleeve','urbanform-cropped-zip-hoodie');

-- ─────────────────────────────────────────────────────────────────────────
-- Collections (4) + assignments
-- ─────────────────────────────────────────────────────────────────────────

insert into collections (name, slug, description, cover_image_url, status, sort_order) values
('Streetwear Edit', 'streetwear-edit', 'Utility-driven pieces built for everyday movement.', 'https://picsum.photos/seed/col-streetwear/1200/1500', 'published', 1),
('Minimal Essentials', 'minimal-essentials', 'Quiet, considered basics that layer easily.', 'https://picsum.photos/seed/col-minimal/1200/1500', 'published', 2),
('Vintage Selection', 'vintage-selection', 'One-of-a-kind pieces reworked from deadstock and reclaimed fabric.', 'https://picsum.photos/seed/col-vintage/1200/1500', 'published', 3),
('New Arrivals', 'new-arrivals', 'The latest additions to the XFY edit.', 'https://picsum.photos/seed/col-new/1200/1500', 'published', 4);

insert into collection_products (collection_id, product_id, sort_order)
select (select id from collections where slug='streetwear-edit'), id, row_number() over ()
from products where style = 'streetwear';

insert into collection_products (collection_id, product_id, sort_order)
select (select id from collections where slug='minimal-essentials'), id, row_number() over ()
from products where style = 'minimal';

insert into collection_products (collection_id, product_id, sort_order)
select (select id from collections where slug='vintage-selection'), id, row_number() over ()
from products where style = 'vintage';

insert into collection_products (collection_id, product_id, sort_order)
select (select id from collections where slug='new-arrivals'), id, row_number() over ()
from products where featured = true;

-- ─────────────────────────────────────────────────────────────────────────
-- Journal articles (3)
-- ─────────────────────────────────────────────────────────────────────────

insert into journal_articles (title, slug, excerpt, cover_image_url, body_markdown, status, published_at) values
('Indonesian Streetwear Brands to Watch', 'indonesian-streetwear-brands-to-watch', 'A look at the independent labels reshaping streetwear out of Indonesia right now.', 'https://picsum.photos/seed/journal-streetwear/1200/800', 'Placeholder editorial body copy — replace with real reporting before launch. This article would cover labels, cutting techniques, and where the streetwear scene is heading next.', 'published', now() - interval '10 days'),
('How to Discover Independent Fashion', 'how-to-discover-independent-fashion', 'A practical guide to finding brands before they''re everywhere.', 'https://picsum.photos/seed/journal-discover/1200/800', 'Placeholder editorial body copy — replace with real reporting before launch. This article would cover how XFY finds and vets independent brands.', 'published', now() - interval '20 days'),
('The Story Behind Emerging Local Brands', 'the-story-behind-emerging-local-brands', 'What it actually takes to start a small fashion label in Indonesia today.', 'https://picsum.photos/seed/journal-story/1200/800', 'Placeholder editorial body copy — replace with real reporting before launch. This article would profile a founder''s path from first sample to first stockist.', 'published', now() - interval '30 days');

-- ─────────────────────────────────────────────────────────────────────────
-- Sample order data — CLEARLY DEMO, not a real transaction
-- ─────────────────────────────────────────────────────────────────────────

insert into customers (email, name, phone) values
('demo.customer@example.com', 'Demo Customer (seed data)', '+62-812-0000-0000');

insert into orders (order_number, customer_id, status, payment_status, shipping_status, subtotal, shipping_cost, total, currency, shipping_address, notes) values
('XFY-DEMO-0001', (select id from customers where email='demo.customer@example.com'), 'confirmed', 'paid', 'packed', 1225000, 15000, 1240000,'IDR',
 '{"full_name":"Demo Customer","phone":"+62-812-0000-0000","address_line":"Jl. Contoh No. 1","city":"Jakarta","province":"DKI Jakarta","postal_code":"12345","country":"Indonesia"}'::jsonb,
 'DEMO ORDER — seed data, not a real transaction.');

insert into order_items (order_id, product_id, product_name_snapshot, brand_name_snapshot, quantity, unit_price, variant_snapshot)
select (select id from orders where order_number='XFY-DEMO-0001'), id, name, (select name from brands where id = products.brand_id), 1, coalesce(sale_price, price), 'M'
from products where slug = 'nomads-cargo-utility-jacket';
