"use client";

import { useFormState, useFormStatus } from "react-dom";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { FieldError } from "@/components/ui/field-error";
import { CATEGORIES, STYLES } from "@/lib/constants";
import type { ActionState } from "@/lib/actions/products";
import type { ProductWithBrand } from "@/types/product";
import type { Brand } from "@/types/brand";
import type { Collection } from "@/types/collection";

function SubmitButton({ label }: { label: string }) {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" variant="accent" size="lg" disabled={pending}>
      {pending ? "Saving…" : label}
    </Button>
  );
}

interface Props {
  action: (state: ActionState, formData: FormData) => Promise<ActionState>;
  brands: Brand[];
  collections: Collection[];
  product?: ProductWithBrand & { collection_ids?: string[] };
  submitLabel: string;
}

export function ProductForm({ action, brands, collections, product, submitLabel }: Props) {
  const [state, formAction] = useFormState(action, undefined);

  return (
    <form action={formAction} className="space-y-8">
      {state?.error && (
        <div className="rounded-xfy border border-red-200 bg-red-50 p-4 text-sm text-red-700" role="alert">{state.error}</div>
      )}

      <section className="grid grid-cols-1 gap-5 rounded-xfy border border-xfy-gray-200 bg-white p-6 sm:grid-cols-2">
        <h2 className="font-display text-lg font-semibold text-xfy-black sm:col-span-2">Basics</h2>
        <div>
          <Label htmlFor="name">Product name</Label>
          <Input id="name" name="name" required defaultValue={product?.name} />
          <FieldError message={state?.fieldErrors?.name} />
        </div>
        <div>
          <Label htmlFor="slug">Slug</Label>
          <Input id="slug" name="slug" required defaultValue={product?.slug} placeholder="oversized-cargo-jacket" />
          <FieldError message={state?.fieldErrors?.slug} />
        </div>
        <div>
          <Label htmlFor="brand_id">Brand</Label>
          <Select id="brand_id" name="brand_id" required defaultValue={product?.brand_id}>
            <option value="">Select brand</option>
            {brands.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
          </Select>
          <FieldError message={state?.fieldErrors?.brand_id} />
        </div>
        <div>
          <Label htmlFor="status">Status</Label>
          <Select id="status" name="status" defaultValue={product?.status ?? "draft"}>
            <option value="draft">Draft</option>
            <option value="review">Review</option>
            <option value="published">Published</option>
            <option value="archived">Archived</option>
          </Select>
        </div>
        <div>
          <Label htmlFor="category">Category</Label>
          <Select id="category" name="category" required defaultValue={product?.category}>
            <option value="">Select category</option>
            {CATEGORIES.map((c) => <option key={c.slug} value={c.slug}>{c.name}</option>)}
          </Select>
          <FieldError message={state?.fieldErrors?.category} />
        </div>
        <div>
          <Label htmlFor="style">Style</Label>
          <Select id="style" name="style" required defaultValue={product?.style}>
            <option value="">Select style</option>
            {STYLES.map((s) => <option key={s.slug} value={s.slug}>{s.name}</option>)}
          </Select>
          <FieldError message={state?.fieldErrors?.style} />
        </div>
        <div className="sm:col-span-2">
          <Label htmlFor="description">Description</Label>
          <Textarea id="description" name="description" defaultValue={product?.description ?? ""} rows={4} />
        </div>
        <div className="sm:col-span-2">
          <Label htmlFor="curation_note">Curation note ("Why XFY picked this")</Label>
          <Textarea id="curation_note" name="curation_note" defaultValue={product?.curation_note ?? ""} rows={3} />
        </div>
      </section>

      <section className="grid grid-cols-1 gap-5 rounded-xfy border border-xfy-gray-200 bg-white p-6 sm:grid-cols-2">
        <h2 className="font-display text-lg font-semibold text-xfy-black sm:col-span-2">Pricing & stock</h2>
        <div>
          <Label htmlFor="price">Price (IDR)</Label>
          <Input id="price" name="price" type="number" min="0" required defaultValue={product?.price} />
          <FieldError message={state?.fieldErrors?.price} />
        </div>
        <div>
          <Label htmlFor="sale_price">Sale price (optional)</Label>
          <Input id="sale_price" name="sale_price" type="number" min="0" defaultValue={product?.sale_price ?? ""} />
        </div>
        <div>
          <Label htmlFor="stock">Stock</Label>
          <Input id="stock" name="stock" type="number" min="0" required defaultValue={product?.stock ?? 0} />
          <FieldError message={state?.fieldErrors?.stock} />
        </div>
        <div>
          <Label htmlFor="sku">SKU</Label>
          <Input id="sku" name="sku" defaultValue={product?.sku ?? ""} />
        </div>
        <input type="hidden" name="currency" value="IDR" />
      </section>

      <section className="grid grid-cols-1 gap-5 rounded-xfy border border-xfy-gray-200 bg-white p-6 sm:grid-cols-2">
        <h2 className="font-display text-lg font-semibold text-xfy-black sm:col-span-2">Details</h2>
        <div><Label htmlFor="material">Material</Label><Input id="material" name="material" defaultValue={product?.material ?? ""} /></div>
        <div><Label htmlFor="fit">Fit</Label><Input id="fit" name="fit" defaultValue={product?.fit ?? ""} /></div>
        <div><Label htmlFor="origin">Origin</Label><Input id="origin" name="origin" defaultValue={product?.origin ?? ""} placeholder="e.g. Bandung, Indonesia" /></div>
        <div><Label htmlFor="condition">Condition</Label><Input id="condition" name="condition" defaultValue={product?.condition ?? ""} placeholder="e.g. New" /></div>
      </section>

      <section className="space-y-4 rounded-xfy border border-xfy-gray-200 bg-white p-6">
        <h2 className="font-display text-lg font-semibold text-xfy-black">Images</h2>
        <div>
          <Label htmlFor="image_urls">Image URLs (one per line, first is primary)</Label>
          <Textarea
            id="image_urls"
            name="image_urls"
            rows={4}
            placeholder="https://…"
            defaultValue={product?.images?.map((i) => i.image_url).join("\n") ?? ""}
          />
          <p className="mt-1.5 text-xs text-xfy-gray-500">Upload to Supabase Storage first, then paste the public URL here. Direct file upload UI is not built in V1 — see README.</p>
        </div>
      </section>

      <section className="space-y-4 rounded-xfy border border-xfy-gray-200 bg-white p-6">
        <h2 className="font-display text-lg font-semibold text-xfy-black">Merchandising</h2>
        <label className="flex items-center gap-2 text-sm text-xfy-black">
          <input type="checkbox" name="featured" defaultChecked={product?.featured} className="h-4 w-4 rounded border-xfy-gray-300 text-xfy-blue" />
          Featured on homepage (XFY Picks)
        </label>
        <label className="flex items-center gap-2 text-sm text-xfy-black">
          <input type="checkbox" name="xfy_selected" defaultChecked={product?.xfy_selected} className="h-4 w-4 rounded border-xfy-gray-300 text-xfy-blue" />
          XFY Selected badge
        </label>
        {collections.length > 0 && (
          <div>
            <p className="mb-2 text-sm font-medium text-xfy-black">Collections</p>
            <div className="flex flex-wrap gap-3">
              {collections.map((c) => (
                <label key={c.id} className="flex items-center gap-2 text-sm text-xfy-gray-700">
                  <input
                    type="checkbox"
                    name="collection_ids"
                    value={c.id}
                    defaultChecked={product?.collection_ids?.includes(c.id)}
                    className="h-4 w-4 rounded border-xfy-gray-300 text-xfy-blue"
                  />
                  {c.name}
                </label>
              ))}
            </div>
          </div>
        )}
      </section>

      <section className="space-y-4 rounded-xfy border border-xfy-gray-200 bg-white p-6">
        <h2 className="font-display text-lg font-semibold text-xfy-black">External checkout links</h2>
        <p className="text-xs text-xfy-gray-500">Leave blank to hide that buy option on the product page — links are never invented.</p>
        <div>
          <Label htmlFor="shopee_url">Shopee URL</Label>
          <Input id="shopee_url" name="shopee_url" type="url" defaultValue={product?.shopee_url ?? ""} placeholder="https://shopee.co.id/…" />
          <FieldError message={state?.fieldErrors?.shopee_url} />
        </div>
        <div>
          <Label htmlFor="etsy_url">Etsy URL</Label>
          <Input id="etsy_url" name="etsy_url" type="url" defaultValue={product?.etsy_url ?? ""} placeholder="https://etsy.com/listing/…" />
          <FieldError message={state?.fieldErrors?.etsy_url} />
        </div>
      </section>

      <SubmitButton label={submitLabel} />
    </form>
  );
}
