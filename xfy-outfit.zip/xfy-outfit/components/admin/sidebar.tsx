"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { LayoutDashboard, Package, Building2, ShoppingCart, LayoutTemplate, FolderOpen, Newspaper, Settings, LogOut, ExternalLink } from "lucide-react";
import { cn } from "@/lib/utils";
import { createClient } from "@/lib/supabase/client";

const LINKS = [
  { href: "/admin", label: "Dashboard", icon: LayoutDashboard },
  { href: "/admin/products", label: "Products", icon: Package },
  { href: "/admin/brands", label: "Brands", icon: Building2 },
  { href: "/admin/orders", label: "Orders", icon: ShoppingCart },
  { href: "/admin/collections", label: "Collections", icon: FolderOpen },
  { href: "/admin/homepage", label: "Homepage", icon: LayoutTemplate },
  { href: "/admin/journal", label: "Journal", icon: Newspaper },
  { href: "/admin/settings", label: "Settings", icon: Settings },
];

export function AdminSidebar({ email }: { email: string }) {
  const pathname = usePathname();
  const router = useRouter();

  const handleLogout = async () => {
    const supabase = createClient();
    await supabase.auth.signOut();
    router.push("/admin/login");
    router.refresh();
  };

  return (
    <aside className="flex h-screen w-64 shrink-0 flex-col border-r border-xfy-gray-200 bg-white">
      <div className="flex h-16 items-center gap-2 border-b border-xfy-gray-200 px-5">
        <span className="font-display text-lg font-bold text-xfy-black">XFY</span>
        <span className="rounded-full bg-xfy-gray-100 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide text-xfy-gray-500">Admin</span>
      </div>

      <nav className="flex-1 space-y-1 overflow-y-auto p-3" aria-label="Admin">
        {LINKS.map((link) => {
          const active = pathname === link.href || (link.href !== "/admin" && pathname.startsWith(link.href));
          const Icon = link.icon;
          return (
            <Link
              key={link.href}
              href={link.href}
              className={cn(
                "flex items-center gap-2.5 rounded-xfy px-3 py-2.5 text-sm font-medium",
                active ? "bg-xfy-blue-soft text-xfy-blue-dark" : "text-xfy-gray-700 hover:bg-xfy-gray-50"
              )}
            >
              <Icon className="h-4 w-4" />
              {link.label}
            </Link>
          );
        })}
      </nav>

      <div className="border-t border-xfy-gray-200 p-3">
        <Link href="/" target="_blank" className="flex items-center gap-2.5 rounded-xfy px-3 py-2.5 text-sm text-xfy-gray-700 hover:bg-xfy-gray-50">
          <ExternalLink className="h-4 w-4" /> View storefront
        </Link>
        <div className="mt-2 flex items-center justify-between px-3 py-2">
          <span className="truncate text-xs text-xfy-gray-500">{email}</span>
          <button onClick={handleLogout} aria-label="Log out" className="text-xfy-gray-500 hover:text-xfy-black">
            <LogOut className="h-4 w-4" />
          </button>
        </div>
      </div>
    </aside>
  );
}
