"use client";

import { useFormState, useFormStatus } from "react-dom";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { FieldError } from "@/components/ui/field-error";
import type { ActionState } from "@/lib/actions/products";
import type { Brand } from "@/types/brand";

function SubmitButton({ label }: { label: string }) {
  const { pending } = useFormStatus();
  return <Button type="submit" variant="accent" size="lg" disabled={pending}>{pending ? "Saving…" : label}</Button>;
}

export function BrandForm({ action, brand, submitLabel }: { action: (s: ActionState, fd: FormData) => Promise<ActionState>; brand?: Brand; submitLabel: string }) {
  const [state, formAction] = useFormState(action, undefined);

  return (
    <form action={formAction} className="space-y-8">
      {state?.error && <div className="rounded-xfy border border-red-200 bg-red-50 p-4 text-sm text-red-700" role="alert">{state.error}</div>}

      <section className="grid grid-cols-1 gap-5 rounded-xfy border border-xfy-gray-200 bg-white p-6 sm:grid-cols-2">
        <div>
          <Label htmlFor="name">Brand name</Label>
          <Input id="name" name="name" required defaultValue={brand?.name} />
          <FieldError message={state?.fieldErrors?.name} />
        </div>
        <div>
          <Label htmlFor="slug">Slug</Label>
          <Input id="slug" name="slug" required defaultValue={brand?.slug} placeholder="nomads-studio" />
          <FieldError message={state?.fieldErrors?.slug} />
        </div>
        <div>
          <Label htmlFor="location">Location</Label>
          <Input id="location" name="location" defaultValue={brand?.location ?? ""} placeholder="e.g. Bandung, Indonesia" />
        </div>
        <div>
          <Label htmlFor="founded_year">Founded year</Label>
          <Input id="founded_year" name="founded_year" type="number" defaultValue={brand?.founded_year ?? ""} />
        </div>
        <div>
          <Label htmlFor="status">Status</Label>
          <Select id="status" name="status" defaultValue={brand?.status ?? "draft"}>
            <option value="draft">Draft</option>
            <option value="published">Published</option>
            <option value="archived">Archived</option>
          </Select>
        </div>
        <div>
          <Label htmlFor="style_tags">Style tags (comma separated)</Label>
          <Input id="style_tags" name="style_tags" defaultValue={brand?.style_tags?.join(", ") ?? ""} placeholder="Streetwear, Minimal" />
        </div>
        <div className="sm:col-span-2">
          <Label htmlFor="description">Short description</Label>
          <Textarea id="description" name="description" rows={2} defaultValue={brand?.description ?? ""} />
        </div>
        <div className="sm:col-span-2">
          <Label htmlFor="story">Brand story</Label>
          <Textarea id="story" name="story" rows={5} defaultValue={brand?.story ?? ""} placeholder="Founder story, if known — never fabricated." />
        </div>
      </section>

      <section className="grid grid-cols-1 gap-5 rounded-xfy border border-xfy-gray-200 bg-white p-6 sm:grid-cols-2">
        <h2 className="font-display text-lg font-semibold text-xfy-black sm:col-span-2">Media & links</h2>
        <div><Label htmlFor="logo_url">Logo URL</Label><Input id="logo_url" name="logo_url" type="url" defaultValue={brand?.logo_url ?? ""} /></div>
        <div><Label htmlFor="cover_image_url">Cover image URL</Label><Input id="cover_image_url" name="cover_image_url" type="url" defaultValue={brand?.cover_image_url ?? ""} /></div>
        <div><Label htmlFor="website_url">Website</Label><Input id="website_url" name="website_url" type="url" defaultValue={brand?.website_url ?? ""} /></div>
        <div><Label htmlFor="instagram_url">Instagram</Label><Input id="instagram_url" name="instagram_url" type="url" defaultValue={brand?.instagram_url ?? ""} /></div>
        <div><Label htmlFor="tiktok_url">TikTok</Label><Input id="tiktok_url" name="tiktok_url" type="url" defaultValue={brand?.tiktok_url ?? ""} /></div>
        <label className="flex items-center gap-2 self-end pb-2 text-sm text-xfy-black">
          <input type="checkbox" name="is_featured" defaultChecked={brand?.is_featured} className="h-4 w-4 rounded border-xfy-gray-300 text-xfy-blue" />
          Feature in Hidden Gems / New Brands
        </label>
      </section>

      <SubmitButton label={submitLabel} />
    </form>
  );
}
