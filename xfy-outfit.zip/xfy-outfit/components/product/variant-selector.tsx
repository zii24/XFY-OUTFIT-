"use client";

import { cn } from "@/lib/utils";
import type { ProductVariant } from "@/types/product";

interface Props {
  variants: ProductVariant[];
  type: "size" | "color";
  selected: string | null;
  onSelect: (value: string) => void;
}

export function VariantSelector({ variants, type, selected, onSelect }: Props) {
  const options = variants.filter((v) => v.type === type);
  if (options.length === 0) return null;

  return (
    <div>
      <p className="mb-2 text-sm font-medium text-xfy-black">{type === "size" ? "Size" : "Color"}</p>
      <div className="flex flex-wrap gap-2">
        {options.map((opt) => {
          const disabled = opt.stock <= 0;
          const isSelected = selected === opt.value;
          return (
            <button
              key={opt.id}
              type="button"
              disabled={disabled}
              aria-pressed={isSelected}
              onClick={() => onSelect(opt.value)}
              className={cn(
                "min-w-[44px] rounded-xfy border px-3.5 py-2 text-sm font-medium transition-colors",
                disabled && "cursor-not-allowed border-xfy-gray-200 text-xfy-gray-300 line-through",
                !disabled && isSelected && "border-xfy-black bg-xfy-black text-white",
                !disabled && !isSelected && "border-xfy-gray-200 text-xfy-black hover:border-xfy-black"
              )}
            >
              {opt.name}
            </button>
          );
        })}
      </div>
    </div>
  );
}
