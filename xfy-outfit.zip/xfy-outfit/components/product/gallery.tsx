"use client";

import Image from "next/image";
import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { X, ChevronLeft, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";
import type { ProductImage } from "@/types/product";

export function Gallery({ images, productName }: { images: ProductImage[]; productName: string }) {
  const [active, setActive] = useState(0);
  const [lightbox, setLightbox] = useState(false);
  const safeImages = images.length ? images : [{ id: "fallback", image_url: "https://picsum.photos/seed/xfy-fallback/1200/1500", alt_text: productName } as ProductImage];

  return (
    <div>
      <div className="grid grid-cols-[64px_1fr] gap-3 md:grid-cols-[80px_1fr]">
        <div className="flex flex-row gap-2 overflow-x-auto md:flex-col md:overflow-visible">
          {safeImages.map((img, i) => (
            <button
              key={img.id}
              onClick={() => setActive(i)}
              aria-label={`Show image ${i + 1}`}
              aria-current={active === i}
              className={cn(
                "relative aspect-[4/5] w-14 shrink-0 overflow-hidden rounded-xfy border md:w-full",
                active === i ? "border-xfy-black" : "border-transparent"
              )}
            >
              <Image src={img.image_url} alt="" fill sizes="80px" className="object-cover" />
            </button>
          ))}
        </div>
        <button
          onClick={() => setLightbox(true)}
          aria-label="Open image in full screen"
          className="relative aspect-[4/5] w-full overflow-hidden rounded-xfy bg-xfy-gray-100"
        >
          <Image
            src={safeImages[active]!.image_url}
            alt={safeImages[active]!.alt_text ?? productName}
            fill
            priority
            sizes="(min-width: 1024px) 45vw, 100vw"
            className="object-cover"
          />
        </button>
      </div>

      <AnimatePresence>
        {lightbox && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 p-4"
            role="dialog"
            aria-modal="true"
            aria-label={`${productName} image ${active + 1} of ${safeImages.length}`}
          >
            <button onClick={() => setLightbox(false)} aria-label="Close" className="absolute right-4 top-4 flex h-11 w-11 items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20">
              <X className="h-5 w-5" />
            </button>
            {safeImages.length > 1 && (
              <>
                <button
                  onClick={() => setActive((a) => (a - 1 + safeImages.length) % safeImages.length)}
                  aria-label="Previous image"
                  className="absolute left-4 flex h-11 w-11 items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20"
                >
                  <ChevronLeft className="h-5 w-5" />
                </button>
                <button
                  onClick={() => setActive((a) => (a + 1) % safeImages.length)}
                  aria-label="Next image"
                  className="absolute right-4 flex h-11 w-11 items-center justify-center rounded-full bg-white/10 text-white hover:bg-white/20"
                >
                  <ChevronRight className="h-5 w-5" />
                </button>
              </>
            )}
            <div className="relative h-[85vh] w-full max-w-2xl">
              <Image src={safeImages[active]!.image_url} alt={safeImages[active]!.alt_text ?? productName} fill className="object-contain" />
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
