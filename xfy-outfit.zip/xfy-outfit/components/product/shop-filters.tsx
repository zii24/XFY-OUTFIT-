"use client";

import { useRouter, useSearchParams, usePathname } from "next/navigation";
import { useState } from "react";
import { SlidersHorizontal, X } from "lucide-react";
import { Select } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { SORT_OPTIONS } from "@/lib/constants";

interface Props {
  brands: { slug: string; name: string }[];
  categories: readonly { slug: string; name: string }[];
  styles: readonly { slug: string; name: string }[];
  sizes: readonly string[];
  activeFilters: Record<string, string | undefined>;
  resultCount: number;
}

export function ShopFilters({ brands, categories, styles, sizes, activeFilters, resultCount }: Props) {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();
  const [mobileOpen, setMobileOpen] = useState(false);

  const setParam = (key: string, value: string | null) => {
    const params = new URLSearchParams(searchParams.toString());
    if (value) params.set(key, value);
    else params.delete(key);
    router.push(`${pathname}?${params.toString()}`);
  };

  const hasActiveFilters = Object.entries(activeFilters).some(([k, v]) => v && k !== "sort" && k !== "q");

  const FilterBody = (
    <div className="space-y-7">
      <div>
        <label className="mb-2 block text-sm font-medium text-xfy-black">Sort by</label>
        <Select value={activeFilters.sort ?? "featured"} onChange={(e) => setParam("sort", e.target.value)}>
          {SORT_OPTIONS.map((opt) => (
            <option key={opt.value} value={opt.value}>
              {opt.label}
            </option>
          ))}
        </Select>
      </div>

      <div>
        <p className="mb-2 text-sm font-medium text-xfy-black">Category</p>
        <div className="space-y-1.5">
          {categories.map((c) => (
            <button
              key={c.slug}
              onClick={() => setParam("category", activeFilters.category === c.slug ? null : c.slug)}
              className={`block w-full rounded-xfy px-2 py-1.5 text-left text-sm ${activeFilters.category === c.slug ? "bg-xfy-blue-soft font-medium text-xfy-blue-dark" : "text-xfy-gray-700 hover:bg-xfy-gray-50"}`}
            >
              {c.name}
            </button>
          ))}
        </div>
      </div>

      <div>
        <p className="mb-2 text-sm font-medium text-xfy-black">Style</p>
        <div className="space-y-1.5">
          {styles.map((s) => (
            <button
              key={s.slug}
              onClick={() => setParam("style", activeFilters.style === s.slug ? null : s.slug)}
              className={`block w-full rounded-xfy px-2 py-1.5 text-left text-sm ${activeFilters.style === s.slug ? "bg-xfy-blue-soft font-medium text-xfy-blue-dark" : "text-xfy-gray-700 hover:bg-xfy-gray-50"}`}
            >
              {s.name}
            </button>
          ))}
        </div>
      </div>

      <div>
        <p className="mb-2 text-sm font-medium text-xfy-black">Brand</p>
        <Select value={activeFilters.brand ?? ""} onChange={(e) => setParam("brand", e.target.value || null)}>
          <option value="">All brands</option>
          {brands.map((b) => (
            <option key={b.slug} value={b.slug}>
              {b.name}
            </option>
          ))}
        </Select>
      </div>

      <div>
        <p className="mb-2 text-sm font-medium text-xfy-black">Size</p>
        <div className="flex flex-wrap gap-2">
          {sizes.map((s) => (
            <button
              key={s}
              onClick={() => setParam("size", activeFilters.size === s ? null : s)}
              className={`h-9 min-w-[38px] rounded-xfy border px-2 text-sm ${activeFilters.size === s ? "border-xfy-black bg-xfy-black text-white" : "border-xfy-gray-200 text-xfy-black hover:border-xfy-black"}`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      <label className="flex items-center gap-2 text-sm text-xfy-black">
        <input
          type="checkbox"
          checked={activeFilters.xfy_selected === "1"}
          onChange={(e) => setParam("xfy_selected", e.target.checked ? "1" : null)}
          className="h-4 w-4 rounded border-xfy-gray-300 text-xfy-blue focus:ring-xfy-blue"
        />
        XFY Selected only
      </label>

      <label className="flex items-center gap-2 text-sm text-xfy-black">
        <input
          type="checkbox"
          checked={activeFilters.availability === "in-stock"}
          onChange={(e) => setParam("availability", e.target.checked ? "in-stock" : null)}
          className="h-4 w-4 rounded border-xfy-gray-300 text-xfy-blue focus:ring-xfy-blue"
        />
        In stock only
      </label>

      {hasActiveFilters && (
        <Button variant="outline" size="sm" className="w-full" onClick={() => router.push(pathname)}>
          Clear filters
        </Button>
      )}
    </div>
  );

  return (
    <>
      <div className="hidden md:block">{FilterBody}</div>

      <div className="flex items-center justify-between md:hidden">
        <p className="text-sm text-xfy-gray-500">{resultCount} pieces</p>
        <Button variant="outline" size="sm" onClick={() => setMobileOpen(true)}>
          <SlidersHorizontal className="h-4 w-4" /> Filters
        </Button>
      </div>

      {mobileOpen && (
        <div className="fixed inset-0 z-50 flex flex-col bg-white md:hidden" role="dialog" aria-modal="true" aria-label="Filters">
          <div className="flex items-center justify-between border-b border-xfy-gray-200 p-4">
            <span className="font-display text-lg font-semibold">Filters</span>
            <button onClick={() => setMobileOpen(false)} aria-label="Close filters" className="flex h-9 w-9 items-center justify-center rounded-full hover:bg-xfy-gray-100">
              <X className="h-5 w-5" />
            </button>
          </div>
          <div className="flex-1 overflow-y-auto p-4">{FilterBody}</div>
          <div className="border-t border-xfy-gray-200 p-4">
            <Button variant="accent" className="w-full" onClick={() => setMobileOpen(false)}>
              Show {resultCount} results
            </Button>
          </div>
        </div>
      )}
    </>
  );
}
