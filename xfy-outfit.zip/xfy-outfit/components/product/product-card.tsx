import Link from "next/link";
import Image from "next/image";
import { Badge } from "@/components/ui/badge";
import { WishlistButton } from "./wishlist-button";
import { formatPrice } from "@/lib/utils";
import type { ProductWithBrand } from "@/types/product";

export function ProductCard({ product }: { product: ProductWithBrand }) {
  const primaryImage = product.images?.[0]?.image_url ?? "https://picsum.photos/seed/xfy-fallback/800/1000";
  const secondaryImage = product.images?.[1]?.image_url;
  const onSale = product.sale_price != null && product.sale_price < product.price;

  return (
    <Link href={`/product/${product.slug}`} className="group block">
      <div className="relative aspect-[4/5] overflow-hidden rounded-xfy bg-xfy-gray-100">
        <Image
          src={primaryImage}
          alt={product.images?.[0]?.alt_text ?? product.name}
          fill
          sizes="(min-width: 1024px) 25vw, (min-width: 640px) 33vw, 50vw"
          className={`object-cover transition-opacity duration-500 ${secondaryImage ? "group-hover:opacity-0" : "group-hover:scale-[1.03]"} `}
        />
        {secondaryImage && (
          <Image
            src={secondaryImage}
            alt=""
            fill
            sizes="(min-width: 1024px) 25vw, (min-width: 640px) 33vw, 50vw"
            className="object-cover opacity-0 transition-opacity duration-500 group-hover:opacity-100"
          />
        )}
        <div className="absolute left-3 top-3 flex flex-col gap-1.5">
          {product.xfy_selected && <Badge tone="selected">XFY Selected</Badge>}
          {onSale && <Badge tone="sale">Sale</Badge>}
          {product.stock === 0 && <Badge tone="status">Sold out</Badge>}
        </div>
        <WishlistButton product={product} className="absolute right-3 top-3" />
      </div>
      <div className="mt-3 space-y-0.5">
        <p className="text-xs font-medium uppercase tracking-wide text-xfy-gray-500">{product.brand?.name}</p>
        <h3 className="text-sm font-medium text-xfy-black">{product.name}</h3>
        <div className="flex items-center gap-2 pt-0.5">
          {onSale ? (
            <>
              <span className="text-sm font-semibold text-xfy-black">{formatPrice(product.sale_price!, product.currency)}</span>
              <span className="text-xs text-xfy-gray-500 line-through">{formatPrice(product.price, product.currency)}</span>
            </>
          ) : (
            <span className="text-sm font-semibold text-xfy-black">{formatPrice(product.price, product.currency)}</span>
          )}
        </div>
      </div>
    </Link>
  );
}
