"use client";

import { Heart } from "lucide-react";
import { cn } from "@/lib/utils";
import { useWishlist } from "@/context/wishlist-context";
import type { ProductWithBrand } from "@/types/product";

export function WishlistButton({ product, className }: { product: ProductWithBrand; className?: string }) {
  const { toggle, has } = useWishlist();
  const active = has(product.id);

  return (
    <button
      type="button"
      aria-pressed={active}
      aria-label={active ? "Remove from wishlist" : "Save to wishlist"}
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        toggle({
          productId: product.id,
          slug: product.slug,
          name: product.name,
          brandName: product.brand?.name ?? "",
          image: product.images?.[0]?.image_url ?? "",
          price: product.price,
          salePrice: product.sale_price,
          inStock: product.stock > 0,
        });
      }}
      className={cn(
        "flex h-9 w-9 items-center justify-center rounded-full bg-white/90 text-xfy-black shadow-sm backdrop-blur transition-transform hover:scale-105",
        className
      )}
    >
      <Heart className={cn("h-4 w-4 transition-colors", active && "fill-xfy-blue text-xfy-blue")} strokeWidth={1.75} />
    </button>
  );
}
