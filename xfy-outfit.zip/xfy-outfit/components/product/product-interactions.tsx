"use client";

import { useMemo, useState } from "react";
import { Minus, Plus, Share2, Check } from "lucide-react";
import { VariantSelector } from "./variant-selector";
import { CheckoutOptions } from "./checkout-options";
import { Button } from "@/components/ui/button";
import type { ProductWithBrand } from "@/types/product";

export function ProductInteractions({ product }: { product: ProductWithBrand }) {
  const variants = product.variants ?? [];
  const hasSizes = variants.some((v) => v.type === "size");
  const hasColors = variants.some((v) => v.type === "color");

  const [size, setSize] = useState<string | null>(null);
  const [color, setColor] = useState<string | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [copied, setCopied] = useState(false);

  const selectedVariantStock = useMemo(() => {
    if (!hasSizes && !hasColors) return product.stock;
    const sizeVariant = variants.find((v) => v.type === "size" && v.value === size);
    const colorVariant = variants.find((v) => v.type === "color" && v.value === color);
    const relevant = [sizeVariant, colorVariant].filter(Boolean);
    if (relevant.length === 0) return 0;
    return Math.min(...relevant.map((v) => v!.stock));
  }, [hasSizes, hasColors, size, color, variants, product.stock]);

  const readyToSelect = (!hasSizes || size) && (!hasColors || color);
  const canAddToCart = readyToSelect && selectedVariantStock > 0;

  const handleShare = async () => {
    const url = typeof window !== "undefined" ? window.location.href : "";
    try {
      if (navigator.share) {
        await navigator.share({ title: product.name, url });
      } else {
        await navigator.clipboard.writeText(url);
        setCopied(true);
        setTimeout(() => setCopied(false), 1800);
      }
    } catch {
      // User cancelled the share sheet — no action needed.
    }
  };

  return (
    <div className="mt-6 space-y-6">
      {hasSizes && <VariantSelector variants={variants} type="size" selected={size} onSelect={setSize} />}
      {hasColors && <VariantSelector variants={variants} type="color" selected={color} onSelect={setColor} />}

      <div>
        <p className="mb-2 text-sm font-medium text-xfy-black">Quantity</p>
        <div className="inline-flex items-center rounded-xfy border border-xfy-gray-200">
          <button
            aria-label="Decrease quantity"
            onClick={() => setQuantity((q) => Math.max(1, q - 1))}
            className="flex h-10 w-10 items-center justify-center text-xfy-black hover:bg-xfy-gray-50 disabled:opacity-40"
            disabled={quantity <= 1}
          >
            <Minus className="h-3.5 w-3.5" />
          </button>
          <span className="w-10 text-center text-sm font-medium" aria-live="polite">{quantity}</span>
          <button
            aria-label="Increase quantity"
            onClick={() => setQuantity((q) => Math.min(q + 1, selectedVariantStock || 10))}
            className="flex h-10 w-10 items-center justify-center text-xfy-black hover:bg-xfy-gray-50 disabled:opacity-40"
            disabled={quantity >= (selectedVariantStock || 0)}
          >
            <Plus className="h-3.5 w-3.5" />
          </button>
        </div>
        {(hasSizes || hasColors) && !readyToSelect && (
          <p className="mt-2 text-xs text-xfy-gray-500">Select {hasSizes && !size ? "a size" : "a color"} to see availability.</p>
        )}
        {readyToSelect && selectedVariantStock === 0 && <p className="mt-2 text-xs text-red-600">Out of stock in this selection.</p>}
        {readyToSelect && selectedVariantStock > 0 && selectedVariantStock <= 3 && (
          <p className="mt-2 text-xs text-xfy-blue">Only {selectedVariantStock} left</p>
        )}
      </div>

      <CheckoutOptions product={product} selectedSize={size} selectedColor={color} quantity={quantity} canAddToCart={canAddToCart} />

      <Button variant="ghost" size="sm" onClick={handleShare} className="text-xfy-gray-500">
        {copied ? <Check className="h-4 w-4" /> : <Share2 className="h-4 w-4" />}
        {copied ? "Link copied" : "Share this product"}
      </Button>
    </div>
  );
}
