"use client";

import { useState } from "react";
import { ShoppingBag, ExternalLink, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useCart } from "@/context/cart-context";
import { formatPrice } from "@/lib/utils";
import type { ProductWithBrand } from "@/types/product";

interface Props {
  product: ProductWithBrand;
  selectedSize: string | null;
  selectedColor: string | null;
  quantity: number;
  canAddToCart: boolean;
}

export function CheckoutOptions({ product, selectedSize, selectedColor, quantity, canAddToCart }: Props) {
  const { addLine } = useCart();
  const [added, setAdded] = useState(false);
  const unitPrice = product.sale_price ?? product.price;
  const variantLabel = [selectedSize, selectedColor].filter(Boolean).join(" / ") || null;

  const handleAddToXfyCart = () => {
    if (!canAddToCart) return;
    addLine({
      id: `${product.id}-${variantLabel ?? "default"}`,
      productId: product.id,
      slug: product.slug,
      name: product.name,
      brandName: product.brand?.name ?? "",
      image: product.images?.[0]?.image_url ?? "",
      unitPrice,
      quantity,
      variant: variantLabel,
      destination: "xfy",
      externalUrl: null,
      maxStock: product.stock,
    });
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  const openExternal = (url: string, destination: "shopee" | "etsy") => {
    addLine({
      id: `${product.id}-${destination}-${variantLabel ?? "default"}`,
      productId: product.id,
      slug: product.slug,
      name: product.name,
      brandName: product.brand?.name ?? "",
      image: product.images?.[0]?.image_url ?? "",
      unitPrice,
      quantity,
      variant: variantLabel,
      destination,
      externalUrl: url,
      maxStock: product.stock,
    });
    window.open(url, "_blank", "noopener,noreferrer");
  };

  return (
    <div className="space-y-3 rounded-xfy border border-xfy-gray-200 p-5">
      <p className="text-sm font-semibold text-xfy-black">Choose where to buy</p>

      <Button
        variant="accent"
        size="lg"
        className="w-full justify-between"
        disabled={!canAddToCart}
        onClick={handleAddToXfyCart}
      >
        <span className="flex items-center gap-2">
          <ShoppingBag className="h-4 w-4" />
          Buy on XFY
        </span>
        <span>{added ? <Check className="h-4 w-4" /> : formatPrice(unitPrice * quantity, product.currency)}</span>
      </Button>

      {product.shopee_url && (
        <Button
          variant="outline"
          size="lg"
          className="w-full justify-between"
          onClick={() => openExternal(product.shopee_url!, "shopee")}
        >
          <span>Buy on Shopee</span>
          <ExternalLink className="h-4 w-4" />
        </Button>
      )}

      {product.etsy_url && (
        <Button
          variant="outline"
          size="lg"
          className="w-full justify-between"
          onClick={() => openExternal(product.etsy_url!, "etsy")}
        >
          <span>Buy on Etsy</span>
          <ExternalLink className="h-4 w-4" />
        </Button>
      )}

      <p className="pt-1 text-xs leading-relaxed text-xfy-gray-500">
        Shopee and Etsy links open the seller&apos;s own store in a new tab — payment and fulfillment happen there,
        not on XFY. Buying on XFY checks out directly with us.
      </p>
    </div>
  );
}
