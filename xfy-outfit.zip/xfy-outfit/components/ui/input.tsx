import { cn } from "@/lib/utils";
import { forwardRef, type InputHTMLAttributes } from "react";

export const Input = forwardRef<HTMLInputElement, InputHTMLAttributes<HTMLInputElement>>(({ className, ...props }, ref) => (
  <input
    ref={ref}
    className={cn(
      "flex h-11 w-full rounded-xfy border border-xfy-gray-200 bg-white px-3.5 text-sm text-xfy-black placeholder:text-xfy-gray-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-xfy-blue disabled:opacity-50",
      className
    )}
    {...props}
  />
));
Input.displayName = "Input";
