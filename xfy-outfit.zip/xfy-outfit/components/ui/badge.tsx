import { cn } from "@/lib/utils";
import type { HTMLAttributes } from "react";

const styles: Record<string, string> = {
  selected: "bg-xfy-blue text-white",
  sale: "bg-xfy-navy text-white",
  outline: "border border-xfy-gray-200 text-xfy-gray-700",
  soft: "bg-xfy-blue-soft text-xfy-blue-dark",
  status: "bg-xfy-gray-100 text-xfy-gray-700",
};

export function Badge({ className, tone = "outline", children, ...props }: HTMLAttributes<HTMLSpanElement> & { tone?: keyof typeof styles }) {
  return (
    <span className={cn("inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium", styles[tone], className)} {...props}>
      {children}
    </span>
  );
}
