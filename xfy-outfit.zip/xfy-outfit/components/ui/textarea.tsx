import { cn } from "@/lib/utils";
import { forwardRef, type TextareaHTMLAttributes } from "react";

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaHTMLAttributes<HTMLTextAreaElement>>(({ className, ...props }, ref) => (
  <textarea
    ref={ref}
    className={cn(
      "flex min-h-[110px] w-full rounded-xfy border border-xfy-gray-200 bg-white px-3.5 py-2.5 text-sm text-xfy-black placeholder:text-xfy-gray-500 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-xfy-blue disabled:opacity-50",
      className
    )}
    {...props}
  />
));
Textarea.displayName = "Textarea";
