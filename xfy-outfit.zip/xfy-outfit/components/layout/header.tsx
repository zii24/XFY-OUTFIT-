"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { Heart, Search, ShoppingBag, Menu, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { NAV_LINKS } from "@/lib/constants";
import { useCart } from "@/context/cart-context";
import { useWishlist } from "@/context/wishlist-context";
import { SearchOverlay } from "./search-overlay";
import { MobileNav } from "./mobile-nav";

export function Header() {
  const pathname = usePathname();
  const [scrolled, setScrolled] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const { count } = useCart();
  const { items } = useWishlist();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <>
      <header
        className={cn(
          "sticky top-0 z-40 w-full bg-white/95 backdrop-blur transition-shadow",
          scrolled ? "shadow-[0_1px_0_0_rgba(15,23,42,0.08)]" : ""
        )}
      >
        <div className="container flex h-16 items-center justify-between md:h-20">
          <Link href="/" className="font-display text-xl font-bold tracking-tight text-xfy-black md:text-2xl">
            XFY
          </Link>

          <nav className="hidden items-center gap-8 md:flex" aria-label="Primary">
            {NAV_LINKS.map((link) => {
              const active = pathname === link.href || pathname.startsWith(link.href + "/");
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  className={cn(
                    "relative py-1 text-sm font-medium text-xfy-gray-700 transition-colors hover:text-xfy-black",
                    active && "text-xfy-black"
                  )}
                >
                  {link.label}
                  {active && <span className="absolute -bottom-1 left-0 h-[2px] w-full bg-xfy-blue" />}
                </Link>
              );
            })}
          </nav>

          <div className="flex items-center gap-1">
            <button
              aria-label="Search"
              onClick={() => setSearchOpen(true)}
              className="flex h-10 w-10 items-center justify-center rounded-full text-xfy-black hover:bg-xfy-gray-100"
            >
              <Search className="h-5 w-5" strokeWidth={1.75} />
            </button>
            <Link
              href="/wishlist"
              aria-label={`Wishlist, ${items.length} items`}
              className="relative hidden h-10 w-10 items-center justify-center rounded-full text-xfy-black hover:bg-xfy-gray-100 md:flex"
            >
              <Heart className="h-5 w-5" strokeWidth={1.75} />
              {items.length > 0 && (
                <span className="absolute right-1 top-1 flex h-4 w-4 items-center justify-center rounded-full bg-xfy-blue text-[10px] font-semibold text-white">
                  {items.length}
                </span>
              )}
            </Link>
            <Link
              href="/cart"
              aria-label={`Cart, ${count} items`}
              className="relative flex h-10 w-10 items-center justify-center rounded-full text-xfy-black hover:bg-xfy-gray-100"
            >
              <ShoppingBag className="h-5 w-5" strokeWidth={1.75} />
              {count > 0 && (
                <span className="absolute right-1 top-1 flex h-4 w-4 items-center justify-center rounded-full bg-xfy-blue text-[10px] font-semibold text-white">
                  {count}
                </span>
              )}
            </Link>
            <button
              aria-label="Open menu"
              onClick={() => setMobileOpen(true)}
              className="ml-1 flex h-10 w-10 items-center justify-center rounded-full text-xfy-black hover:bg-xfy-gray-100 md:hidden"
            >
              <Menu className="h-5 w-5" strokeWidth={1.75} />
            </button>
          </div>
        </div>
      </header>

      <SearchOverlay open={searchOpen} onClose={() => setSearchOpen(false)} />
      <MobileNav open={mobileOpen} onClose={() => setMobileOpen(false)} wishlistCount={items.length} />
    </>
  );
}
