"use client";

import Link from "next/link";
import { X, Heart } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import { NAV_LINKS } from "@/lib/constants";

export function MobileNav({ open, onClose, wishlistCount }: { open: boolean; onClose: () => void; wishlistCount: number }) {
  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/30 md:hidden"
            onClick={onClose}
            aria-hidden="true"
          />
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "tween", duration: 0.25, ease: [0.22, 0.61, 0.36, 1] }}
            className="fixed inset-y-0 right-0 z-50 flex w-[86%] max-w-sm flex-col bg-white p-6 shadow-xl md:hidden"
            role="dialog"
            aria-modal="true"
            aria-label="Menu"
          >
            <div className="mb-8 flex items-center justify-between">
              <span className="font-display text-lg font-bold">XFY</span>
              <button onClick={onClose} aria-label="Close menu" className="flex h-10 w-10 items-center justify-center rounded-full hover:bg-xfy-gray-100">
                <X className="h-5 w-5" />
              </button>
            </div>
            <nav className="flex flex-col gap-1" aria-label="Mobile primary">
              <Link href="/" onClick={onClose} className="rounded-xfy px-2 py-3 text-lg font-medium text-xfy-black hover:bg-xfy-gray-50">
                Home
              </Link>
              {NAV_LINKS.map((link) => (
                <Link key={link.href} href={link.href} onClick={onClose} className="rounded-xfy px-2 py-3 text-lg font-medium text-xfy-black hover:bg-xfy-gray-50">
                  {link.label}
                </Link>
              ))}
              <Link href="/wishlist" onClick={onClose} className="mt-3 flex items-center gap-2 rounded-xfy border-t border-xfy-gray-200 px-2 py-4 text-sm font-medium text-xfy-black">
                <Heart className="h-4 w-4" /> Wishlist {wishlistCount > 0 && `(${wishlistCount})`}
              </Link>
            </nav>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
