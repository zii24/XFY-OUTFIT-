import Link from "next/link";
import { Instagram, Music2 } from "lucide-react";

const columns = [
  {
    heading: "Shop",
    links: [
      { href: "/shop", label: "All Products" },
      { href: "/shop?style=streetwear", label: "Streetwear" },
      { href: "/shop?style=minimal", label: "Minimal" },
      { href: "/shop?style=vintage", label: "Vintage" },
    ],
  },
  {
    heading: "Discover",
    links: [
      { href: "/brands", label: "Brands" },
      { href: "/collections", label: "Collections" },
      { href: "/journal", label: "Journal" },
      { href: "/submit-brand", label: "Submit Your Brand" },
    ],
  },
  {
    heading: "XFY",
    links: [
      { href: "/about", label: "About" },
      { href: "/about#contact", label: "Contact" },
      { href: "/about#privacy", label: "Privacy Policy" },
      { href: "/about#terms", label: "Terms" },
    ],
  },
];

export function Footer() {
  return (
    <footer className="border-t border-xfy-gray-200 bg-white">
      <div className="container grid gap-12 py-16 md:grid-cols-[1.3fr_1fr_1fr_1fr]">
        <div>
          <Link href="/" className="font-display text-xl font-bold text-xfy-black">
            XFY
          </Link>
          <p className="mt-4 max-w-xs text-sm leading-relaxed text-xfy-gray-500">
            Discover independent fashion brands from Indonesia — curated pieces, emerging labels, and fashion culture worth paying attention to.
          </p>
          <div className="mt-6 flex gap-3">
            <a href="#" aria-label="XFY on Instagram" className="flex h-9 w-9 items-center justify-center rounded-full border border-xfy-gray-200 text-xfy-gray-700 hover:border-xfy-black hover:text-xfy-black">
              <Instagram className="h-4 w-4" />
            </a>
            <a href="#" aria-label="XFY on TikTok" className="flex h-9 w-9 items-center justify-center rounded-full border border-xfy-gray-200 text-xfy-gray-700 hover:border-xfy-black hover:text-xfy-black">
              <Music2 className="h-4 w-4" />
            </a>
          </div>
        </div>
        {columns.map((col) => (
          <div key={col.heading}>
            <h3 className="text-sm font-semibold text-xfy-black">{col.heading}</h3>
            <ul className="mt-4 space-y-3">
              {col.links.map((link) => (
                <li key={link.label}>
                  <Link href={link.href} className="text-sm text-xfy-gray-500 hover:text-xfy-black">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div className="border-t border-xfy-gray-200 py-6">
        <div className="container flex flex-col items-center justify-between gap-2 text-xs text-xfy-gray-500 md:flex-row">
          <p>© {new Date().getFullYear()} XFY Outfit. All rights reserved.</p>
          <p>Made for independent Indonesian fashion.</p>
        </div>
      </div>
    </footer>
  );
}
