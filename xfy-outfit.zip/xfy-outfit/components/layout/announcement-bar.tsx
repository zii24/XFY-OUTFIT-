export function AnnouncementBar({ text, enabled }: { text: string; enabled: boolean }) {
  if (!enabled) return null;
  return (
    <div className="bg-xfy-navy py-2 text-center text-xs text-white/90">
      <p>{text}</p>
    </div>
  );
}
