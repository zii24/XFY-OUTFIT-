"use client";

import { useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { Search, X } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";

export function SearchOverlay({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [q, setQ] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const router = useRouter();

  useEffect(() => {
    if (open) setTimeout(() => inputRef.current?.focus(), 50);
  }, [open]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [onClose]);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!q.trim()) return;
    router.push(`/shop?q=${encodeURIComponent(q.trim())}`);
    onClose();
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 bg-white"
          role="dialog"
          aria-modal="true"
          aria-label="Search"
        >
          <div className="container flex h-20 items-center justify-between">
            <span className="font-display text-lg font-semibold">Search XFY</span>
            <button onClick={onClose} aria-label="Close search" className="flex h-10 w-10 items-center justify-center rounded-full hover:bg-xfy-gray-100">
              <X className="h-5 w-5" />
            </button>
          </div>
          <div className="container">
            <form onSubmit={submit} className="flex items-center gap-3 border-b border-xfy-gray-200 pb-4">
              <Search className="h-5 w-5 shrink-0 text-xfy-gray-500" />
              <input
                ref={inputRef}
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search products, brands, styles…"
                className="w-full bg-transparent font-display text-2xl text-xfy-black placeholder:text-xfy-gray-300 focus:outline-none md:text-4xl"
              />
            </form>
            <p className="mt-6 text-sm text-xfy-gray-500">Press Enter to search, or Esc to close.</p>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
