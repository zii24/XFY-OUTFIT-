import { SectionHeading } from "./section-heading";
import { ProductGrid } from "@/components/product/product-grid";
import type { ProductWithBrand } from "@/types/product";

export function XfyPicks({ products }: { products: ProductWithBrand[] }) {
  if (products.length === 0) return null;
  return (
    <section className="container py-14 md:py-20">
      <SectionHeading title="XFY Picks" subtitle="Pieces selected from independent brands we think deserve attention." href="/shop?xfy_selected=1" cta="Shop all picks" />
      <ProductGrid products={products} />
    </section>
  );
}
