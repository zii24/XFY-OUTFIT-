import Image from "next/image";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import type { Brand } from "@/types/brand";

export function HiddenGems({ brand }: { brand: Brand | null }) {
  if (!brand) return null;
  return (
    <section className="bg-xfy-navy py-16 text-white md:py-24">
      <div className="container grid grid-cols-1 items-center gap-10 md:grid-cols-2">
        <div className="relative aspect-[4/5] w-full overflow-hidden rounded-xfy md:aspect-[3/4]">
          <Image
            src={brand.cover_image_url ?? `https://picsum.photos/seed/${brand.slug}-gem/900/1200`}
            alt={brand.name}
            fill
            sizes="(min-width: 768px) 50vw, 100vw"
            className="object-cover"
          />
        </div>
        <div className="max-w-md">
          <p className="text-sm font-medium text-xfy-blue-soft/90">Hidden Gems</p>
          <h2 className="mt-3 font-display text-3xl font-bold leading-tight md:text-4xl">
            Discover brands you probably haven&apos;t heard of yet.
          </h2>
          <p className="mt-4 text-sm leading-relaxed text-white/70 md:text-base">
            {brand.description ?? `${brand.name} is one of the independent labels we've been quietly following.`}
          </p>
          <Link href={`/brands/${brand.slug}`} className="mt-6 inline-flex items-center gap-2 text-sm font-medium text-white hover:text-xfy-blue-soft">
            Explore {brand.name} <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </div>
    </section>
  );
}
