import { SectionHeading } from "./section-heading";
import { BrandCard } from "@/components/brand/brand-card";
import type { Brand } from "@/types/brand";

export function NewBrands({ brands }: { brands: Brand[] }) {
  if (brands.length === 0) return null;
  return (
    <section className="container py-14 md:py-20">
      <SectionHeading title="New Brands" subtitle="Recently added labels worth a first look." href="/brands" cta="View all brands" />
      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        {brands.slice(0, 4).map((b) => (
          <BrandCard key={b.id} brand={b} />
        ))}
      </div>
    </section>
  );
}
