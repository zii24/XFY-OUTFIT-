import { SectionHeading } from "./section-heading";
import { CollectionCard } from "@/components/collection/collection-card";
import type { Collection } from "@/types/collection";

export function FeaturedCollections({ collections }: { collections: Collection[] }) {
  if (collections.length === 0) return null;
  return (
    <section className="container py-14 md:py-20">
      <SectionHeading title="Featured Collections" subtitle="Curated edits built around a style, not just a category." href="/collections" cta="View all collections" />
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {collections.slice(0, 3).map((c) => (
          <CollectionCard key={c.id} collection={c} />
        ))}
      </div>
    </section>
  );
}
