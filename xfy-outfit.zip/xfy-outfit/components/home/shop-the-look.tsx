import Image from "next/image";
import Link from "next/link";
import { SectionHeading } from "./section-heading";
import { formatPrice } from "@/lib/utils";
import type { ProductWithBrand } from "@/types/product";

export function ShopTheLook({ products, lookImage }: { products: ProductWithBrand[]; lookImage: string }) {
  if (products.length === 0) return null;
  return (
    <section className="container py-14 md:py-20">
      <SectionHeading title="Shop the Look" subtitle="One outfit, fully broken down — every piece is from an independent label." />
      <div className="grid grid-cols-1 gap-8 md:grid-cols-[1.1fr_1fr]">
        <div className="relative aspect-[4/5] w-full overflow-hidden rounded-xfy bg-xfy-gray-100">
          <Image src={lookImage} alt="A complete outfit styled from independent Indonesian brands" fill sizes="(min-width: 768px) 55vw, 100vw" className="object-cover" />
        </div>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-1">
          {products.map((product) => (
            <Link
              key={product.id}
              href={`/product/${product.slug}`}
              className="flex items-center gap-4 rounded-xfy border border-xfy-gray-200 p-3 transition-colors hover:border-xfy-black"
            >
              <div className="relative h-16 w-14 shrink-0 overflow-hidden rounded-xfy bg-xfy-gray-100">
                <Image src={product.images?.[0]?.image_url ?? ""} alt="" fill sizes="56px" className="object-cover" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-xs font-medium uppercase tracking-wide text-xfy-gray-500">{product.brand?.name}</p>
                <p className="truncate text-sm font-medium text-xfy-black">{product.name}</p>
              </div>
              <span className="shrink-0 text-sm font-semibold text-xfy-black">{formatPrice(product.sale_price ?? product.price, product.currency)}</span>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
