import Image from "next/image";
import Link from "next/link";
import { SectionHeading } from "./section-heading";
import type { JournalArticle } from "@/types/journal";

export function JournalHighlights({ articles }: { articles: JournalArticle[] }) {
  if (articles.length === 0) return null;
  return (
    <section className="container py-14 md:py-20">
      <SectionHeading title="XFY Journal" subtitle="Fashion culture, brand stories, and how to discover independent labels." href="/journal" cta="Read the journal" />
      <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
        {articles.slice(0, 3).map((article) => (
          <Link key={article.id} href={`/journal/${article.slug}`} className="group block">
            <div className="relative aspect-[4/3] w-full overflow-hidden rounded-xfy bg-xfy-gray-100">
              <Image
                src={article.cover_image_url ?? `https://picsum.photos/seed/${article.slug}/800/600`}
                alt={article.title}
                fill
                sizes="(min-width: 768px) 33vw, 100vw"
                className="object-cover transition-transform duration-500 group-hover:scale-105"
              />
            </div>
            <h3 className="mt-4 font-display text-lg font-semibold text-xfy-black">{article.title}</h3>
            {article.excerpt && <p className="mt-2 line-clamp-2 text-sm text-xfy-gray-500">{article.excerpt}</p>}
          </Link>
        ))}
      </div>
    </section>
  );
}
