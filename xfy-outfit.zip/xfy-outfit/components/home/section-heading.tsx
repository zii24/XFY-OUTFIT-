import Link from "next/link";
import { ArrowRight } from "lucide-react";

export function SectionHeading({ title, subtitle, href, cta }: { title: string; subtitle?: string; href?: string; cta?: string }) {
  return (
    <div className="mb-8 flex items-end justify-between gap-4">
      <div>
        <h2 className="font-display text-2xl font-bold text-xfy-black md:text-3xl">{title}</h2>
        {subtitle && <p className="mt-2 max-w-lg text-sm text-xfy-gray-500 md:text-base">{subtitle}</p>}
      </div>
      {href && cta && (
        <Link href={href} className="hidden shrink-0 items-center gap-1 text-sm font-medium text-xfy-black hover:text-xfy-blue md:flex">
          {cta} <ArrowRight className="h-4 w-4" />
        </Link>
      )}
    </div>
  );
}
