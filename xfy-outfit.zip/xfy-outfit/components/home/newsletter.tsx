"use client";

import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

export function Newsletter() {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);

  // V1: no email service is connected yet. Submitting confirms intent in the
  // UI without pretending to send a verified email — swap in a real
  // provider (e.g. Resend, Mailchimp) via a server action before launch.
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.includes("@")) return;
    setSubmitted(true);
  };

  return (
    <section className="border-t border-xfy-gray-200 bg-xfy-gray-50 py-16 md:py-20">
      <div className="container max-w-xl text-center">
        <h2 className="font-display text-2xl font-bold text-xfy-black md:text-3xl">Discover new brands before everyone else.</h2>
        <p className="mt-3 text-sm text-xfy-gray-500">One email, roughly monthly. New labels, curated picks, no noise.</p>
        {submitted ? (
          <p className="mt-6 text-sm font-medium text-xfy-blue">You&apos;re on the list — thanks for joining.</p>
        ) : (
          <form onSubmit={handleSubmit} className="mt-6 flex flex-col gap-3 sm:flex-row">
            <Input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="you@email.com"
              aria-label="Email address"
              className="flex-1"
            />
            <Button type="submit" variant="primary" size="lg">
              Subscribe
            </Button>
          </form>
        )}
      </div>
    </section>
  );
}
