"use client";

import Link from "next/link";
import Image from "next/image";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

interface Props {
  title: string;
  subtitle: string;
  imageUrl: string;
  ctaLabel: string;
  ctaHref: string;
  secondaryCtaLabel: string;
  secondaryCtaHref: string;
}

export function Hero({ title, subtitle, imageUrl, ctaLabel, ctaHref, secondaryCtaLabel, secondaryCtaHref }: Props) {
  return (
    <section className="container grid grid-cols-1 items-center gap-10 py-10 md:grid-cols-2 md:py-16">
      <motion.div
        initial={{ opacity: 0, y: 18 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, ease: [0.22, 0.61, 0.36, 1] }}
        className="order-2 max-w-md md:order-1"
      >
        <h1 className="font-display text-4xl font-bold leading-[1.08] tracking-tight text-xfy-black md:text-5xl">
          {title}
        </h1>
        <p className="mt-5 text-base leading-relaxed text-xfy-gray-700 md:text-lg">{subtitle}</p>
        <div className="mt-8 flex flex-wrap items-center gap-3">
          <Link href={ctaHref}>
            <Button variant="accent" size="lg">
              {ctaLabel}
              <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
          <Link href={secondaryCtaHref}>
            <Button variant="outline" size="lg">
              {secondaryCtaLabel}
            </Button>
          </Link>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, scale: 1.04 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.9, ease: [0.22, 0.61, 0.36, 1] }}
        className="order-1 relative aspect-[4/5] w-full overflow-hidden rounded-xfy bg-xfy-gray-100 md:order-2 md:aspect-[3/4]"
      >
        <Image src={imageUrl} alt="Editorial fashion photography featuring an independent Indonesian brand" fill priority sizes="(min-width: 768px) 50vw, 100vw" className="object-cover" />
      </motion.div>
    </section>
  );
}
