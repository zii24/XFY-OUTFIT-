import Link from "next/link";
import Image from "next/image";
import { ArrowUpRight } from "lucide-react";
import type { Collection } from "@/types/collection";

export function CollectionCard({ collection }: { collection: Collection }) {
  return (
    <Link href={`/collections/${collection.slug}`} className="group relative block overflow-hidden rounded-xfy">
      <div className="relative aspect-[3/4] w-full bg-xfy-gray-100">
        <Image
          src={collection.cover_image_url ?? `https://picsum.photos/seed/${collection.slug}/900/1200`}
          alt={collection.name}
          fill
          sizes="(min-width: 1024px) 33vw, 100vw"
          className="object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
      </div>
      <div className="absolute inset-x-0 bottom-0 flex items-end justify-between p-5">
        <div>
          <h3 className="font-display text-xl font-semibold text-white">{collection.name}</h3>
          {collection.description && <p className="mt-1 max-w-xs text-sm text-white/80">{collection.description}</p>}
        </div>
        <ArrowUpRight className="h-5 w-5 shrink-0 text-white transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
      </div>
    </Link>
  );
}
