import Link from "next/link";
import Image from "next/image";
import { MapPin } from "lucide-react";
import type { Brand } from "@/types/brand";

export function BrandCard({ brand }: { brand: Brand }) {
  return (
    <Link href={`/brands/${brand.slug}`} className="group block">
      <div className="relative aspect-[4/5] overflow-hidden rounded-xfy bg-xfy-navy">
        <Image
          src={brand.cover_image_url ?? `https://picsum.photos/seed/${brand.slug}/800/1000`}
          alt={brand.name}
          fill
          sizes="(min-width: 1024px) 25vw, 50vw"
          className="object-cover opacity-90 transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 p-4">
          <h3 className="font-display text-lg font-semibold text-white">{brand.name}</h3>
          {brand.location && (
            <p className="mt-1 flex items-center gap-1 text-xs text-white/80">
              <MapPin className="h-3 w-3" /> {brand.location}
            </p>
          )}
          {brand.style_tags && brand.style_tags.length > 0 && (
            <p className="mt-1 text-xs text-white/70">{brand.style_tags.slice(0, 3).join(" · ")}</p>
          )}
        </div>
      </div>
      {brand.description && <p className="mt-3 line-clamp-2 text-sm text-xfy-gray-500">{brand.description}</p>}
    </Link>
  );
}
